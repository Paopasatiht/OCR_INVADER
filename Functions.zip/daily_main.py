# \main_rerun.py
import json
from pathlib import Path
import logging
import configparser
from datetime import datetime
import shutil
from Functions.Extraction_Core import extraction_core_main
from Functions.Email_Sender import send_summary_email
from Functions.SharePoint_IO import SharePointClient
from Functions.Path_Handler import set_cache_paths, ensure_dir_exists

if __name__ == "__main__":

    today = datetime.now().strftime("%Y%m%d")  # e.g., 20251229

    # 0) Load config
    CONFIG_PATH = Path("Config/config.cfg")
    cfg = configparser.ConfigParser()
    if not cfg.read(CONFIG_PATH):
        print(f"[ERROR] Config file not found: {CONFIG_PATH}")
        exit(1)

    inputs_dir, outputs_dir, temp_dir, logs_dir = set_cache_paths(config_path=CONFIG_PATH)

    # Configurable flags
    Enable_SharePoint_API = cfg.getboolean("SharePoint_API_setting", "Enable_SharePoint_API", fallback=True)
    Ignore_SharePoint_Error = cfg.getboolean("SharePoint_API_setting", "Ignore_SharePoint_Error", fallback=False)
    Delete_Cache_After_Upload = cfg.getboolean("Cache_setting", "Delete_Cache_After_Upload", fallback=False)

    # 1) Prepare logger
    logs_dir.mkdir(parents=True, exist_ok=True)
    current_date = f"{today[:4]}-{today[4:6]}-{today[6:]}"
    log_file_path = logs_dir / f"log_{current_date}.txt"

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s",
        handlers=[
            logging.FileHandler(log_file_path, mode="w", encoding="utf-8"),
            logging.StreamHandler()
        ]
    )
    log = logging.getLogger("OCR")
    log.info("Logging initialized. File: %s", log_file_path)

    # Prepare local cache paths
    inputs_dir.mkdir(parents=True, exist_ok=True)
    outputs_dir.mkdir(parents=True, exist_ok=True)

    # Initialize extraction_results early
    extraction_results = {"status": "running", "sharepoint_status": "skipped" if not Enable_SharePoint_API else "ok"}

    # --- SharePoint Steps (only if enabled) ---
    if Enable_SharePoint_API:
        try:
            sp_client = SharePointClient(cfg)
            remote_input_template = cfg.get("SharePoint_Paths", "Remote_Input", fallback=None)
            remote_input_abs = f"{remote_input_template}/{today}"  if remote_input_template else f"/Inputs/{today}" # Download only today
            log.info("Listing files from SharePoint folder: %s", remote_input_abs)
            listed_items = sp_client.list_all_recursive(remote_input_abs, log=log)
            log.info("Total items listed: %d", len(listed_items))

            downloaded_paths, listed_files_abs = sp_client.download_tree(remote_input_abs, inputs_dir, log=log)
            log.info("Downloaded %d files to %s", len(downloaded_paths), inputs_dir)

            extraction_results["listed_remote_files"] = listed_files_abs
            extraction_results["downloaded_files"] = [str(p) for p in downloaded_paths]

        except Exception as e:
            log.exception("SharePoint listing/downloading failed.")
            extraction_results["sharepoint_status"] = "failed"
            extraction_results["sharepoint_error"] = str(e)
    else:
        log.info("SharePoint API disabled. Skipping file listing and downloading.")

    # --- Extraction ---
    try:
        extraction_results_core, dfs = extraction_core_main(
            today=today,
            cfg=cfg,
            log=log,
            CONFIG_PATH="Config/config.cfg",
            rerun=False,
            inputs_dir=inputs_dir,
            outputs_dir=outputs_dir,
            temp_dir=temp_dir
        )
        extraction_results.update(extraction_results_core)
    except Exception as e:
        log.exception("Extraction pipeline failed.")
        extraction_results["status"] = "failed"
        extraction_results["pipeline_error"] = str(e)

    # --- Upload outputs (only if enabled) ---
    if Enable_SharePoint_API:
        try:
            remote_output_template = cfg.get("SharePoint_Paths", "Remote_Output", fallback=None)
            remote_output_rel = f"{remote_output_template}/{today}" if remote_output_template else f"Outputs/{today}"
            log.info("Uploading output files to SharePoint folder: %s", remote_output_rel)

            uploaded_files = sp_client.upload_directory(outputs_dir, remote_output_rel, log=log)
            log.info("Uploaded %d files from %s to SharePoint folder %s", len(uploaded_files), outputs_dir, remote_output_rel)

            extraction_results["uploaded_files"] = [str(p) for p in uploaded_files]
        except Exception as e:
            log.exception("SharePoint upload failed.")
            extraction_results["sharepoint_status"] = "failed"
            extraction_results["sharepoint_upload_error"] = str(e)
    else:
        log.info("SharePoint API disabled. Skipping file upload.")

    # -------------------------------------------------------------------------
    # Save FINAL enriched extraction_results payload to JSON
    # -------------------------------------------------------------------------
    try:
        ensure_dir_exists(temp_dir)
        out_file = temp_dir / f"OCR_extraction_results_{current_date}.json"
        with open(out_file, "w", encoding="utf-8") as fo:
            json.dump(extraction_results, fo, ensure_ascii=False, indent=2)
        log.info("Saved enriched extraction results to: %s", out_file)
    except Exception as e:
        log.exception("Failed to save enriched extraction results: %s", e)

    # --- Always send email ---
    templates_dir = Path(cfg.get("Local_Paths", "Email_Template_Path", fallback="Email Format"))
    attachments_dir = outputs_dir
    to_emails_raw = cfg.get("Email", "to_emails", fallback="")
    to_emails = [e.strip() for e in to_emails_raw.split(",") if e.strip()]

    try:
        if to_emails:
            # Template selection logic
            if extraction_results.get("sharepoint_status") == "failed" and not Ignore_SharePoint_Error:
                extraction_results["status"] = "sharepoint_failed"
                log.warning("Using SharePoint failure email template.")
            else:
                log.info("Using standard OCR template (Ignore_SharePoint_Error=%s).", Ignore_SharePoint_Error)

            send_summary_email(
                extraction_results=extraction_results,
                templates_dir=templates_dir,
                attachments_dir=attachments_dir,
                config_path=CONFIG_PATH,
                to_emails=to_emails,
                log=log
            )

            log.info("Summary email sent successfully.")
        else:
            log.warning("Email skipped: no recipients configured.")
            
    except Exception:
        log.exception("Failed to send summary email.")

    # -------------------------------------------------------------------------
    # FINAL STEP: Delete cache after successful upload if configured
    # -------------------------------------------------------------------------
    try:
        should_delete = (
            Delete_Cache_After_Upload
            and Enable_SharePoint_API
            and bool(extraction_results.get("uploaded_files"))
            and extraction_results.get("sharepoint_status") != "failed"
        )

        if should_delete:
            log.info("Delete_Cache_After_Upload=true and upload succeeded. Purging cache directories...")

            def purge_dir(path: Path, name: str):
                try:
                    if path.exists():
                        shutil.rmtree(path)
                        log.info("Purged cache directory: %s", path)
                    else:
                        log.info("Skip purge: %s not found.", path)
                except Exception as e:
                    log.exception("Failed to purge %s: %s", name, e)

            # Purge main cache areas (adjust to your definition of 'cache')
            purge_dir(inputs_dir, "inputs_dir")
            purge_dir(outputs_dir, "outputs_dir")
            purge_dir(temp_dir, "temp_dir")

            # NOTE: We keep logs_dir to retain run history.
            log.info("Cache purge completed.")
        else:
            log.info(
                "Cache purge skipped. Conditions - Delete_Cache_After_Upload=%s, "
                "Enable_SharePoint_API=%s, uploaded_files=%s, sharepoint_status=%s",
                Delete_Cache_After_Upload,
                Enable_SharePoint_API,
                bool(extraction_results.get("uploaded_files")),
                extraction_results.get("sharepoint_status"),
            )
    except Exception:
        log.exception("Final cache purge step failed.")

