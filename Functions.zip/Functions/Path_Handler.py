import os
from pathlib import Path
import configparser as config  # as requested


def get_base_dir() -> Path:
    """
    Returns the directory containing the running .py file, if available.
    In Jupyter (.ipynb), __file__ is undefined; we fallback to current working dir.
    """
    try:
        # Works for .py scripts
        return Path(__file__).resolve().parent.parent
    except NameError:
        # In Jupyter notebooks, __file__ is not defined.
        # Best practical fallback is the current working directory (where the notebook typically runs).
        return Path.cwd().resolve()

def set_cache_paths(
    base_dir: Path | str | None = None,
    config_filename: str = "config.cfg",
    section: str = "Local_Paths",
    config_path: Path | str | None = None,
) -> tuple[Path, Path, Path, Path]:
    """
    Ensure cache directories specified in the config exist, and return them as absolute Paths.

    You can specify either:
      - config_path: full path to the INI file (preferred when you know it)
      - base_dir + config_filename: if the config file lives under base_dir

    Args:
        base_dir: Base directory to look for config file if config_path is not given.
                  If None, uses current working directory.
        config_filename: INI filename when config_path is not given (default 'config.cfg').
        section: INI section containing 'Cache_Inputs' and 'Cache_Outputs' (default 'Local_Paths').
        config_path: Full path to the config file. If provided, overrides base_dir+config_filename.
        allow_outputs_typo: If True, falls back to 'Cache_Ouputs' when 'Cache_Outputs' is missing.

    Returns:
        (inputs_path, outputs_path): Absolute Paths.

    Raises:
        FileNotFoundError: if the config file cannot be read.
        KeyError: if the section or required keys are missing.
    """
    # Resolve config file path
    if config_path:
        cfg_path = Path(config_path).resolve()
        base_dir_resolved = cfg_path.parent.parent  # used for resolving relative cache paths
    else:
        base_dir_resolved = Path(base_dir).resolve() if base_dir else Path.cwd().resolve()
        cfg_path = (base_dir_resolved / config_filename).resolve()

    # Read INI
    cfg = config.ConfigParser()
    read_files = cfg.read(cfg_path)
    if not read_files:
        raise FileNotFoundError(
            f"Could not find config file at {cfg_path}. "
            f"Ensure '{cfg_path.name}' is placed in {cfg_path.parent}."
        )

    if section not in cfg:
        raise KeyError(f"Missing [{section}] section in {cfg_path.name}")

    # Get values
    cache_inputs = cfg[section].get("Cache_Inputs")
    cache_outputs = cfg[section].get("Cache_Outputs")
    cache_temp = cfg[section].get("Cache_Temp")
    log_dir = cfg[section].get("Logs")

    if not cache_inputs:
        raise KeyError(f"Missing 'Cache_Inputs' key in [{section}] section")
    if not cache_outputs:
        raise KeyError(f"Missing 'Cache_Outputs' key in [{section}] section")
    if not cache_temp:
        raise KeyError(f"Missing 'Cache_Temp' key in [{section}] section")
    if not log_dir:
        raise KeyError(f"Missing 'Logs' key in [{section}] section")

    # Resolve to absolute paths; if relative, resolve against the directory containing the config file
    inputs_path = Path(cache_inputs)
    outputs_path = Path(cache_outputs)
    temp_path = Path(cache_temp)
    log_path = Path(log_dir)
    
    if not inputs_path.is_absolute():
        inputs_path = (base_dir_resolved / inputs_path).resolve()
    if not outputs_path.is_absolute():
        outputs_path = (base_dir_resolved / outputs_path).resolve()
    if not temp_path.is_absolute():
        temp_path = (base_dir_resolved / temp_path).resolve()
    if not log_path.is_absolute():
        log_path = (base_dir_resolved / log_path).resolve()

    # Ensure directories exist
    os.makedirs(inputs_path, exist_ok=True)
    os.makedirs(outputs_path, exist_ok=True)
    os.makedirs(temp_path, exist_ok=True)
    os.makedirs(log_path, exist_ok=True)

    print(f"Cache_Inputs -> {inputs_path}")
    print(f"Cache_Outputs -> {outputs_path}")
    print(f"Cache_Temp -> {temp_path}")
    print(f"Logs -> {log_path}")

    return inputs_path, outputs_path, temp_path, log_path


def ensure_dir_exists(path: Path):
    """Create directory if it does not exist."""
    path.mkdir(parents=True, exist_ok=True)
