# Functions/mappers/FINNET_transaction.py
from __future__ import annotations

from typing import Union, Optional, Dict, List, Tuple
from pathlib import Path
import logging
import configparser

import pandas as pd
from Functions.mappers.base import FINNETTransactionRecord, FINNETMapResult, TransactionRecord, TransactionFormMapper
from Functions.mappers.helpers import (normalize_transaction_amount, load_json_mapping, load_shared_agent_names, load_shared_bank_codes, normalize_header,
                                       map_account_number_FINNET)


class FINNETExcelMapper(TransactionFormMapper):
    """
    Map FINNET Excel/CSV rows to FINNETTransactionRecord(s) using JSON-based column mappings.
    Column config: Config/mapping_config/FINNET/finnet_columns.json
    Shared mappings: Config/mapping_config/bank_codes.json, agent_names.json
    """

    def __init__(
        self,
        config_path: Path,                  # not used here; kept for consistency with interface
        log: logging.Logger,
        mapping_config_path: Optional[Path] = None  # points to the finnet_columns.json
    ):
        self.log = log
        cfg = configparser.ConfigParser()
        cfg.read(str(config_path))
        shared_root = Path(cfg.get("Local_Paths", "Mapping_config_shared_root", fallback="Config/mapping_config")) # shared JSON location

        # Columns JSON (per-kind)
        self.mapping_config_path = mapping_config_path or (shared_root / "FINNET" / "finnet_columns.json") # hard-coded fallback
        self.colmap: Dict[str, str] = load_json_mapping(self.mapping_config_path, log)

        # Shared JSON for bank codes & agent names
        self.bank_codes_mapping = load_shared_bank_codes(config_path, log)
        self.agent_names_mapping = load_shared_agent_names(config_path, log)


    # ---- Helper: decide reader based on extension ----
    def _normalize_ext(self, p: Optional[Union[str, Path]]) -> str:
        if not p:
            return ""
        # Extract final extension in lowercase without dot
        return Path(str(p)).suffix.lower().lstrip(".")

    def _read_excel_like(
        self,
        source: Union[Path, str, bytes, bytearray, pd.DataFrame],
        sheet_name: Optional[Union[int, str]] = 0,
        csv_kwargs: Optional[Dict] = None,
    ) -> pd.DataFrame:
        """
        Read source as CSV/XLSX/XLS. If source is bytes, attempt in order: CSV -> XLSX -> XLS.
        """
        csv_kwargs = csv_kwargs or {}
        csv_defaults = {"encoding": "utf-8", "sep": ","}
        csv_opts = {**csv_defaults, **csv_kwargs}

        # Case 1: DataFrame
        if isinstance(source, pd.DataFrame):
            return source.copy()

        # Case 2: Path/str
        if isinstance(source, (Path, str)):
            ext = self._normalize_ext(source)
            if ext == "csv":
                return pd.read_csv(source, **csv_opts)
            elif ext in ("xlsx", "xlsm"):
                return pd.read_excel(source, sheet_name=sheet_name, engine="openpyxl", dtype=str)
            elif ext == "xls":
                return pd.read_excel(source, sheet_name=sheet_name, engine="xlrd", dtype=str)
            else:
                # Unknown/absent extension: try heuristics (CSV -> XLSX -> XLS)
                self.log.debug("Unknown extension for '%s'; trying CSV -> XLSX -> XLS", source)
                try:
                    return pd.read_csv(source, **csv_opts)
                except Exception as e_csv:
                    self.log.debug("CSV read failed: %s", e_csv)
                    try:
                        return pd.read_excel(source, sheet_name=sheet_name, engine="openpyxl", dtype=str)
                    except Exception as e_xlsx:
                        self.log.debug("XLSX read failed: %s", e_xlsx)
                        return pd.read_excel(source, sheet_name=sheet_name, engine="xlrd", dtype=str)

        # Case 3: bytes/bytearray (read in-memory)
        if isinstance(source, (bytes, bytearray)):
            from io import BytesIO, StringIO

            # Try CSV first (bytes -> text via UTF-8)
            try:
                text = source.decode("utf-8")
                return pd.read_csv(StringIO(text), **csv_opts)
            except Exception as e_csv:
                self.log.debug("In-memory CSV read failed: %s", e_csv)

            # Try XLSX next
            try:
                return pd.read_excel(BytesIO(source), sheet_name=sheet_name, engine="openpyxl", dtype=str)
            except Exception as e_xlsx:
                self.log.debug("In-memory XLSX read failed: %s", e_xlsx)

            # Finally try XLS
            return pd.read_excel(BytesIO(source), sheet_name=sheet_name, engine="xlrd", dtype=str)

        raise TypeError("Unsupported excel_source type")

    def _load_df(
        self,
        excel_source: Union[Path, str, bytes, bytearray, pd.DataFrame],
        sheet_name: Optional[Union[int, str]] = 0,
        csv_kwargs: Optional[Dict] = None,
    ) -> pd.DataFrame:
        """
        Load the data into a DataFrame.
        Supports: .xlsx, .xls, .csv
        Accepts: Path/str, bytes/bytearray, or DataFrame.
        """
        df = self._read_excel_like(excel_source, sheet_name=sheet_name, csv_kwargs=csv_kwargs)

        df.columns = [normalize_header(str(c)) for c in df.columns]
        # Fill down id-ish columns if present
        for col in ("no", "sa"):
            if col in df.columns:
                df[col] = df[col].ffill()
        return df.fillna("")
    
    def _resolve_column(self, df: pd.DataFrame, key: str, fallbacks: List[str]) -> str:
        """
        Resolve logical key using colmap target header -> normalized name,
        then fallback to provided alternatives.
        """
        if key in self.colmap:
            mapped = normalize_header(self.colmap[key])
            if mapped in df.columns:
                return mapped
        for fb in fallbacks:
            norm_fb = normalize_header(fb)
            if norm_fb in df.columns:
                return norm_fb
        return ""  # not found

    def _to_transaction_records(self, fr_list: list[FINNETTransactionRecord]) -> list[TransactionRecord]:
        return [
            TransactionRecord(
                agent=fr.agent,
                payment_type=fr.payment_type,
                bank_code=fr.bank_code,
                bank_account_no_fmt=fr.bank_account_no_fmt,
                amount=fr.amount,
                date=fr.date,
                source_kind=fr.source_kind,
                source_file=fr.source_file
            )
            for fr in fr_list
        ]

    def map(
        self,
        excel_source: Union[Path, str, bytes, pd.DataFrame],
        input_dir: Path, # For saving relative path,
        today: str = "",
    ) -> FINNETMapResult:

        """
        Create FINNETTransactionRecord(s) using dynamic column resolution.
        Triaging:
          - SUCCESS: payment_type !~ /total amount|grand total/ & result contains 'success' & amount present
          - PROCESSING: payment_type !~ /total amount|grand total/ & PROCESSING result
          - FAIL: payment_type !~ /total amount|grand total/ & FAIL result
          - IGNORE: otherwise (including empty result)
        """

        # today string comes in the form of yyyymmdd, convert to dd/mm/yyyy first
        
        try:
            s = (today or "").strip()
            if len(s) == 8 and s.isdigit():
                y = s[0:4]
                m = s[4:6]
                d = s[6:8]
                today = f"{d}/{m}/{y}"
        except Exception as e:
            self.log.warning("FINNET mapper: cannot convert today date string to the proper format for today = %s: %s", today, e)


        df = self._load_df(excel_source)

        # Resolve columns (config-driven, with fallbacks)
        c_no      = self._resolve_column(df, "no", ["no"])
        c_agent   = self._resolve_column(df, "agent", ["sa", "agent"])
        c_paytype = self._resolve_column(df, "payment_type", ["payment_type"])
        c_toacct  = self._resolve_column(df, "to_account", ["to_bank_account_no", "account"])
        c_amount  = self._resolve_column(df, "amount", ["to_receive", "amount", "value"])
        c_result  = self._resolve_column(df, "result", ["result", "status"])
        c_date    = self._resolve_column(df, "date", ["processing_time", "date", "txn_date"])

        
        # === Forward-fill payment_type (pay_text) before processing rows ===
        try:
            if c_paytype:
                # Normalize to string, strip, lowercase; treat empty string as missing for ffill
                # Work on a copy to avoid chained assignment warnings
                col = df[c_paytype].astype(str).map(lambda s: s.strip().lower())
                col = col.replace({"": None})              # empty -> NaN-like for ffill
                col = col.ffill()
                col = col.fillna("")                       # any remaining -> empty string
                df[c_paytype] = col
        except Exception as e:
            self.log.warning("FINNET mapper: unable to forward-fill payment_type: %s", e)
        
        missing_keys = [k for k, v in {
            "no": c_no, "agent": c_agent, "payment_type": c_paytype,
            "to_account": c_toacct, "amount": c_amount, "result": c_result, "date": c_date
            }.items() if v == ""]
        if missing_keys:
            self.log.warning("FINNET mapper: unresolved columns for keys: %s", ", ".join(missing_keys))

        success_records: List[FINNETTransactionRecord] = []
        pending_records: List[FINNETTransactionRecord] = []
        rows_processed = 0
        rows_filtered = 0
        rows_pending = 0
        missing_account_map = 0

        for rec in df.itertuples(index=False):
            no_val      = str(getattr(rec, c_no, "")).strip() if c_no else ""
            agent_short = str(getattr(rec, c_agent, "")).strip() if c_agent else ""
            agent_name  = self.agent_names_mapping.get(agent_short) or agent_short

            pay_text    = str(getattr(rec, c_paytype, "")).strip().lower() if c_paytype else ""
            result_text = str(getattr(rec, c_result, "")).strip().lower() if c_result else ""
            to_cell     = str(getattr(rec, c_toacct, "")).strip() if c_toacct else ""
            amount_raw  = str(getattr(rec, c_amount, "")).strip() if c_amount else ""
            date_val    = today

            # Summary/total rows -> filter out rows with "total amount", "grand total" and "by sa" in pay_text column
            if ("total amount" in pay_text) or ("grand total" in pay_text) or ("by sa" in pay_text):
                rows_filtered += 1
                continue

            # Filter empty result rows -> only by FINNET cases
            if not result_text:
                rows_filtered += 1
                continue

            # Pending when result != SUCCESS
            if result_text != "success":
                pending_records.append(FINNETTransactionRecord(
                    no=no_val,
                    agent=agent_name,
                    payment_type="C",
                    bank_code="",
                    bank_account_no_fmt="",
                    amount=str(normalize_transaction_amount(amount_raw) or "").strip(),
                    date=date_val,
                    source_kind="FINNET",
                    source_file=excel_source.relative_to(input_dir),
                    result_status=result_text
                ))
                rows_pending += 1
                continue

            amount = normalize_transaction_amount(amount_raw)
            if not amount:
                rows_filtered += 1
                continue

            # Map bank/account format if possible
            bank_code = ""
            bank_account_no_fmt = ""
            mapped: Optional[Tuple[str, str, str]] = None
            try:
                mapped = map_account_number_FINNET(to_cell, self.bank_codes_mapping)
            except Exception as e:
                self.log.debug("FINNET account map error for '%s': %s", to_cell, e)

            if mapped:
                code, bank_name, normalized_acc = mapped
                bank_code = f"{code}"
                bank_account_no_fmt = f"{code} {bank_name} {normalized_acc}"
            else:
                missing_account_map += 1
                self.log.warning("FINNET: unmapped account (No. %s) for to_account='%s'", no_val, to_cell)

            success_records.append(FINNETTransactionRecord(
                no=no_val,
                agent=agent_name,
                payment_type="C",
                bank_code=bank_code,
                bank_account_no_fmt=bank_account_no_fmt,
                amount=str(amount).strip(),
                date=date_val,
                source_kind="FINNET",
                source_file=excel_source.relative_to(input_dir),
                result_status=result_text
            ))
            rows_processed += 1

        self.log.info(
            "FINNET rows processed=%d, SUCCESS=%d, PENDING=%d, filtered=%d, unmapped_accounts=%d",
            rows_processed, len(success_records), len(pending_records), rows_filtered, missing_account_map
        )

        return FINNETMapResult(
            records=self._to_transaction_records(success_records),
            success_transactions=success_records,
            pending_transactions=pending_records
        )


# ----------------------------------------
# Utilities to use at top level
# ----------------------------------------


def save_finnet_records_to_excel(
    records: List[FINNETTransactionRecord],
    excel_path: Union[str, Path]
) -> None:
    """
    Save FINNETTransactionRecord list to an Excel file at top level (deferred I/O).
    """
    rows = [
        {
            "No.": r.no,
            "Agent": r.agent,
            "Payment Type": r.payment_type,
            "Bank Code": r.bank_code,
            "Bank Account No Fmt": r.bank_account_no_fmt,
            "Amount": r.amount,
            "Date": r.date,
            "Result": r.result_status,
            "Source kind": r.source_kind,
            "Source file": r.source_file
        }
        for r in records
    ]
    # Use Excel writer to save as .xlsx
    pd.DataFrame(rows).to_excel(excel_path, index=False)




