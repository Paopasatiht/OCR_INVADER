import json
import re
import logging
import configparser
from pathlib import Path, PureWindowsPath
from typing import Optional, Tuple, Dict, Any
from datetime import datetime
from Functions.mappers.base import DateNormOptions

# ----------------------------
# Helpers
# ----------------------------
def to_bool(val: Optional[object], default: bool) -> bool:
    if val is None:
        return default
    if isinstance(val, bool):
        return val
    s = str(val).strip().lower()
    if s in {"true", "1", "yes", "y"}:
        return True
    if s in {"false", "0", "no", "n"}:
        return False
    return default

def to_int(val: Optional[object], default: int) -> int:
    try:
        return int(val) if val is not None else default
    except Exception:
        return default

def to_optional_bool(val: Optional[object]) -> Optional[bool]:
    """
    Map JSON values for prefer_buddhist_shorthand → Optional[bool]
    - True/False remain boolean
    - 'auto' or None → None
    """
    if val is None:
        return None
    if isinstance(val, bool):
        return val
    s = str(val).strip().lower()
    if s in {"auto", "none", "null"}:
        return None
    if s in {"true", "1", "yes", "y"}:
        return True
    if s in {"false", "0", "no", "n"}:
        return False
    # Unknown string → keep auto behavior
    return None

def to_locale(val: Optional[object]) -> Optional[str]:
    if val is None:
        return None
    s = str(val).strip().lower()
    return s if s in {"th", "en"} else None


def normalize_header(name: str) -> str:
    """Normalize column header: lowercase, remove line breaks, punctuation, collapse spaces to underscores."""
    name = str(name).lower()
    name = name.replace("\n", " ")            # remove line breaks
    name = re.sub(r"[^\w\s]", " ", name)      # remove punctuation except letters/numbers
    name = re.sub(r"\s+", "_", name)          # collapse spaces to underscore
    return name

def normalize_account_number(account_no: str) -> str:
    """Return digits-only account number."""
    return re.sub(r'\D', '', account_no or '')


def normalize_transaction_amount(amount_str: str) -> str:
    """
    Format transaction amount to '#,###.00'.
    Examples:
      '1' -> '1.00'
      '1.0011231' -> '1.00'
      '  1 1 2 3 1 . 0 0  ' -> '11,231.00'
    """
    cleaned = re.sub(r'[^\d.]', '', amount_str or '')
    if cleaned.count('.') > 1:
        first, *rest = cleaned.split('.')
        cleaned = first + '.' + ''.join(rest)
    if not cleaned or cleaned == '.':
        return '0.00'
    try:
        value = float(cleaned)
    except ValueError:
        return '0.00'
    return f"{value:,.2f}"


def normalize_date(date_str: str, options: Optional[DateNormOptions] = None) -> str:
    """
    Normalize date to dd/mm/yyyy.
    Handles:
      - yyyy-mm-dd (spaces around separators tolerated)
      - dd/mm/yyyy or dd-mm-yyyy (spaces around separators tolerated)
      - English month names (short/full)
      - Thai month abbreviations (with or without dots/spaces)
      - Thai Buddhist year (subtract 543)
      - Shorthand Buddhist year (e.g., '68' -> 2568 -> 2025) with context-aware rules
      - Two-digit Gregorian year using a dynamic pivot
      - Space-separated triplets after month-name replacement (e.g., '22 ธ.ค. 2568' -> '22 12 2568')
    """
    if options is None:
        options = DateNormOptions()  # safe default

    # Thai digit normalization map (for OCR cases)
    THAI_DIGITS = {
        "๐": "0", "๑": "1", "๒": "2", "๓": "3", "๔": "4",
        "๕": "5", "๖": "6", "๗": "7", "๘": "8", "๙": "9"
    }

    THAI_MONTHS = {
        r"ม\.?ค\.?": "01", r"มค": "01",
        r"ก\.?พ\.?": "02", r"กพ": "02",
        r"มี\.?ค\.?": "03", r"มีค": "03",
        r"เม\.?ย\.?": "04", r"เมย": "04",
        r"พ\.?ค\.?": "05", r"พค": "05",
        r"มิ\.?ย\.?": "06", r"มิย": "06",
        r"ก\.?ค\.?": "07", r"กค": "07",
        r"ส\.?ค\.?": "08", r"สค": "08",
        r"ก\.?ย\.?": "09", r"กย": "09",
        r"ต\.?ค\.?": "10", r"ตค": "10",
        r"พ\.?ย\.?": "11", r"พย": "11",
        r"ธ\.?ค\.?": "12", r"ธค": "12",
    }

    EN_MONTHS = {
        r"\bjan(uary)?\b": "01",
        r"\bfeb(ruary)?\b": "02",
        r"\bmar(ch)?\b": "03",
        r"\bapr(il)?\b": "04",
        r"\bmay\b": "05",
        r"\bjun(e)?\b": "06",
        r"\bjul(y)?\b": "07",
        r"\baug(ust)?\b": "08",
        r"\bsep(t(ember)?)?\b": "09",
        r"\boct(ober)?\b": "10",
        r"\bnov(ember)?\b": "11",
        r"\bdec(ember)?\b": "12",
    }

    THAI_CONTEXT_PATTERNS = [
        r"พ\.?ศ\.?",      # "พ.ศ."
        r"\bพศ\b",
        r"[๐-๙]",         # Thai digits present
        r"[\u0E00-\u0E7F]",  # any Thai letters
    ]

    def has_thai_context(s: str) -> bool:
        if options.locale_hint and (options.locale_hint.lower() == "th"):
            return True
        return any(re.search(p, s) for p in THAI_CONTEXT_PATTERNS)

    def to_ddmmyyyy(d: str, m: str, y: str) -> str:
        return f"{d.zfill(2)}/{m.zfill(2)}/{y}"

    def interpret_year(y: str, s: str) -> str:
        """
        Decide Gregorian 4-digit year from 'y', using options.
        """
        current_year = datetime.now().year

        # 4-digit year
        if len(y) == 4:
            y_int = int(y)
            # Treat typical Buddhist years by range instead of ad-hoc offsets
            if 2300 <= y_int <= 2700:
                return str(y_int - 543)
            return str(y_int)

        # 2-digit year
        if len(y) == 2:
            yy = int(y)

            # Candidates
            buddhist_candidate = (2500 + yy) - 543   # 1957 + yy
            pivot = (current_year % 100) + options.pivot_offset
            gregorian_candidate = (2000 + yy) if yy <= pivot else (1900 + yy)

            # Forced modes first
            if options.prefer_buddhist_shorthand is True:
                return str(buddhist_candidate)
            if options.prefer_buddhist_shorthand is False:
                return str(gregorian_candidate)

            # Auto mode
            if has_thai_context(s):
                return str(buddhist_candidate)

            # Proximity override: choose Buddhist if it's near the current year
            if abs(buddhist_candidate - current_year) <= options.buddhist_proximity_window:
                return str(buddhist_candidate)

            # Default to Gregorian pivot
            return str(gregorian_candidate)

        # Fallback
        return y

    try:
        s = (date_str or "").strip()

        if not s:
            return date_str

        # 0) Normalize Thai digits -> Latin (helps OCR cases)
        s = s.translate(str.maketrans(THAI_DIGITS))

        # 1) Lowercase for English month matching (Thai unaffected by lower())
        s = s.lower()

        # 2) Replace Thai months with numeric tokens
        for thai_pattern, num in THAI_MONTHS.items():
            s = re.sub(thai_pattern, num, s)

        # 3) Replace English months with numeric tokens
        for eng_pattern, num in EN_MONTHS.items():
            s = re.sub(eng_pattern, num, s)

        # 4) Keep digits, slash, dash, and spaces; normalize others to space then squeeze
        s = re.sub(r"[^\d/\-\s]", " ", s)
        s = re.sub(r"\s+", " ", s).strip()

        # 5) Trim spaces around separators so '22/12 / 2568' -> '22/12/2568'
        s = re.sub(r"\s*([/\-])\s*", r"\1", s)

        # --- Pattern A: yyyy-mm-dd or yyyy/mm/dd (spaces around sep already trimmed)
        mobj = re.fullmatch(r"(\d{4})[-/](\d{1,2})[-/](\d{1,2})", s)
        if mobj:
            y, mth, d = mobj.groups()
            y = interpret_year(y, s)
            return to_ddmmyyyy(d, mth, y)

        # --- Pattern B: dd/mm/yy(yy) or mm/dd/yy(yy) (spaces around sep trimmed)
        mobj = re.fullmatch(r"(\d{1,2})[-/](\d{1,2})[-/](\d{2,4})", s)
        if mobj:
            a, b, y = mobj.groups()
            y = interpret_year(y, s)
            if options.assume_day_first:
                d, mth = a, b
            else:
                mth, d = a, b
            return to_ddmmyyyy(d, mth, y)

        # --- Pattern C: space-separated triplets (after month replacement)
        # e.g. "22 12 2568" -> dd mm yyyy
        mobj = re.fullmatch(r"(\d{1,2})\s+(\d{1,2})\s+(\d{2,4})", s)
        if mobj:
            d, mth, y = mobj.groups()
            y = interpret_year(y, s)
            return to_ddmmyyyy(d, mth, y)

        # --- Fallback: split on any of '-', '/', or whitespace
        parts = re.split(r"[-/\s]+", s)
        parts = [p for p in parts if p]
        if len(parts) == 3:
            a, b, c = parts
            # Heuristic: yyyy/mm/dd if first part > 31
            if a.isdigit() and int(a) > 31:
                y, mth, d = a, b, c
            else:
                if options.assume_day_first:
                    d, mth, y = a, b, c
                else:
                    mth, d, y = a, b, c
            y = interpret_year(y, s)
            return to_ddmmyyyy(d, mth, y)

        # No        # No parse → return original
        return date_str

    except Exception:
        return date_str

# ----------------------------
# Agent name extractor
# ----------------------------

# ---- Normalization helpers ----
def _normalize_for_match(s: str) -> str:
    """
    Lowercase, strip surrounding spaces, collapse inner spaces, and remove common punctuation.
    Preserves Thai characters; removes ASCII punctuation that often appears in paths.
    """
    s = s.lower()
    # Remove common separators/punctuation that may be in paths
    s = re.sub(r"[\-_/\\\.\(\)\[\],:]+", " ", s)
    # Collapse spaces
    s = re.sub(r"\s+", " ", s).strip()
    return s

def _split_tokens(path_str: str) -> list:
    """
    Split path into tokens by both slash types and common separators,
    keeping meaningful words (including Thai) for matching.
    """
    # First split by path separators
    parts = re.split(r"[\\/]+", path_str)
    tokens = []
    for part in parts:
        # Further split by spaces and common punctuation
        tokens.extend(re.split(r"[\s\-\._\(\)\[\],:]+", part))
    # Remove empties
    return [t for t in tokens if t]

def _extract_company_name_from_value(value: str) -> str:
    """
    Your dict values look like: "AECS - บริษัท หลักทรัพย์ บียอนด์ จำกัด (มหาชน)"
    Extract the company Thai/English name part to improve matching.
    """
    # Split at ' - ' once
    left, sep, right = value.partition(" - ")
    # If we have the right part, that's the company name; else use the entire value
    company = right or value
    return company.strip()

# ---- Main extractor ----
def extract_agent_from_path(
    path_str: str,
    agent_map: Dict[str, str],
) -> Optional[Tuple[str, str]]:
    """
    Robustly extract (agent_code, agent_display_value) from arbitrary path strings.

    Strategy:
    1) Normalize the entire path string.
    2) Try exact agent code matches (word-boundary).
    3) Try full value substring matches (case-insensitive).
    4) Try company-name fragment matches (normalized).
    5) Resolve ambiguity by preferring code matches, then longest name fragment.

    Returns:
        (code, display_value) from agent_map, or None if no match is found.
    """
    if not path_str or not agent_map:
        return None

    raw = path_str.strip()
    # Build normalization of entire path and a token set for code checks
    path_norm = _normalize_for_match(raw)
    tokens = set(_split_tokens(raw.lower()))

    # Pre-compute normalized company names for each code
    index = []
    for code, display in agent_map.items():
        code_norm = code.lower()
        full_value_norm = _normalize_for_match(display)
        company_name = _extract_company_name_from_value(display)
        company_norm = _normalize_for_match(company_name)

        # Prepare regex for codes with word boundaries to avoid partial matches
        code_pattern = re.compile(rf"(?<!\w){re.escape(code_norm)}(?!\w)")

        index.append({
            "code": code,
            "code_norm": code_norm,
            "display": display,
            "full_value_norm": full_value_norm,
            "company_norm": company_norm,
            "code_pattern": code_pattern,
            "company_len": len(company_norm.replace(" ", "")),  # length without spaces for tie-breaking
        })

    # 1) Exact code match anywhere
    code_hits = []
    for item in index:
        # Fast token check OR regex on normalized path
        if item["code_norm"] in tokens or item["code_pattern"].search(path_norm):
            code_hits.append(item)

    if code_hits:
        # If multiple codes matched, prefer the one whose company name appears too
        enriched_hits = []
        for it in code_hits:
            has_company = it["company_norm"] and (it["company_norm"] in path_norm)
            enriched_hits.append((has_company, it["company_len"], it))
        # Sort: prefer has_company=True, then longer company name
        enriched_hits.sort(key=lambda x: (not x[0], -x[1]))
        best = enriched_hits[0][2]
        return best["display"]

    # 2) Full display value substring match (case-insensitive, normalized)
    value_hits = [it for it in index if it["full_value_norm"] in path_norm]
    if value_hits:
        # Prefer longest full value (rarely needed but safe)
        value_hits.sort(key=lambda it: -len(it["full_value_norm"]))
        best = value_hits[0]
        return best["display"]

    # 3) Company-name fragment match (normalized)
    company_hits = [it for it in index if it["company_norm"] and it["company_norm"] in path_norm]
    if company_hits:
        # Prefer the longest company name (most specific)
        company_hits.sort(key=lambda it: -it["company_len"])
        best = company_hits[0]
        return best["display"]

    # 4) Last resort: substring code (without word boundary), to catch cases like "SCB01"
    loose_code_hits = [it for it in index if it["code_norm"] in path_norm]
    if loose_code_hits:
        loose_code_hits.sort(key=lambda it: -len(it["code_norm"]))
        best = loose_code_hits[0]
        return best["display"]

    return None

# ----------------------------
# Mapping loader
# ----------------------------

# Map Thai numerals to ASCII digits
def normalize_account_number(acc: str, preserve_leading_zeros: bool = False) -> str:
    """
    Extract and normalize an account number from OCR text.

    - Converts Thai numerals to Arabic.
    - Accepts digits possibly separated by spaces/dashes.
    - Collapses separators and returns the longest candidate digit run found.
    - Optionally removes leading zeros (default behavior).

    Parameters:
        acc: The raw OCR-extracted string.
        preserve_leading_zeros: If True, keep leading zeros in the output.
                                If False (default), strip leading zeros.

    Returns:
        The normalized account number string. If no digits found, returns "".

    Examples:
        normalize_account_number("0991364021 บัญชี", preserve_leading_zeros=False) -> "991364021"
        normalize_account_number("09 913-640 21") -> "991364021"
        normalize_account_number("เลขบัญชี: ๑๒๓-๔๕๖ ๗๘๙๐") -> "1234567890"
        normalize_account_number("000-000", preserve_leading_zeros=False) -> "0"
        normalize_account_number("000-000", preserve_leading_zeros=True)  -> "000000"
    """
    _THAI_TO_ARABIC = str.maketrans({
        "๐": "0", "๑": "1", "๒": "2", "๓": "3", "๔": "4",
        "๕": "5", "๖": "6", "๗": "7", "๘": "8", "๙": "9"
    })

    if acc is None:
        return ""

    s = str(acc).strip()
    # Normalize Thai digits to Arabic
    s = s.translate(_THAI_TO_ARABIC)

    # Find sequences of digits that may include spaces/dashes as separators
    # e.g. "12 345-67" will be captured as a single token
    tokens = re.findall(r"[0-9]+(?:[ \t-]+[0-9]+)*", s)
    if not tokens:
        return ""

    # Collapse separators and select the longest candidate
    def _collapse(t: str) -> str:
        return re.sub(r"[ \t-]+", "", t)

    candidates = [_collapse(t) for t in tokens]
    best = max(candidates, key=len)

    if preserve_leading_zeros:
        return best

    # Remove leading zeros; keep a single '0' if all zeros
    stripped = best.lstrip("0")
    return stripped if stripped != "" else "0"


def _resolve_json_path(base_cfg_path: Path, rel_json: str, log: logging.Logger, mapping_type: str) -> Path:
    try:
        p = Path(rel_json.strip())
        if not p.is_absolute():
            p = (base_cfg_path.parent / p).resolve()
        return p
    except Exception as e:
        log.exception("Failed to resolve JSON path for %s: %s", mapping_type, e)
        raise


def load_json_mapping(json_path: Path, log: logging.Logger) -> Dict[str, Any]:
    """
    Load mapping from a JSON file. Expected structure: dict (values can be str or dict).
    """
    if not json_path.exists():
        raise FileNotFoundError(f"Mapping file not found: {json_path}")
    try:
        with open(json_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, dict):
            raise TypeError(f"Expected dict in {json_path}, got {type(data)}")
        # Strip keys only; keep values intact
        cleaned = {k.strip(): (v.strip() if isinstance(v, str) else v) for k, v in data.items()}
        log.info("Loaded mapping from %s with %d keys.", json_path, len(cleaned))
        return cleaned
    except Exception as e:
        log.exception("Failed to load mapping from %s: %s", json_path, e)
        raise


def load_shared_bank_codes(config_path: Path, log: logging.Logger) -> dict:
    """Load shared bank codes from path in config.cfg and normalize keys."""
    cfg = configparser.ConfigParser()
    cfg.read(str(config_path))
    bank_codes_path = Path(cfg.get("Local_Paths", "BANK_CODES_DICT"))
    raw = load_json_mapping(bank_codes_path, log)
    normalized = {normalize_account_number(k): v for k, v in raw.items()}
    log.info("Bank codes loaded: %d normalized keys.", len(normalized))
    return normalized

def load_shared_agent_names(config_path: Path, log: logging.Logger) -> dict:
    """Load shared agent names from path in config.cfg."""
    cfg = configparser.ConfigParser()
    cfg.read(str(config_path))
    agent_names_path = Path(cfg.get("Local_Paths", "AGENT_NAMES_DICT"))
    return load_json_mapping(agent_names_path, log)


def map_account_number(raw_account_no: str, bank_codes_mapping: Dict[str, Dict[str, str]]) -> Optional[Tuple[str, str, str]]:
    """
    Return (bank_code, bank_name, normalized_number) for a raw OCR account number.
    Returns None if not found.
    """
    normalized = normalize_account_number(raw_account_no)
    match = bank_codes_mapping.get(normalized)
    if not match:
        return None
    bank_code = match.get("bank_code", "")
    bank_name = match.get("bank", "")
    account_no = match.get("account_no", "")
    return bank_code, bank_name, account_no


from typing import Optional, Tuple, Dict, Any, List

MASK_CHARS = set(["x", "X", "•", "*", "●"])

def _collapse_separators(s: str) -> str:
    # Remove spaces and dashes only inside the token
    return re.sub(r"[ \t-]+", "", s)

def _extract_digit_tokens(s: str) -> List[str]:
    """
    Returns digit tokens that may include spaces/dashes between groups.
    Example: "xxx-x-x6827-x" -> ["6827"]
             "09 913-640 21" -> ["09 913-640 21"]
    """
    _THAI_TO_ARABIC = str.maketrans({
    "๐": "0", "๑": "1", "๒": "2", "๓": "3", "๔": "4",
    "๕": "5", "๖": "6", "๗": "7", "๘": "8", "๙": "9"
    })  

    s = str(s).strip()
    # Normalize Thai digits to Arabic
    s = s.translate(_THAI_TO_ARABIC)

    return re.findall(r"[0-9]+(?:[ \t-]+[0-9]+)*", s)

def _is_masked(s: str) -> bool:
    return any(ch in MASK_CHARS for ch in s)

def _digits_only(s: str) -> str:
    _THAI_TO_ARABIC = str.maketrans({
    "๐": "0", "๑": "1", "๒": "2", "๓": "3", "๔": "4",
    "๕": "5", "๖": "6", "๗": "7", "๘": "8", "๙": "9"
    })  

    s = str(s).strip()
    # Normalize Thai digits to Arabic
    s = s.translate(_THAI_TO_ARABIC)
    return re.sub(r"[^0-9]", "", s)

def _align_mask(candidate: str, masked: str) -> bool:
    """
    Validate that a candidate full account (digits only) matches the masked pattern.
    Rule: compare from the right (most slips keep last 4 visible).
    Any mask char can match any digit; visible digits must align at same relative positions.
    """
    cand = _digits_only(candidate)
    _THAI_TO_ARABIC = str.maketrans({
    "๐": "0", "๑": "1", "๒": "2", "๓": "3", "๔": "4",
    "๕": "5", "๖": "6", "๗": "7", "๘": "8", "๙": "9"
    })  

    masked = str(masked).strip()
    # Normalize Thai digits to Arabic
    m = masked.translate(_THAI_TO_ARABIC)

    # Strip separators in masked but keep mask characters and digits
    m_compact = re.sub(r"[ \t-]", "", m)

    # Align right by visible digits in masked
    # Build an index list of visible digits (with their positions from right)
    vis = [(idx, ch) for idx, ch in enumerate(m_compact) if ch.isdigit()]
    if not vis:
        return False

    # Compare each visible digit from the right edge
    # Compute offsets from the end for masked and candidate
    # Example masked "...x6827x" -> positions of 6,8,2,7 should equal candidate[-4:]
    k = len(m_compact)
    n = len(cand)
    # If candidate shorter than number of visible digits, fail
    if n < len(vis):
        return False

    # Check right-aligned positions: For masked index i (from right = k-1-i),
    # compare with candidate at n-1 - (k-1-i) = n-k+i
    for i, ch in vis:
        ci = n - k + i
        if ci < 0 or ci >= n:
            return False
        if cand[ci] != ch:
            return False
    return True

def map_account_number_from_hint(
    raw_acc: str,
    bank_codes_mapping: Dict[str, Dict[str, str]],
    bank_hint_code: Optional[str] = None,
    bank_hint_name: Optional[str] = None,
    logger: Optional[logging.Logger] = None,
) -> Optional[Tuple[str, str, str]]:
    """
    Resolve raw account (possibly masked/partial) to full account using bank_codes_mapping.
    Returns (bank_code, bank_name, full_account) or None if not resolvable.

    - If raw_acc contains a masked pattern (e.g., 'xxx-x-x6827-x'), try mask alignment.
    - Else extract digit tokens; collapse separators; choose the longest token.
    - If the longest token is shorter than 6 digits (likely suffix), match by .endswith(token).
    - Use bank hints (code/name) to disambiguate when multiple matches exist.
    """
    log = logger or logging.getLogger(__name__)
    s = raw_acc or ""
    _THAI_TO_ARABIC = str.maketrans({
    "๐": "0", "๑": "1", "๒": "2", "๓": "3", "๔": "4",
    "๕": "5", "๖": "6", "๗": "7", "๘": "8", "๙": "9"
    })  

    s = str(s).strip()
    # Normalize Thai digits to Arabic
    s_norm = s.translate(_THAI_TO_ARABIC)

    # 1) If the raw contains mask chars, attempt mask alignment across all known accounts
    if _is_masked(s_norm):
        candidates = []
        for full_acc, meta in bank_codes_mapping.items():
            try:
                if _align_mask(full_acc, s_norm):
                    candidates.append((full_acc, meta))
            except Exception:
                # Defensive: skip malformed entries
                continue

        if not candidates:
            # Fall back to digit-only heuristics below
            log.debug("Mask alignment found no candidates for '%s'", raw_acc)
        elif len(candidates) == 1:
            full, meta = candidates[0]
            return meta.get("bank_code", ""), meta.get("bank", ""), full
        else:
            # Disambiguate by bank hints first
            filtered = _filter_by_bank_hints(candidates, bank_hint_code, bank_hint_name)
            if len(filtered) == 1:
                full, meta = filtered[0]
                return meta.get("bank_code", ""), meta.get("bank", ""), full
            # If still multiple, prefer longest length, then lexicographic
            best = sorted(filtered or candidates, key=lambda x: (len(_digits_only(x[0])), x[0]), reverse=True)[0]
            full, meta = best
            return meta.get("bank_code", ""), meta.get("bank", ""), full

    # 2) Extract digit tokens (handles cases like '09 913-640 21')
    tokens = _extract_digit_tokens(s_norm)
    if not tokens:
        # No digits—cannot resolve
        return None

    # Collapse separators; choose longest
    collapsed = [_collapse_separators(t) for t in tokens]
    best = max(collapsed, key=len)

    # If best looks like a full account (>= 8–10 digits commonly), try direct dict hit
    if best in bank_codes_mapping:
        meta = bank_codes_mapping[best]
        return meta.get("bank_code", ""), meta.get("bank", ""), best

    # 3) Treat short tokens as suffix; search mapping for accounts ending with best
    #    Use >=6 as heuristic threshold; tweak if your data shows shorter suffixes
    if len(best) < 6:
        matches = []
        for full_acc, meta in bank_codes_mapping.items():
            if _digits_only(full_acc).endswith(best):
                matches.append((full_acc, meta))

        if not matches:
            return None
        if len(matches) == 1:
            full, meta = matches[0]
            return meta.get("bank_code", ""), meta.get("bank", ""), full

        # Disambiguate with bank hints
        filtered = _filter_by_bank_hints(matches, bank_hint_code, bank_hint_name)
        if len(filtered) == 1:
            full, meta = filtered[0]
            return meta.get("bank_code", ""), meta.get("bank", ""), full

        # As tie-breaker: prefer the account with same length (if you know expected lengths),
        # else choose deterministically by lexical
        best_match = sorted(filtered or matches, key=lambda x: x[0])[0]
        full, meta = best_match
        return meta.get("bank_code", ""), meta.get("bank", ""), full

    # 4) If best is mid-length (e.g., 7 digits) and not exact, attempt contains heuristic
    contains = []
    for full_acc, meta in bank_codes_mapping.items():
        if best in _digits_only(full_acc):
            contains.append((full_acc, meta))
    if contains:
        filtered = _filter_by_bank_hints(contains, bank_hint_code, bank_hint_name)
        full, meta = (filtered or contains)[0]
        return meta.get("bank_code", ""), meta.get("bank", ""), full

    # No resolution
    return None

def _filter_by_bank_hints(
    pairs: List[Tuple[str, Dict[str, str]]],
    bank_hint_code: Optional[str],
    bank_hint_name: Optional[str],
) -> List[Tuple[str, Dict[str, str]]]:
    if not bank_hint_code and not bank_hint_name:
        return pairs
    out = []
    for full, meta in pairs:
        code_ok = (bank_hint_code and meta.get("bank_code") == bank_hint_code)
        name_ok = (bank_hint_name and meta.get("bank", "").lower() == bank_hint_name.lower())
        if (bank_hint_code and code_ok) or (bank_hint_name and name_ok):
            out.append((full, meta))
    return out



def map_account_number_FINNET(to_cell: str, bank_codes_mapping: Dict[str, Dict[str, str]]) -> Optional[Tuple[str, str, str]]:
    """
    Return (bank_code, bank_name, normalized_number) for a raw FINNET account number.
    Returns None if not found.
    """
    # Step 1: Extract account number (assume format: BANKSHORTNAME ACCNO)
    parts = to_cell.split()
    if len(parts) == 2:
        _, raw_acc = parts
    else:
        # fallback: try to find the account number (last part)
        raw_acc = parts[-1] if parts else ""

    # Step 2: Map account number
    return map_account_number(raw_acc, bank_codes_mapping)


def load_default_accounts(config_path: Path, log: logging.Logger) -> Dict[str, str]:
    cfg = configparser.ConfigParser()
    cfg.read(str(config_path))
    try:
        default_accounts_path = Path(cfg.get("Local_Paths", "DEFAULT_ACCOUNTS_DICT"))
        if not default_accounts_path.exists():
            log.warning("Default accounts file not found: %s", default_accounts_path)
            return {}
        return load_json_mapping(default_accounts_path, log)
    except Exception as e:
        log.exception("Could not load default accounts: %s", e)
        return {}

def get_fallback_account(
        doc_type: str,
        default_accounts: Dict[str, str],
        bank_codes_mapping: Dict[str, Dict[str, str]],
        log: logging.Logger
) -> Optional[Tuple[str, str, str]]:
    
    if not doc_type:
        return None
    
    default_acc = default_accounts.get(doc_type)
    if not default_acc:
        log.info("No default account configured for document type: %s", doc_type)
        return None
    
    result = map_account_number(default_acc, bank_codes_mapping)
    if result:
        log.info("Using fallback account for document type %s: %s", doc_type, default_acc)
        return result