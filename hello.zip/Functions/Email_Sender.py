# Functions\Email_Sender.py
from pathlib import Path
from datetime import datetime
from typing import Dict, Any, List, Optional
from Functions.email.smtp_handler import (
    send_email,
    send_plain_text_email,
     _build_flat_summary_excel, 
    _build_smart_reconcile_email_body,
    _build_smart_reconcile_subject,
    _build_summary_excel,
)
import logging

def _collect_output_attachments(
    attachments_dir: Path,
    log: logging.Logger,
    extensions: tuple = (".xlsx", ".xls", ".csv"),
    max_files: int = 10,  # เพิ่ม parameter นี้
) -> List[Path]:
    """
    รวบรวมไฟล์ output จาก directory ที่จะแนบไปกับ email

    Args:
        attachments_dir: Directory ที่เก็บ output files
        log: Logger
        extensions: นามสกุลไฟล์ที่ต้องการ (default: Excel files)
        max_files: จำนวนไฟล์สูงสุดที่จะแนบ (ป้องกัน email ใหญ่เกินไป)

    Returns:
        List[Path]: รายการไฟล์ที่จะแนบ
    """
    attachments: List[Path] = []

    if not attachments_dir.exists():
        log.warning("Attachments directory does not exist: %s", attachments_dir)
        return attachments

    try:
        # หาไฟล์ตาม extensions ที่กำหนด
        for ext in extensions:
            for file_path in attachments_dir.glob(f"*{ext}"):
                if file_path.is_file():
                    attachments.append(file_path)

        # จำกัดจำนวนไฟล์
        if len(attachments) > max_files:
            log.warning(
                "Too many attachments (%d), limiting to %d files",
                len(attachments), max_files
            )
            # เรียงตามเวลาแก้ไขล่าสุด แล้วเอาแค่ max_files
            attachments.sort(key=lambda p: p.stat().st_mtime, reverse=True)
            attachments = attachments[:max_files]

        log.info("Collected %d output attachments from %s", len(attachments), attachments_dir)

    except Exception as e:
        log.exception("Error collecting attachments: %s", e)

    return attachments

def send_summary_email(
    extraction_results: Dict[str, Any],
    templates_dir: Path,
    attachments_dir: Path,
    config_path: Path,
    to_emails: List[str],
    log: logging.Logger
) -> None:
    """
    Prepare email template, generate failure Excel if needed, and send OCR summary email.

    :param extraction_results: Dict containing OCR pipeline results.
    :param templates_dir: Path to directory containing HTML templates.
    :param attachments_dir: Path to directory for saving Excel attachments.
    :param config_path: Path to Config/config.cfg for SMTP settings.
    :param to_emails: List of recipient email addresses.
    :param log: Logger instance.
    """
    try:
        # Select template and prepare attachments
        template_path, attachments = prepare_email_template_and_attachments(
            extraction_results=extraction_results,
            templates_dir=templates_dir,
            output_dir=attachments_dir,
            log=log
        )

        # Send email
        send_email(
            subject=f"OCR Summary • {datetime.now().strftime('%Y-%m-%d')}",
            body_path=template_path,
            to_emails=to_emails,
            log=log,
            config_path=config_path,
            attachments=attachments
        )

        log.info("OCR summary email sent successfully.")

    except Exception as e:
        log.exception("Failed to send OCR summary email: %s", e)


def send_thai_summary_email(
    extraction_results: Dict[str, Any],
    attachments_dir: Path,
    config_path: Path,
    to_emails: List[str],
    log: logging.Logger,
    cc_emails: Optional[List[str]] = None,
    subject_prefix: str = "สรุปผล OCR",
    include_output_files: bool = True,
) -> None:
    """
    ส่ง email สรุปผลแบบ Plain Text ภาษาไทย

    Args:
        extraction_results: Dict ของผลลัพธ์การ extraction
        attachments_dir: Directory ที่เก็บ output files
        config_path: Path ไปยัง Config/config.cfg
        to_emails: List ของ email addresses ผู้รับ
        log: Logger
        cc_emails: List ของ CC recipients (optional)
        subject_prefix: Prefix สำหรับ email subject
        include_output_files: แนบ output Excel files หรือไม่
    """
    log.info("Preparing Thai plain text summary email...")

    try:
        # -----------------------------------------------------------------
        # Step 1: สร้าง email body (plain text ภาษาไทย)
        # -----------------------------------------------------------------
        body_text = _build_thai_plain_text_body(
            extraction_results=extraction_results,
            log=log,
            config_path=config_path  # ส่ง config_path เพื่อโหลด agent names
        )

        # -----------------------------------------------------------------
        # Step 2: สร้าง summary Excel
        # -----------------------------------------------------------------
        failure_keys = [
            "encrypted_pdf_files",
            "failed_OCR_classification_files",
            "failed_OCR_extraction_files",
            "unknown_or_unused_from_azure",
            "failed_mapping_files",
        ]
        success_key = "overall_success_files"

        attachments_dir.mkdir(parents=True, exist_ok=True)

        all_attachments: List[Path] = []

        try:
            summary_path = _build_summary_excel(
                extraction_results=extraction_results,
                output_dir=attachments_dir,
                log=log,
                failure_keys=failure_keys,
                success_key=success_key
            )
            all_attachments.append(summary_path)
        except Exception as e:
            log.exception("Failed to create summary Excel: %s", e)

        # -----------------------------------------------------------------
        # Step 3: รวบรวม output files (ถ้าต้องการ)
        # -----------------------------------------------------------------
        if include_output_files:
            output_files = _collect_output_attachments(attachments_dir, log)
            existing_names = {p.name for p in all_attachments}
            for f in output_files:
                if f.name not in existing_names:
                    all_attachments.append(f)

        log.info("Total attachments: %d", len(all_attachments))

        # -----------------------------------------------------------------
        # Step 4: สร้าง subject (ภาษาไทย)
        # -----------------------------------------------------------------
        subject = _build_thai_email_subject(extraction_results, subject_prefix)
        log.info("Email subject: %s", subject)

        # -----------------------------------------------------------------
        # Step 5: ส่ง email
        # -----------------------------------------------------------------
        send_plain_text_email(
            subject=subject,
            body_text=body_text,
            to_emails=to_emails,
            log=log,
            config_path=config_path,
            attachments=all_attachments,
            cc_emails=cc_emails,
        )

        log.info("Thai summary email sent successfully to: %s", ", ".join(to_emails))

    except Exception as e:
        log.exception("Failed to send Thai summary email: %s", e)
        raise


def _build_thai_email_subject(
    extraction_results: Dict[str, Any],
    prefix: str = "สรุปผล OCR"
) -> str:
    """
    สร้าง subject ภาษาไทย

    Format: "[prefix] [สถานะ] - DD/MM/YYYY HH:MM"
    """
    from datetime import datetime

    status = extraction_results.get("status", "unknown")

    if status == "sharepoint_failed":
        status_label = "SharePoint ผิดพลาด"
    elif status == "failed":
        status_label = "ล้มเหลว"
    else:
        failure_keys = [
            "encrypted_pdf_files",
            "failed_OCR_classification_files",
            "failed_OCR_extraction_files",
            "unknown_or_unused_from_azure",
            "failed_mapping_files",
        ]
        failures_exist = any(extraction_results.get(k) for k in failure_keys)
        success_exist = bool(extraction_results.get("overall_success_files"))

        if failures_exist and success_exist:
            status_label = "สำเร็จบางส่วน"
        elif failures_exist:
            status_label = "ล้มเหลว"
        elif success_exist:
            status_label = "สำเร็จ"
        else:
            status_label = "ไม่มีไฟล์"

    timestamp = datetime.now().strftime("%d/%m/%Y %H:%M")

    return f"[{prefix}] {status_label} - {timestamp}"


# =====================================================================================
# send_smart_reconcile_email - ส่ง email แบบ OCR Smart Reconcile
# =====================================================================================
def send_smart_reconcile_email(
    extraction_results: Dict[str, Any],
    attachments_dir: Path,
    config_path: Path,
    to_emails: List[str],
    log: logging.Logger,
    cc_emails: Optional[List[str]] = None,
    sender_name: str = "ทีมพัฒนา OCR",
    include_output_files: bool = True,
    max_attachments: int = 10,
) -> None:
    """
    ส่ง email สรุปผลแบบ OCR Smart Reconcile

    Args:
        extraction_results: Dict ของผลลัพธ์การ extraction
        attachments_dir: Directory ที่เก็บ output files
        config_path: Path ไปยัง Config/config.cfg
        to_emails: List ของ email addresses ผู้รับ
        log: Logger
        cc_emails: List ของ CC recipients (optional)
        sender_name: ชื่อผู้ส่ง/ทีม ที่จะแสดงท้าย email
        include_output_files: แนบ output Excel files หรือไม่
        max_attachments: จำนวนไฟล์แนบสูงสุด
    """
    log.info("Preparing Smart Reconcile summary email...")

    try:
        # -----------------------------------------------------------------
        # Step 1: สร้าง email body และ status
        # -----------------------------------------------------------------
        body_text, status_text = _build_smart_reconcile_email_body(
            extraction_results=extraction_results,
            log=log,
            config_path=config_path,
            sender_name=sender_name
        )

        # -----------------------------------------------------------------
        # Step 2: สร้าง subject
        # -----------------------------------------------------------------
        subject = _build_smart_reconcile_subject(status_text)
        log.info("Email subject: %s", subject)

        # -----------------------------------------------------------------
        # Step 3: สร้าง summary Excel
        # -----------------------------------------------------------------
        attachments_dir.mkdir(parents=True, exist_ok=True)
        all_attachments: List[Path] = []

        try:
            # summary_path = _build_summary_excel(
            #     extraction_results=extraction_results,
            #     output_dir=attachments_dir,
            #     log=log
            # )

            summary_path = _build_flat_summary_excel(
                extraction_results=extraction_results,
                output_dir=attachments_dir,
                log=log,
                config_path=config_path  # ส่ง config เพื่อโหลด agent names
            )
            all_attachments.append(summary_path)
        except Exception as e:
            log.exception("Failed to create summary Excel: %s", e)

        # -----------------------------------------------------------------
        # Step 4: รวบรวม output files (ถ้าต้องการ)
        # -----------------------------------------------------------------
        if include_output_files:
            output_files = _collect_output_attachments(
                attachments_dir, log,
                max_files=max_attachments
            )
            existing_names = {p.name for p in all_attachments}
            for f in output_files:
                if f.name not in existing_names:
                    all_attachments.append(f)

        log.info("Total attachments: %d", len(all_attachments))

        # -----------------------------------------------------------------
        # Step 5: ส่ง email
        # -----------------------------------------------------------------
        send_plain_text_email(
            subject=subject,
            body_text=body_text,
            to_emails=to_emails,
            log=log,
            config_path=config_path,
            attachments=all_attachments,
            cc_emails=cc_emails,
        )

        log.info("Smart Reconcile email sent successfully to: %s", ", ".join(to_emails))

    except Exception as e:
        log.exception("Failed to send Smart Reconcile email: %s", e)
        raise