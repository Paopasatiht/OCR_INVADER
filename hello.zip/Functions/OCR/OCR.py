import os
import logging
import random
import time
import re
import mimetypes
from io import BytesIO
from pathlib import Path
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Dict, List, Optional, Tuple

import fitz  # PyMuPDF
import requests
from azure.core.credentials import AzureKeyCredential
from azure.core.exceptions import HttpResponseError
from azure.core.pipeline.transport import RequestsTransport
from azure.core.pipeline.policies import RetryPolicy
from azure.ai.documentintelligence import DocumentIntelligenceClient
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry


# -------------------------------
# Other Helpers
# -------------------------------
def _preflight_pdf_openable(
    pdf_path: Path, logger: Optional[logging.Logger] = None
) -> Tuple[bool, bool, Optional[str]]:
    """
    Returns (openable, is_encrypted, error_message).
    If False, error_message contains the exception string.
    """
    log = logger or logging.getLogger(__name__)
    try:
        doc = fitz.open(str(pdf_path))
        try:
            # If the document requires a password, treat as not openable
            if getattr(doc, "is_encrypted", False):
                return False, True, "PDF is encrypted and requires a password"
            return True, False, None
        finally:
            try:
                doc.close()
            except Exception:
                pass
    except Exception as e:
        # Typical errors: "document closed", "file is corrupted", etc.
        return False, False, str(e)

# -------------------------------
# Client creation (injected creds)
# -------------------------------
def create_di_client(
    di_endpoint: str,
    di_key: str,
    session: Optional[requests.Session] = None,
    logger: Optional[logging.Logger] = None,
    POOL_SIZE: int = 10,
    timeout: Tuple[float,float] = (300,300),
    adapter_retry_total: int = 2
) -> Optional[DocumentIntelligenceClient]:
    """
    Creates a DocumentIntelligenceClient with the endpoint/key supplied by the caller.
    Returns None if creation fails.
    """
    log = logger or logging.getLogger(__name__)
    try:
        if not di_endpoint or not di_key:
            log.error("Cannot create DI client: endpoint or key missing.")
            return None

        if session is None:
            session = requests.Session()
        try:
            session.trust_env = False
        except Exception as e:
            log.exception("Failed to set trust_env on session: %s", e)
        
        # Retry policy for the adapter (idempotent GET/POST with backoff)
        retry_cfg = Retry(
            total=adapter_retry_total,            # max retries across all types
            connect=adapter_retry_total,          # connection errors
            read=adapter_retry_total,             # read timeouts
            backoff_factor=0.5,                   # exponential backoff base
            status_forcelist=[408, 500, 502, 503, 504],
            allowed_methods=frozenset(["GET", "POST"]),
            respect_retry_after_header=True
        )


        # Size the pool to your concurrency with a buffer
        adapter = HTTPAdapter(pool_connections=POOL_SIZE, pool_maxsize=POOL_SIZE, max_retries=retry_cfg)
        session.mount("http://", adapter)
        session.mount("https://", adapter)

        transport = RequestsTransport(session=session
                                      , connection_pool_maxsize=POOL_SIZE
                                      , connection_timeout = timeout[0]
                                      , read_timeout = timeout[1])
        client = DocumentIntelligenceClient(
            endpoint=di_endpoint,
            credential=AzureKeyCredential(di_key),
            transport=transport,
        )
        return client
    except Exception as e:
        log.exception("Failed to create DocumentIntelligenceClient: %s", e)
        return None


# -------------
# Helper funcs
# -------------
IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp", ".gif", ".webp"}

def is_pdf(path: Path) -> bool:
    try:
        return path.suffix.lower() == ".pdf"
    except Exception:
        return False

def is_image(path: Path) -> bool:
    try:
        return path.suffix.lower() in IMAGE_EXTS
    except Exception:
        return False

def make_page_key(file_path: Path, page_num: Optional[int]) -> str:
    """
    Returns a stable, human-readable key:
      - PDF: '<basename>_page_<n>'
      - Image: '<basename>'
    """
    try:
        base = file_path.stem
        return f"{base}" if page_num is None else f"{base}_page_{page_num}"
    except Exception:
        return f"unknown_{random.randint(1, 999999)}"

def read_file_bytes(path: Path, logger: Optional[logging.Logger] = None) -> Optional[BytesIO]:
    log = logger or logging.getLogger(__name__)
    try:
        with open(path, "rb") as f:
            b = f.read()
        bio = BytesIO(b)
        bio.seek(0)
        return bio
    except Exception as e:
        log.exception("Failed to read file bytes %s: %s", path, e)
        return None

def guess_content_type(file_name: str, default: str = "application/octet-stream") -> str:
    try:
        ct, _ = mimetypes.guess_type(file_name)
        return ct or default
    except Exception:
        return default


# -------------------
# PDF page extraction
# -------------------
def split_pdf_to_pages_bytes_with_fitz(
    pdf_path: Path, logger: Optional[logging.Logger] = None
) -> Tuple[List[Tuple[int, BytesIO]], bool]:
    """
    Returns (pages_bytes, had_split_error).
    - pages_bytes: list of (page_num, BytesIO) for each successfully split page
    - had_split_error: True if *any* page failed to split OR the PDF failed to open
    """
    log = logger or logging.getLogger(__name__)
    pages_bytes: List[Tuple[int, BytesIO]] = []
    had_split_error = False
    src = None

    try:
        src = fitz.open(str(pdf_path))
    except Exception as e:
        log.exception("Failed to open PDF %s: %s", pdf_path, e)
        # Opening failed => no pages, mark as split error
        return [], True

    try:
        for i in range(src.page_count):
            single = None
            try:
                single = fitz.open()
                single.insert_pdf(src, from_page=i, to_page=i)
                pdf_bytes = single.tobytes()
                bio = BytesIO(pdf_bytes)
                bio.seek(0)
                pages_bytes.append((i + 1, bio))
            except Exception as e:
                had_split_error = True
                log.exception("Failed to split PDF %s page %s: %s", pdf_path, i + 1, e)
            finally:
                try:
                    if single:
                        single.close()
                except Exception:
                    pass
    finally:
        try:
            if src:
                src.close()
        except Exception:
            pass

    return pages_bytes, had_split_error


# --------------
# Classification
# --------------
def classify_stream(
    client: DocumentIntelligenceClient,
    stream: BytesIO,
    content_type: str,
    classifier_id: str,
    logger: Optional[logging.Logger] = None,
) -> Any:
    """
    Calls Azure Document Intelligence classification on the given stream.
    Returns result or raises exception (caller handles).
    """
    log = logger or logging.getLogger(__name__)
    if not classifier_id:
        raise RuntimeError("Classifier model id is missing")
    if client is None:
        raise RuntimeError("DocumentIntelligenceClient is None")

    try:
        stream.seek(0)
    except Exception as e:
        log.exception("Failed to seek stream: %s", e)
        raise

    try:
        poller = client.begin_classify_document(
            classifier_id=classifier_id,
            body=stream,
            content_type=content_type,
        )
    except Exception as e:
        log.exception("begin_classify_document failed: %s", e)
        raise

    try:
        result = poller.result()
        return result
    except Exception as e:
        log.exception("Polling result for classify failed: %s", e)
        raise


def gather_inputs_recursive(root_dir: Path, logger: Optional[logging.Logger] = None) -> List[Path]:
    log = logger or logging.getLogger(__name__)
    files: List[Path] = []
    try:
        if not root_dir or not root_dir.exists():
            log.error("Input root dir missing or does not exist: %s", root_dir)
            return files
        for p in root_dir.rglob("*"):
            try:
                if p.is_file() and (is_pdf(p) or is_image(p)):
                    files.append(p)
            except Exception as e:
                log.exception("Error while scanning path %s: %s", p, e)
    except Exception as e:
        log.exception("Failed to gather inputs recursively: %s", e)
    return files


def classify_pdf_pages(
    client: DocumentIntelligenceClient,
    pdf_path: Path,
    root_dir: Path,
    classifier_id: str,
    logger: Optional[logging.Logger] = None,
) -> List[Dict[str, Any]]:
    log = logger or logging.getLogger(__name__)
    outputs: List[Dict[str, Any]] = []
    had_split_error = False

    # Split pages
    try:
        page_streams, had_split_error = split_pdf_to_pages_bytes_with_fitz(pdf_path, logger=log)
    except Exception as e:
        # Defensive: if split function itself threw, mark failure and continue
        log.exception("Failed splitting PDF %s: %s", pdf_path, e)
        page_streams, had_split_error = [], True

    content_type = "application/pdf"

    # Treat as classification failure only if *no pages* are available.
    if not page_streams:
        log.warning("No page streams available for %s", pdf_path)
        return [{
            "file_path": os.path.relpath(str(pdf_path), start=str(root_dir)),
            "page_num": None,
            "page_key": make_page_key(pdf_path, None),
            "error": "No pages available (open/split failure)",
            "is_pdf": True,
        }]

    # If some pages split and some didn't, proceed with the available ones.
    if had_split_error:
        log.warning("Partial split errors for %s: proceeding with %d pages", pdf_path, len(page_streams))

    
    # ======= Skip classification if classifier_id is None or empty =======
    if not classifier_id:
        log.info("Classifier id is empty/None; skipping classification for %s", pdf_path)
        for page_num, stream in page_streams:
            outputs.append({
                "file_path": os.path.relpath(str(pdf_path), start=str(root_dir)),
                "page_num": str(page_num),
                "page_key": make_page_key(pdf_path, page_num),
                "page_stream": stream,
                "content_type": content_type,
                "is_pdf": True,
                "skipped_classification": True,  # <-- marker for downstream routing
            })
        try:
            outputs.sort(key=lambda x: int(x.get("page_num") or 10**9))
        except Exception as e:
            log.exception("Failed to sort outputs for %s: %s", pdf_path, e)
        return outputs

    # Classify page-by-page in parallel
    try:
        page_workers = min(len(page_streams), max(1, (os.cpu_count() or 4)))
    except Exception:
        page_workers = 1

    try:
        with ThreadPoolExecutor(max_workers=page_workers) as executor:
            futures = {}
            try:
                for page_num, stream in page_streams:
                    futures[executor.submit(
                        classify_stream, client, stream, content_type, classifier_id, log
                    )] = (page_num, stream)
            except Exception as e:
                log.exception("Failed to submit classification futures: %s", e)

            for fut in as_completed(futures):
                page_num, stream = futures.get(fut, (None, None))
                try:
                    result = fut.result()
                    outputs.append({
                        "file_path": os.path.relpath(str(pdf_path), start=str(root_dir)),
                        "page_num": str(page_num),
                        "page_key": make_page_key(pdf_path, page_num),
                        "classification_result": result,
                        "page_stream": stream,
                        "is_pdf": True,
                    })
                except Exception as e:
                    log.exception("Classification failed for %s page %s", pdf_path, page_num)
                    outputs.append({
                        "file_path": os.path.relpath(str(pdf_path), start=str(root_dir)),
                        "page_num": str(page_num),
                        "page_key": make_page_key(pdf_path, page_num),
                        "error": str(e),
                        "is_pdf": True,
                    })
    except Exception as e:
        log.exception("ThreadPool for classify_pdf_pages failed: %s", e)

    try:
        outputs.sort(key=lambda x: x.get("page_num", 10**9))
    except Exception as e:
        log.exception("Failed to sort outputs for %s: %s", pdf_path, e)
    return outputs


def classify_image_file(
    client: DocumentIntelligenceClient,
    image_path: Path,
    root_dir: Path,
    classifier_id: str,
    logger: Optional[logging.Logger] = None,
) -> Dict[str, Any]:
    log = logger or logging.getLogger(__name__)
    stream = read_file_bytes(image_path, logger=log)
    if stream is None:
        return {
            "file_path": os.path.relpath(str(image_path), start=str(root_dir)),
            "page_num": "",
            "page_key": make_page_key(image_path, None),
            "error": "Failed to read image bytes",
            "is_pdf": False,
        }

    content_type = guess_content_type(image_path.name, default="image/*")

    # ======= Skip classification if classifier_id is None or empty =======
    if not classifier_id:
        log.info("Classifier id is empty/None; skipping classification for image %s", image_path)
        return {
            "file_path": os.path.relpath(str(image_path), start=str(root_dir)),
            "page_num": "",
            "page_key": make_page_key(image_path, None),
            "page_stream": stream,
            "content_type": content_type,
            "is_pdf": False,
            "skipped_classification": True,  # <-- marker for downstream routing
        }
    
    try:
        result = classify_stream(client, stream, content_type, classifier_id, log)
        return {
            "file_path": os.path.relpath(str(image_path), start=str(root_dir)),
            "page_num": "",
            "page_key": make_page_key(image_path, None),
            "classification_result": result,
            "page_stream": stream,
            "is_pdf": False,
        }
    except Exception as e:
        log.exception("Classification failed for image %s", image_path)
        return {
            "file_path": os.path.relpath(str(image_path), start=str(root_dir)),
            "page_num": "",
            "page_key": make_page_key(image_path, None),
            "error": str(e),
            "is_pdf": False,
        }


def classify_inputs_in_recursive_folder(
    root_dir: Path,
    client: DocumentIntelligenceClient,
    classifier_id: str,
    logger: Optional[logging.Logger] = None,
    max_workers_files: Optional[int] = None,
) -> List[Dict[str, Any]]:
    """
    Recursively processes all PDFs and images under root_dir.
    Returns a flat list of outputs (dicts).
    """
    log = logger or logging.getLogger(__name__)
    if client is None:
        log.error("Cannot classify: DI client is None.")
        return []

    inputs: List[Path] = gather_inputs_recursive(root_dir, logger=log)
    if not inputs:
        log.warning("No input files found under %s", root_dir)
        return []

    outputs: List[Dict[str, Any]] = []

    try:
        file_workers = max_workers_files or (os.cpu_count() or 4)
        file_workers = max(1, file_workers)
    except Exception:
        file_workers = 1

    try:
        with ThreadPoolExecutor(max_workers=file_workers) as executor:
            futures: Dict[Any, Tuple[str, Path]] = {}
            try:
                for path in inputs:
                    if is_pdf(path):
                        openable, is_encrypted, err_msg = _preflight_pdf_openable(path, logger=log)
                        if not openable:
                            reason = err_msg or "Unopenable: unknown error"

                            outputs.append({
                                "file_path": os.path.relpath(str(path), start=str(root_dir)),
                                "page_num": "",
                                "page_key": make_page_key(path, None),
                                "error": f"PDF open failed: {reason}",
                                "reason": "Password required" if is_encrypted else "Cannot be opened",
                                "is_pdf": True,
                                "is_encrypted": is_encrypted,
                            })
                            log.error("Preflight failed for %s: %s", path, reason)
                            continue

                        futures[executor.submit(
                            classify_pdf_pages, client, path, root_dir, classifier_id, log
                        )] = ("pdf", path)
                    else:
                        futures[executor.submit(
                            classify_image_file, client, path, root_dir, classifier_id, log
                        )] = ("image", path)
            except Exception as e:
                log.exception("Failed to submit file-level futures: %s", e)

            for fut in as_completed(futures):
                kind, path = futures.get(fut, ("unknown", Path("")))
                try:
                    res = fut.result()
                    if kind == "pdf" and isinstance(res, list):
                        outputs.extend(res)
                    elif kind == "image" and isinstance(res, dict):
                        outputs.append(res)
                    else:
                        outputs.append({
                            "file_path": os.path.relpath(str(path), start=str(root_dir)),
                            "page_num": "",
                            "page_key": make_page_key(path, None),
                            "error": f"Unexpected result type for {kind}: {type(res)}",
                            "is_pdf": is_pdf(path),
                        })
                except Exception as e:
                    log.exception("Top-level classification failed for %s", path)
                    outputs.append({
                        "file_path": os.path.relpath(str(path), start=str(root_dir)),
                        "page_num": "",
                        "page_key": make_page_key(path, None),
                        "error": str(e),
                        "is_pdf": is_pdf(path),
                    })
    except Exception as e:
        log.exception("ThreadPool for classify_inputs_in_recursive_folder failed: %s", e)

    try:
        def sort_key(item: Dict[str, Any]) -> Tuple[str, int]:
            return (item.get("file_path", ""), item.get("page_num") or 10**9)
        outputs.sort(key=sort_key)
    except Exception as e:
        log.exception("Failed sorting final outputs: %s", e)

    return outputs


# -------------
# Extraction
# -------------
def analyze_page_with_retry(
    client: DocumentIntelligenceClient,
    model_id: str,
    page_key: str,
    stream: BytesIO,
    content_type: str,
    logger: Optional[logging.Logger] = None,
    max_attempts: int = 2
) -> Tuple[str, Any]:
    log = logger or logging.getLogger(__name__)
    if client is None:
        raise RuntimeError("DocumentIntelligenceClient is None")
    if not model_id:
        raise RuntimeError("model_id is required for analyze")

    attempt = 0
    while True:
        try:
            stream.seek(0)
        except Exception as e:
            log.exception("Failed to seek stream for %s: %s", page_key, e)
            raise

        try:
            poller = client.begin_analyze_document(
                model_id=model_id,
                body=stream,
                content_type=content_type
            )
        except Exception as e:
            attempt += 1
            if attempt >= max_attempts:
                log.exception("begin_analyze_document failed and exceeded retries for %s: %s", page_key, e)
                raise
            wait = (2 ** attempt) + random.uniform(0, 0.5)
            log.warning("Analyze begin failed (attempt %s) for %s: %s; retrying in %.2fs",
                        attempt, page_key, e, wait)
            time.sleep(wait)
            continue

        try:
            result = poller.result()
            return page_key, result.as_dict()
        except HttpResponseError as e:
            attempt += 1
            if attempt >= max_attempts:
                log.exception("Analyze polling failed and exceeded retries for %s: %s", page_key, e)
                raise
            wait = (2 ** attempt) + random.uniform(0, 0.5)
            log.warning("Analyze failed (attempt %s) for %s: %s; retrying in %.2fs",
                        attempt, page_key, e, wait)
            time.sleep(wait)
        except Exception as e:
            attempt += 1
            if attempt >= max_attempts:
                log.exception("Analyze (non-HttpResponseError) exceeded retries for %s: %s", page_key, e)
                raise
            wait = (2 ** attempt) + random.uniform(0, 0.5)
            log.warning("Analyze (non-HttpResponseError) (attempt %s) for %s: %s; retrying in %.2fs",
                        attempt, page_key, e, wait)
            time.sleep(wait)


def _extract_model_map_entry(doc_type: str, model_map: Dict[str, Any]) -> Tuple[Optional[str], Optional[str]]:
    try:
        entry = model_map.get(doc_type)
        if entry is None:
            return None, None
        if isinstance(entry, dict):
            return entry.get("modelId"), entry.get("transactionType")
        if isinstance(entry, (list, tuple)) and len(entry) >= 2:
            return entry[0], entry[1]
        if isinstance(entry, str):
            return entry, None
    except Exception:
        pass
    return None, None


def analyze_class_groups_in_parallel(
    grouped_by_class: Dict[str, Dict[str, Tuple[BytesIO, str]]],
    model_map: Dict[str, Any],
    client: DocumentIntelligenceClient,
    logger: Optional[logging.Logger] = None,
    max_workers: int = 4,
) -> Tuple[Dict[str, List[Dict[str, Any]]], List[Dict[str,Any]]]:
    """
    Returns (all_results, failed_extraction_files)
    """
    log = logger or logging.getLogger(__name__)
    if client is None:
        log.error("Cannot analyze: DI client is None.")
        return {}, []

    all_results: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    failed_extraction_files: List[Dict[str, Any]] = []

    try:
        for doc_type, pages_dict in grouped_by_class.items():
            try:
                if doc_type == "Unused":
                    log.info("Skipping 'Unused' class")
                    continue
                if doc_type == "unknown_or_unused_from_azure":
                    log.info("Skipping 'unknown_or_unused_from_azure' class")
                    continue

                model_id, transaction_type = _extract_model_map_entry(doc_type, model_map)
                if not model_id:
                    log.warning("No extraction model mapped for doc_type: %s", doc_type)
                    continue

                tx_type_label = transaction_type or "Uncategorized"
                log.info("== Analyzing class '%s' (tx='%s') via model '%s' (%d page(s)) ==",
                         doc_type, tx_type_label, model_id, len(pages_dict))

                workers = min(max(1, len(pages_dict)), max_workers)

                try:
                    with ThreadPoolExecutor(max_workers=workers) as executor:
                        futures = {}
                        try:
                            for page_key, (stream, file_path) in pages_dict.items():
                                content_type = "application/pdf" if "_page_" in page_key else "image/*"
                                fut = executor.submit(
                                    analyze_page_with_retry,
                                    client, model_id, page_key, stream, content_type, log
                                )
                                futures[fut] = (page_key, file_path)
                        except Exception as e:
                            log.exception("Failed to submit analyze futures for doc_type %s: %s", doc_type, e)

                        for fut in as_completed(futures):
                            page_key_meta, file_path_meta = futures.get(fut, (None, None))
                            try:
                                page_key_res, analyze_result = fut.result()

                                match = re.search(r"_page_(\d+)$", page_key_res)
                                page_num = str(match.group(1)) if match else ""

                                all_results[tx_type_label].append({
                                    "page_key": page_key_res,
                                    "page_num": page_num,
                                    "file_path": file_path_meta,  # relative (propagated earlier)
                                    "model_id": model_id,
                                    "doc_type": doc_type,
                                    "analyze_result": analyze_result
                                })
                            except Exception as e:
                                if file_path_meta:
                                    failed_extraction_files.append({
                                        "file_path": file_path_meta,
                                        "page_num": page_num
                                        })
                                log.exception("Analyze failed in class '%s' for page_key=%s", doc_type, page_key_meta)
                                all_results[tx_type_label].append({
                                    "page_key": page_key_meta,
                                    "page_num": page_num,
                                    "file_path": file_path_meta,
                                    "model_id": model_id,
                                    "doc_type": doc_type,
                                    "error": str(e)
                                })
                except Exception as e:
                    log.exception("ThreadPool for analyze_class_groups failed: %s", e)

                try:
                    all_results[tx_type_label].sort(key=lambda x: x.get("page_key") or "")
                except Exception as e:
                    log.exception("Failed sorting results for tx '%s': %s", tx_type_label, e)

            except Exception as e:
                log.exception("Analyze loop failed for doc_type '%s': %s", doc_type, e)
    except Exception as e:
        log.exception("Analyze class groups outer loop failed: %s", e)

    return all_results, failed_extraction_files


# -----------
# Orchestral
# -----------
def ocr_extraction_main(
    logger: logging.Logger,
    di_endpoint: str,
    di_key: str,
    classifier_id: str,
    model_ids: Dict[str, Any],
    cache_inputs_dir: Path,
    POOL_SIZE: int = 10,
    timeout: Tuple[float,float] = (300,300),
    adapter_retry_total: int = 2,
    Doc_Classification_Confidence_Threshold: float = 0.6
) -> Dict[str, Any]:
    """
    Orchestrates classification and analysis using injected dependencies.
    Returns an object with extraction_results and file tracking lists; never raises.
    """
    log = logger or logging.getLogger(__name__)
    extraction_results: Dict[str, List[Dict[str, Any]]] = {}


    successful_extraction_files: List[Dict[str, Any]] = []
    failed_classification_files: List[Dict[str, Any]] = []
    failed_extraction_files: List[Dict[str, Any]] = []
    unknown_or_unused_from_azure: List[Dict[str, Any]] = []
    encrypted_pdf_files: List[Dict[str, Any]] = []

    try:
        root = cache_inputs_dir
        if root is None or not isinstance(root, Path):
            log.error("cache_inputs_dir is not configured; aborting.")
            return {
                "extraction_results": {},
                "successful_OCR_extraction_files": [],
                "failed_classification_files": [],
                "failed_extraction_files": [],
                "unknown_or_unused_from_azure": [],
                "encrypted_pdf_files": [],
            }

        # Network/session
        session = None
        try:
            session = requests.Session()
            session.trust_env = False
        except Exception as e:
            log.exception("Failed to create requests session: %s", e)

        client = create_di_client(di_endpoint, di_key, session=session, logger=log, POOL_SIZE=POOL_SIZE, timeout=timeout, adapter_retry_total=adapter_retry_total)
        if client is None:
            log.error("Client creation failed; aborting.")
            return {
                "extraction_results": {},
                "successful_OCR_extraction_files": [],
                "failed_classification_files": [],
                "failed_extraction_files": [],
                "unknown_or_unused_from_azure": [],
                "encrypted_pdf_files": [],
            }

        # 1) Classify documents
        try:
            results = classify_inputs_in_recursive_folder(
                root_dir=root,
                client=client,
                classifier_id=classifier_id,
                logger=log
            )
        except Exception as e:
            log.exception("Classification step failed: %s", e)
            results = []

        for r in results:
            try:
                if "error" in r:
                    if r.get("file_path"):
                        if r.get("is_pdf") and r.get("page_num"):
                            rec = {
                                "file_path": r["file_path"], 
                                "page_num": r.get("page_num"),
                                "error": r.get("error"),
                                "reason": r.get("reason")
                                }
                        else:
                            rec = {
                                "file_path": r["file_path"], 
                                "error": r.get("error"),
                                "reason": r.get("reason")
                                }
                        if r.get("is_pdf") and r.get("is_encrypted"):  
                            encrypted_pdf_files.append(rec) 
                        else:            
                            failed_classification_files.append(rec)
                  

                    log.error("%s (page %s) -> %s", r.get("file_path"), r.get("page_num"), r.get("error"))
                else:
                    log.info("[OK] %s (page %s) -> key=%s", r.get("file_path"), r.get("page_num"), r.get("page_key"))
            except Exception:
                pass

        # 2) Group for extraction
        grouped_by_class: Dict[str, Dict[str, Tuple[BytesIO, str]]] = defaultdict(dict)
        try:
            for item in results:
                try:
                    if "error" in item:
                        log.error("Skipping due to classification error: %s", item.get("error"))
                        continue

                    page_num = item.get("page_num")
                    page_key = item.get("page_key")
                    page_stream = item.get("page_stream")
                    file_path = item.get("file_path")  # already relative from classify stage
                    result = item.get("classification_result")
                    
                    # ======= Accept skipped classification items =======
                    if item.get("skipped_classification"):
                        # Drop into a neutral bin for later mapping (works if model_ids has this key):
                        grouped_by_class["Neutral"][page_key] = (page_stream, file_path)
                        continue

                    if page_key is None or page_stream is None or result is None:
                        log.warning("Incomplete classification item; skipping: %s", item)
                        continue

                    docs = getattr(result, "documents", None) or []
                    try:
                        if not isinstance(docs, (list, tuple)):
                            docs = list(docs) if docs else []
                    except Exception:
                        docs = []

                    if not docs:
                        log.warning("No documents in classification result for %s", page_key)
                        continue

                    for doc in docs:
                        try:
                            doc_type = getattr(doc, "doc_type", None)
                            confidence = getattr(doc, "confidence", None)
                            model_id_used = getattr(result, "model_id", None)

                            log.info("-------- %s --------", page_key)
                            log.info("Type: %s | Confidence: %s | Classifier Model ID: %s",
                                     doc_type, confidence, model_id_used)
                            
                            # Check Classification Confindence and group by class
                            if doc_type:
                                if confidence >= Doc_Classification_Confidence_Threshold:
                                    grouped_by_class[doc_type][page_key] = (page_stream, file_path)
                                    if doc_type == "Unused":
                                    # Also append unused pages for tracability
                                        unknown_or_unused_from_azure.append({
                                            "file_path": file_path, 
                                            "page_num": page_num,
                                            "reason": "Unused Document"
                                            })
                                else:
                                    # Throw the doc into unknown_or_unused_from_azure doc bin
                                    grouped_by_class["unknown_or_unused_from_azure"][page_key] = (page_stream, file_path)
                                    unknown_or_unused_from_azure.append({
                                        "file_path": file_path, 
                                        "page_num": page_num,
                                        "reason": "Unknown Document",
                                        "classification_confidence": confidence
                                        })
                        except Exception as e:
                            log.exception("Failed to process doc entry for %s: %s", page_key, e)
                except Exception as e:
                    log.exception("Failed processing classification item: %s", e)
        except Exception as e:
            log.exception("Grouping for extraction failed: %s", e)

        try:
            log.info("-----------------------------------")
            for doc_type, page_dict in grouped_by_class.items():
                log.info("Class '%s' has %d page(s) ready for extraction.", doc_type, len(page_dict))
            log.info("-----------------------------------")
        except Exception:
            pass

        # 3) Analyze (extraction) per page in parallel, class-by-class
        try:
            extraction_results, failed_extraction_files_from_func = analyze_class_groups_in_parallel(
                grouped_by_class=grouped_by_class,
                model_map=model_ids,
                client=client,
                logger=log,
                max_workers=4,
            )
            failed_extraction_files.extend(failed_extraction_files_from_func)
        except Exception as e:
            log.exception("Extraction step failed: %s", e)
            extraction_results = {}

        # Success tracking & summary
        try:
            for tx_type, items in extraction_results.items():
                for it in items:
                    if "analyze_result" in it and it.get("file_path"):
                        if it.get("page_num"):
                            successful_extraction_files.append({
                                "file_path": it.get("file_path"), 
                                "page_num": it.get("page_num")
                                })
                        else:
                            successful_extraction_files.append({
                                "file_path": it.get("file_path")
                                })
                ok = sum(1 for it in items if "analyze_result" in it)
                err = sum(1 for it in items if "error" in it)
                log.info("Tx '%s': %d success / %d errors", tx_type, ok, err)
        except Exception as e:
            log.exception("Failed printing summary: %s", e)

    except Exception as e:
        log.exception("Fatal error in ocr_extraction_main: %s", e)

    return {
        "extraction_results": extraction_results,
        "successful_OCR_extraction_files": successful_extraction_files,
        "failed_OCR_classification_files": failed_classification_files,
        "failed_OCR_extraction_files": failed_extraction_files,
        "unknown_or_unused_from_azure": unknown_or_unused_from_azure,
        "encrypted_pdf_files": encrypted_pdf_files,
    }