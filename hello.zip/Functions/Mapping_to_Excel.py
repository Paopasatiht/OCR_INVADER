# ----------------------------
# Main OCR to Excel transform
# ----------------------------
# pipeline/build_dataframe.py
from __future__ import annotations
from typing import Any, Dict, List, Union, Optional, Iterable, Tuple
from pathlib import Path
import logging
import pandas as pd
import configparser
from Functions.mappers.base import TransactionFormMapper, records_to_dataframe
# single transaction
from Functions.mappers.single_transaction_OCR import SingleTransactionFormMapper

# slip transaction
from Functions.mappers.slip_transaction_OCR import SlipTransactionFormMapper

# multi transaction
from Functions.mappers.multiple_transaction_OCR import MultipleTransactionFormMapper

# Generic Excel mapper (schema-driven)
from Functions.mappers.excel_transaction import OtherExcelDirectoryMapper

# FINNET transaction
from Functions.mappers.FINNET_transaction import FINNETExcelMapper, FINNETTransactionRecord, save_finnet_records_to_excel
from Functions.mappers.base import FINNETMapResult  # for type clarity


def select_mapper(
    source_kind: str, # lower case handled at top level
    config_path: Path,
    log: logging.Logger,
    mapping_config_path: Optional[Path] = None # pointer to schema for further mapping, not required by single transaction doc
) -> TransactionFormMapper:
    """
    Choose mapper by source kind.
    - 'single'   : SingleTransactionFormMapper
    - 'multiple' : MultipleTransactionFormMapper
    - 'finnet'   : FINNETExcelMapper
    - 'excel'    : OtherExcelDirectoryMapper
    - 'slip'     : SlipTransactionFormMapper
    """
    kind = source_kind.lower()
    if kind == "single":
        return SingleTransactionFormMapper(config_path, log)
    if kind == "multiple":
        # Placeholder for future DI mapper
        return MultipleTransactionFormMapper(
            config_path=config_path,
            log=log,
        )
    if kind == "finnet":
        # FINNET mapper uses JSON column config + shared mappings
        return FINNETExcelMapper(config_path=config_path, log=log, mapping_config_path=mapping_config_path)
    if kind == "excel":
        # For non-FINNET Excel files (schema-driven)
        return OtherExcelDirectoryMapper(
            config_path=config_path,
            log=log,
        )
    if kind == "slip":
        return SlipTransactionFormMapper(config_path, log)
    else:
        raise ValueError(f"Unknown source_kind: {source_kind}")
    
# -------------------------------------------------------------------------
# Docs that requires OCR helpers
# -------------------------------------------------------------------------

def build_dataframe_from_extractions_OCR(
    extraction_results: Dict[str, Any],
    source_kind: str,
    config_path: Path,
    log: logging.Logger
) -> Tuple[pd.DataFrame, List[Dict[str,Any]]]:
    """
    Build a normalized DataFrame by delegating to the DI mapper for OCR docs.
    The `extraction_results` must be of the form:
        { "extraction_results": { KindCapitalized: payload } }
    where KindCapitalized matches the DI bucket name ("Single", "Multiple", ...).
    """
    mapper = select_mapper(source_kind, config_path, log)
    records, failed_files = mapper.map(extraction_results)
    df = records_to_dataframe(records)

    return df, failed_files
# -------------------------------------------------------------------------
# Other Excels helpers
# -------------------------------------------------------------------------
def build_dataframe_from_excel_files(
    excel_paths: List[Union[str, Path]],
    config_path: Path,
    log: logging.Logger,
    input_dir: Path
) -> Tuple[pd.DataFrame, List[Dict[str,Any]]]:
    """
    Generic builder for schema-driven Excel files.
    - Scans all schemas under Config/mapping_config/other_excels/**/schema.json
    - Matches each Excel by header_row_index + normalized columns
    - Uses mapping_config to map fields
    - Returns combined DataFrame of TransactionRecords
    """
    mapper = select_mapper("excel", config_path, log)

    df_list: List[pd.DataFrame] = []
    failed_files: List[Dict[str,Any]] = []

    normalized_paths = [Path(p) for p in excel_paths if Path(p).exists() and Path(p).is_file()]

    if not normalized_paths:
        log.warning("Excel: No valid files; returning empty DataFrame.")
        return (pd.DataFrame(), failed_files)

    for path in normalized_paths:
        try:
            log.info("Excel mapping: %s", path)
            records = mapper.map(path, input_dir)  # agent derived from path internally
            if records == "no_schema":
                log.warning("Excel mapper returned no records for %s, skipping.", path)
                failed_files.append({
                    "file_path": str(path.relative_to(input_dir)),
                    "reason": "No schema found"
                    })
            elif records:
                df = records_to_dataframe(records)
                df_list.append(df)
            else:
                log.warning("Excel mapper returned no records for %s, skipping.", path)
                failed_files.append({
                    "file_path": str(path.relative_to(input_dir)),
                    "reason": "No record"
                    })
        except Exception as e:
            log.exception("Excel mapping failed for %s: %s", path, e)
            failed_files.append({
                    "file_path": str(path.relative_to(input_dir)),
                    "reason": "Mapping failed"
                    })
    
    if df_list:
        combined = pd.concat(df_list, ignore_index=True)
        log.info("Excel DataFrame built (rows=%d).", len(combined))
        return combined, failed_files
    else:
        log.info("Excel DataFrame built (rows=0).")
        return pd.DataFrame(), failed_files

# -------------------------------------------------------------------------
# FINNET Excels helpers
# -------------------------------------------------------------------------
def _normalize_path_payload(
    payload: Any,
    log: logging.Logger
) -> List[Path]:
    """
    Convert payload into a list[Path], filtering to existing files only.
    Accepts a single path or an iterable of paths.
    """
    if payload is None:
        log.warning("FINNET payload is None; skipping.")
        return []

    candidates: Iterable[Any]
    if isinstance(payload, (str, Path)):
        candidates = [payload]
    elif isinstance(payload, Iterable):
        candidates = payload
    else:
        log.warning("FINNET payload must be a path or list of paths; got: %r", type(payload))
        return []

    paths: List[Path] = []
    for p in candidates:
        try:
            pp = Path(p)
            if pp.exists() and pp.is_file():
                paths.append(pp)
            else:
                log.warning("FINNET file not found or not a file: %s", pp)
        except Exception as e:
            log.warning("FINNET payload path invalid: %r (%s)", p, e)

    return paths


def build_dataframe_from_finnet_excels(
    excel_paths: List[Union[str, Path]],
    config_path: Path,
    log: logging.Logger,
    outputs_dir: Optional[Path],
    input_dir: Path,
    today: str = ""
) -> Tuple[pd.DataFrame, List[Dict[str,Any]]]:
    """
    Special-case builder for FINNET: given a list of Excel paths,
    run FINNETExcelMapper.map(path), consolidate success/pending excels,
    and return a combined DataFrame built from `result.records`.

    - Consolidated Excels written as:
        success_transactions.xlsx
        pending_transactions.xlsx
      Saved under `outputs_dir` if provided; otherwise in CWD.

    - DataFrame lineage columns added:
    """
    cfg = configparser.ConfigParser()
    cfg.read(str(config_path))
    mapper = select_mapper("finnet", config_path, log, 
                           mapping_config_path=Path(cfg.get("Local_Paths", "FINNET_mapping_DICT", fallback="Config\\mapping_config\\FINNET\\finnet_excel_config.json")))

    # Accumulators for explicit excel outputs
    finnet_success_all: List[FINNETTransactionRecord] = []
    finnet_pending_all: List[FINNETTransactionRecord] = []

    # DataFrames to combine
    df_list: List[pd.DataFrame] = []
    failed_files: List[Dict[str,Any]] = []
    normalized_paths = [Path(p) for p in excel_paths if Path(p).exists() and Path(p).is_file()]
    if not normalized_paths:
        log.warning("FINNET: No valid Excel files; returning empty DataFrame.")
        return (pd.DataFrame(), failed_files)

    for path in normalized_paths:
        try:
            log.info("FINNET mapping: %s", path)
            result: FINNETMapResult = mapper.map(path, input_dir, today)

            current_date = f"{today[:4]}-{today[4:6]}-{today[6:]}"

            # Append success/pending transactions for consolidated excels (defensive defaults)
            finnet_success_all.extend(getattr(result, "success_transactions", []) or [])
            finnet_pending_all.extend(getattr(result, "pending_transactions", []) or [])

            # Convert result.records (list[TransactionRecord]) to DataFrame
            if result.records:
                df = records_to_dataframe(result.records)
                df_list.append(df)
            else:
                log.warning("FINNET result.records is empty for %s; skipping.", path)
                failed_files.append({
                    "file_path": str(path.relative_to(input_dir)), 
                    "reason": "No record"
                    })
        except Exception as e:
            log.exception("FINNET mapping failed for %s: %s", path, e)
            failed_files.append({
                "file_path": str(path.relative_to(input_dir)), 
                "reason": "Mapping failed"
                })
    # ---- Explicitly save consolidated excels ----
    try:
        success_excel = Path(f"FINNET_success_transactions_{current_date}.xlsx")
        pending_excel = Path(f"FINNET_pending_transactions_{current_date}.xlsx")

        if outputs_dir is not None:
            outputs_dir.mkdir(parents=True, exist_ok=True)
            success_excel = outputs_dir / success_excel.name
            pending_excel = outputs_dir / pending_excel.name

        save_finnet_records_to_excel(finnet_success_all, success_excel)
        save_finnet_records_to_excel(finnet_pending_all, pending_excel)
        log.info("FINNET wrote excels: %s, %s", success_excel, pending_excel)
    except Exception as e:
        log.exception("FINNET failed to write excel outputs: %s", e)

    if df_list:
        combined = pd.concat(df_list, ignore_index=True)
        log.info("FINNET DataFrame built (rows=%d).", len(combined))
        return (combined, failed_files)

    log.warning("FINNET: No DataFrames built from records; returning empty DataFrame.")
    return (pd.DataFrame(), failed_files)

# -------------------------------------------------------------------------
# All docs (OCR required, excels, FINNET)
# -------------------------------------------------------------------------

def build_all_dataframes_from_extractions(
    extraction_results: Dict[str, Any],
    config_path: Path,
    log: logging.Logger,
    inputs_dir: Path = None,  # <-- Used for saving relative path of fail files
    outputs_dir: Optional[Path] = None,  # <-- Used for FINNET Excel output location
    today: str = ""
) -> Tuple[Dict[str, pd.DataFrame], List[Dict[str,Any]]]:
    """
    Build a DataFrame for each source kind found in `extraction_results`.

    Returns:
        (dfs, failed_files)
        dfs: Dict[str, pd.DataFrame]
        failed_files: List[Dict[str,Any]] of relative paths that failed during mapping


    ---- Payload expectations by source kind ----

    1) Document Intelligence (DI) kinds (e.g., "Single", "Multiple"):
       These originate from Azure Document Intelligence OCR extraction results.
       Each DI kind payload must be the *raw* extraction payload for that kind,
       exactly as produced by your OCR pipeline.

       Expected structure:
           extraction_results = {
               "Single":   <single_kind_payload>,
               "Multiple": <multiple_kind_payload>,
               ...
           }

       How it is consumed:
       - For each DI kind, the mapper is called as:
             mapper.map({ "extraction_results": { KindCapitalized: payload } })
         where `KindCapitalized` must match the DI bucket name ("Single", "Multiple").
       - The mapper returns normalized records, which are converted via
         `records_to_dataframe(...)` to a DataFrame.

       Notes:
       - The exact schema of `<*_kind_payload>` depends on your DI pipeline’s output.
         It should be the same structure your mapper already expects.
       - Keys are case-insensitive when selecting the mapper, but the inner DI wrapper
         uses the capitalized key ("Single", "Multiple") to preserve existing behavior.

    2) Excels/FINNET kind:
       Excel and FINNET is handled differently because it reads directly files
       (not DI JSON payloads). The payload must be a list of Excel file paths
       (or a single path).

       Expected structure:
           extraction_results = {
               ...
               "FINNET": [<excel_path_1>, <excel_path_2>, ...]
               # or "FINNET": "<single_excel_path>"
           }
        (same with "Excel")

       For FINNET, extra saving behavior (Step 9 integrated here):
       - Map each Excel via `FINNETExcelMapper.map(path)`.
       - Consolidate and save:
             success_transactions.xlsx
             pending_transactions.xlsx
         (These are consolidated across all provided files. They will be saved in
          `outputs_dir` if provided; otherwise, in the current working directory.)
       - Build and return a combined `df_finnet` from `result.records`.
         Each row will include lineage columns:

    General:
    - If a kind has no implemented mapper, it will be skipped with a warning.
    - Empty payloads or invalid inputs will produce warnings and be skipped.
    """
    
    dfs: Dict[str, pd.DataFrame] = {}
    all_failed_files: List[Dict[str,Any]] = []

    if not extraction_results:
        log.warning("No extraction_results provided.")
        return dfs

    for kind, payload in extraction_results.items():
        kind_lower = kind.lower()
        # ---- Other excels branch ----
        
        if kind_lower == "excel":
            try:
                excel_paths = _normalize_path_payload(payload, log)
                if not excel_paths:
                    log.warning("Excel: No valid files in payload; skipping.")
                    continue

                df_excel, failed_excel = build_dataframe_from_excel_files(
                    excel_paths=excel_paths,
                    config_path=config_path,
                    log=log,
                    input_dir=inputs_dir
                )
                if not df_excel.empty:
                    dfs[kind_lower] = df_excel
                else:
                    log.warning("Excel DataFrame is empty; not adding to dfs.")
                all_failed_files.extend(failed_excel)
            except Exception as e:
                log.exception("Excel branch failed: %s", e)
            continue

        # ---- FINNET branch ----
        if kind_lower == "finnet":
            try:
                excel_paths = _normalize_path_payload(payload, log)
                if not excel_paths:
                    log.warning("FINNET: No valid Excel files in payload; skipping.")
                    continue

                df_finnet, failed_finnet = build_dataframe_from_finnet_excels(
                    excel_paths=excel_paths,
                    config_path=config_path,
                    log=log,
                    outputs_dir=outputs_dir,
                    input_dir = inputs_dir,
                    today = today
                )

                if not df_finnet.empty:
                    dfs[kind_lower] = df_finnet
                else:
                    log.warning("FINNET DataFrame is empty; not adding to dfs.")
                all_failed_files.extend(failed_finnet)
            except Exception as e:
                log.exception("FINNET branch failed: %s", e)

            continue  # proceed to next kind

        # ---- Default DI branch for other kinds ----

        try:
            wrapper = { "extraction_results": { kind.capitalize(): payload } }
            df, failed_OCR = build_dataframe_from_extractions_OCR(
                extraction_results=wrapper,
                source_kind=kind_lower,
                config_path=config_path,
                log=log
            )
            dfs[kind_lower] = df
            log.info("Built DataFrame for '%s' with %d rows.", kind, len(df))
        except ValueError:
            log.warning("No DI mapper implemented for kind: %s", kind)
        except Exception as e:
            log.exception("Failed to build DataFrame for '%s': %s", kind, e)
        all_failed_files.extend(failed_OCR)
    return dfs, all_failed_files

# -------------------------------------------------------------------------
# Persist an output DataFrame
# -------------------------------------------------------------------------

def save_dataframe_outputs(
    df: pd.DataFrame,
    outputs_dir: Path,
    base_name: str,
    log: logging.Logger,
    text_columns=("bank_code",)  # add more column names here if needed
) -> None:


    """
    Save the DataFrame to Excel (.xlsx) with openpyxl, and set specified columns
    to text format (num_format "@") so leading zeros are preserved in Excel.
    """
    try:
        outputs_dir.mkdir(parents=True, exist_ok=True)
        xlsx_path = outputs_dir / f"{base_name}.xlsx"

        # Write using openpyxl
        with pd.ExcelWriter(xlsx_path, engine="openpyxl") as writer:
            df.to_excel(writer, index=False, sheet_name="Sheet1")

            ws = writer.sheets["Sheet1"]

            # Build header -> column index map
            header_cells = next(ws.iter_rows(min_row=1, max_row=1, values_only=False))
            header_map = {cell.value: idx + 1 for idx, cell in enumerate(header_cells)}  # 1-based indices

            # Apply text number format to specified columns
            for col_name in text_columns:
                col_idx = header_map.get(col_name)
                if not col_idx:
                    continue
                for cell in ws.iter_rows(min_row=2, max_row=ws.max_row, min_col=col_idx, max_col=col_idx):
                    c = cell[0]
                    c.number_format = "@"  # text format; preserves leading zeros

        log.info("Saved DataFrame as Excel (openpyxl): %s", xlsx_path)

    except Exception as e:
        log.exception("Failed to save DataFrame outputs: %s", e)


