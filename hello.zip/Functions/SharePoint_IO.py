
# Functions/SharePoint_IO.py
import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Any, List, Optional, Tuple, Iterable
import os

import configparser
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry


# -----------------------------------------------------------------------------
# Endpoints & SharePoint paths
# -----------------------------------------------------------------------------
@dataclass(frozen=True)
class Endpoint:
    url: str
    x_api_key: str
    x_app_name: str


@dataclass(frozen=True)
class SharePointPaths:
    base_root: str
    site_url: str
    drive_name: str

    @staticmethod
    def from_config(cfg: configparser.ConfigParser) -> "SharePointPaths":
        sp = cfg["SharePoint_Paths"]
        return SharePointPaths(
            base_root=sp.get("base_root", "").rstrip("/"),
            site_url=sp.get("siteURL", ""),
            drive_name=sp.get("driveName", "")
        )

    def to_params(self) -> Dict[str, str]:
        return {"siteUrl": self.site_url, "driveName": self.drive_name}

    def join_base(self, relative_or_abs: str, *, absolute: bool) -> str:
        """
        Normalize SharePoint-style path, enforce forward slashes and a leading slash if absolute.
        For non-absolute, prepend base_root (matching original behavior).
        """
        p = relative_or_abs.replace("\\", "/").strip("/")
        if absolute:
            return f"/{p}" if not p.startswith("/") else p
        base = self.base_root.rstrip("/") if self.base_root else ""
        out = f"{base}/{p}" if base else f"/{p}"
        if not out.startswith("/"):
            out = "/" + out
        return out



def _build_session(cfg: configparser.ConfigParser) -> requests.Session:
    retries = Retry(
        total=cfg.getint("SharePoint_API_setting", "sharepoint_api_retry_total", fallback=3),
        backoff_factor=cfg.getfloat("SharePoint_API_setting", "sharepoint_api_backoff_factor", fallback=0.5),
        status_forcelist=(429, 500, 502, 503, 504),
        allowed_methods=frozenset(["GET", "POST"]),
        raise_on_status=False,
    )
    session = requests.Session()
    adapter = HTTPAdapter(max_retries=retries)
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    return session



# -----------------------------------------------------------------------------
# Client
# -----------------------------------------------------------------------------
class SharePointClient:
    def __init__(self, cfg: configparser.ConfigParser):
        self.cfg = cfg
        self.sp_paths = SharePointPaths.from_config(cfg)
        self.session = _build_session(cfg)
        self.download_ep = Endpoint(
            url=cfg.get("download", "URL"),
            x_api_key=cfg.get("download", "X_API_KEY"),
            x_app_name=cfg.get("download", "X_APP_NAME"),
        )
        self.listfile_ep = Endpoint(
            url=cfg.get("listfile", "URL"),
            x_api_key=cfg.get("listfile", "X_API_KEY"),
            x_app_name=cfg.get("listfile", "X_APP_NAME"),
        )
        self.upload_ep = Endpoint(
            url=cfg.get("upload", "URL"),
            x_api_key=cfg.get("upload", "X_API_KEY"),
            x_app_name=cfg.get("upload", "X_APP_NAME"),
        )

    def _headers(self, ep: Endpoint) -> Dict[str, str]:
        return {"X-API-Key": ep.x_api_key, "X-App-Name": ep.x_app_name}


    def _request(
        self,
        method: str,
        ep: Endpoint,
        *,
        params: Optional[Dict[str, Any]] = None,
        data: Optional[Dict[str, Any]] = None,
        files: Optional[Dict[str, Any]] = None,
        timeout: Optional[int] = None,
        log: Optional[logging.Logger] = None
    ) -> requests.Response:
        # Determine timeout from config if not provided
        if timeout is None:
            if method.upper() == "GET":
                timeout = self.cfg.getint("SharePoint_API_setting", "sharepoint_api_timeout_get", fallback=30)
            else:
                timeout = self.cfg.getint("SharePoint_API_setting", "sharepoint_api_timeout_post", fallback=60)

        try:
            resp = self.session.request(
                method=method,
                url=ep.url,
                headers=self._headers(ep),
                params=params,
                data=data,
                files=files,
                timeout=timeout,
            )
            resp.raise_for_status()
            return resp
        except Exception:
            if log:
                log.exception("HTTP %s %s failed", method, ep.url)
            raise


    # -------------------------------------------------------------------------
    # Primitives (list, download, upload)
    # -------------------------------------------------------------------------
    def list_files(self, folder_or_abs: str, *, absolute: bool, log: logging.Logger) -> Optional[Dict[str, Any]]:
        folder_path = self.sp_paths.join_base(folder_or_abs, absolute=absolute)
        params = {**self.sp_paths.to_params(), "folderPath": folder_path}
        try:
            data = self._request("GET", self.listfile_ep, params=params, timeout=30, log=log).json()
            if not isinstance(data, dict) or "items" not in data:
                log.warning("list_files: unexpected schema; no 'items' key for %s", folder_path)
                return None
            log.info("Listed: %s", folder_path)
            return data
        except Exception:
            log.exception("list_files failed for %s", folder_path)
            return None

    def download(self, file_path_abs_or_rel: str, save_dir: Path, *, absolute: bool, log: logging.Logger) -> Optional[Path]:
        sp_path = self.sp_paths.join_base(file_path_abs_or_rel, absolute=absolute)
        params = {**self.sp_paths.to_params(), "filePath": sp_path}
        try:
            resp = self._request("GET", self.download_ep, params=params, timeout=30, log=log)
            save_dir.mkdir(parents=True, exist_ok=True)
            filename = Path(sp_path.replace("\\", "/")).name or "download.bin"
            out_path = save_dir / filename
            out_path.write_bytes(resp.content)
            log.info("Downloaded: %s", out_path)
            return out_path
        except Exception:
            log.exception("download failed for %s", sp_path)
            return None

    def create_folder(self, target_folder_rel: str, log: logging.Logger) -> bool:
        """
        Create a folder on SharePoint by POSTing with no files (parity with original).
        """
        target_folder = self.sp_paths.join_base(target_folder_rel, absolute=False)
        data = {**self.sp_paths.to_params(), "folderPath": target_folder}
        try:
            self._request("POST", self.upload_ep, files=None, data=data, timeout=60, log=log)
            log.info("Created folder: %s", target_folder)
            return True
        except Exception:
            log.exception("create_folder failed for %s", target_folder)
            return False

    def upload_file(self, local_file: Optional[Path], target_folder_rel: str, log: logging.Logger) -> bool:
        """
        Upload a single file OR create folder when local_file is None.
        Matches original upload_file(file_path, folderPath) behavior exactly.
        """
        if local_file is None:
            return self.create_folder(target_folder_rel, log=log)

        target_folder = self.sp_paths.join_base(target_folder_rel, absolute=False)
        data = {**self.sp_paths.to_params(), "folderPath": target_folder}
        try:
            if not local_file.is_file():
                log.error("upload_file: local file not found: %s", local_file)
                return False
            with local_file.open("rb") as fh:
                files = {"file": (local_file.name, fh)}
                self._request("POST", self.upload_ep, files=files, data=data, timeout=60, log=log)
            log.info("Uploaded: %s -> %s", local_file, target_folder)
            return True
        except Exception:
            log.exception("upload_file failed for %s -> %s", local_file, target_folder)
            return False
    
    def upload_directory(
            self,
            local_dir: Path,
            target_folder_rel: str,
            log: logging.Logger,
            *,
            base_from_outputs: Optional[Path] = None,
            create_folders: bool = False,
        ) -> List[Path]:
            """
            Upload all files under `local_dir` recursively.

            Parity with the original behavior:
            - If `base_from_outputs` is provided (e.g., BASE_DIR/CACHE), the remote folder is computed
            as the dirname of the file's path relative to `base_from_outputs`. This reproduces:
                rel_path = os.path.relpath(full_path, base_from_outputs)
                remote_folder_rel = os.path.dirname(rel_path)
            Example:
                local: BASE_DIR/CACHE/Outputs/Archive/Trade_date_20251209/20251209/file.xlsx
                rel_path -> Outputs/Archive/Trade_date_20251209/20251209/file.xlsx
                remote_folder_rel -> Outputs/Archive/Trade_date_20251209/20251209
                (NOTE: This already includes 'Outputs' at the root)

            - If `base_from_outputs` is NOT provided, we preserve the directory under `target_folder_rel`
            (relative to `local_dir`). This is convenient for calls like:
                upload_directory(outputs_dir, target_folder_rel="Outputs/20251209", ...)
            Example:
                local: <outputs_dir>/Archive/Trade_date_20251209/20251209/file.xlsx
                remote_folder_rel -> Outputs/20251209/Archive/Trade_date_20251209/20251209

            Args:
                local_dir: Root local directory to walk.
                target_folder_rel: Remote base folder (relative to SharePoint base_root).
                log: Logger instance.
                base_from_outputs: Optional root for computing the rel_path like the original script
                                (typically Path(BASE_DIR) / CACHE). If provided, target_folder_rel
                                is ignored for per-file folder resolution (parity mode).
                create_folders: If True, explicitly create each remote folder before uploading
                                (server may auto-create; disabled by default for speed).

            Returns:
                List[Path]: Local file paths that were successfully uploaded.
            """
            uploaded: List[Path] = []

            try:
                if not local_dir.exists():
                    log.error("upload_directory: local_dir does not exist: %s", local_dir)
                    return uploaded

                # Normalize base target (used only when base_from_outputs is None)
                base_target = target_folder_rel.strip("/")

                for dirpath, _, filenames in os.walk(local_dir):
                    dirpath_p = Path(dirpath)

                    for fname in filenames:
                        full_path = dirpath_p / fname
                        if not full_path.is_file():
                            continue

                        # Compute remote folder rel
                        if base_from_outputs:
                            try:
                                rel_path = full_path.relative_to(base_from_outputs)
                            except ValueError:
                                # If full_path is not under base_from_outputs, fallback to local_dir
                                rel_path = full_path.relative_to(local_dir)
                            rel_dir = rel_path.parent.as_posix()  # already includes 'Outputs/...'
                            remote_folder_rel = rel_dir.strip("/")
                        else:
                            rel_path = full_path.relative_to(local_dir)
                            rel_dir = rel_path.parent.as_posix()  # e.g., 'Archive/...'
                            remote_folder_rel = f"{base_target}/{rel_dir}".strip("/")

                        # Optionally create the folder first (some APIs auto-create)
                        if create_folders:
                            _ = self.create_folder(remote_folder_rel, log=log)

                        # Upload file to computed folder
                        ok = self.upload_file(full_path, remote_folder_rel, log=log)
                        if ok:
                            uploaded.append(full_path)
                            log.info("Uploaded: %s -> %s", full_path, remote_folder_rel)
                        else:
                            log.error("Failed to upload: %s -> %s", full_path, remote_folder_rel)

                return uploaded

            except Exception:
                log.exception(
                    "upload_directory failed for local_dir=%s target_folder_rel=%s",
                    local_dir, target_folder_rel
                        )

    # -------------------------------------------------------------------------
    # Helpers (recursive listing, tree download, DFS plan)
    # -------------------------------------------------------------------------
    def list_all_recursive(self, root_abs: str, log: logging.Logger) -> List[Dict[str, Any]]:
        """
        DFS listing returning raw item dicts. root_abs must be absolute (leading '/').
        """
        start_abs = self.sp_paths.join_base(root_abs, absolute=True)
        stack: List[str] = [start_abs]
        found: List[Dict[str, Any]] = []

        while stack:
            current_abs = stack.pop()
            listing = self.list_files(current_abs, absolute=True, log=log)
            if not listing:
                continue

            for item in listing["items"]:
                t = (item.get("type") or "").strip()
                p = (item.get("path") or "").replace("\\", "/").strip("/")
                if not p:
                    log.warning("Skipping malformed item under %s: %s", current_abs, item)
                    continue
                found.append(item)
                if t == "Folder":
                    next_abs = "/" + p if not p.startswith("/") else p
                    stack.append(next_abs)

        return found

    def download_tree(self, root_abs: str, local_root: Path, log: logging.Logger) -> Tuple[List[Path], List[str]]:
        """
        Download all files under root_abs into local_root (shallow by parent folder).
        Returns (downloaded_paths, listed_file_paths_abs).
        """
        local_root.mkdir(parents=True, exist_ok=True)
        items = self.list_all_recursive(root_abs, log=log)
        listed_files_abs: List[str] = []
        downloaded_paths: List[Path] = []

        for it in items:
            t = it.get("type")
            path_abs = (it.get("path") or "").replace("\\", "/")
            if t == "File" and path_abs:
                listed_files_abs.append(path_abs)
                parent_name = Path(path_abs.strip("/")).parent.name or "root"
                target_dir = local_root / parent_name
                out = self.download(path_abs, target_dir, absolute=True, log=log)
                if out:
                    downloaded_paths.append(out)

        return downloaded_paths, listed_files_abs

    def walk_all_files_dfs(self, root_folder_abs: str, base_dir: str, cache_name: str, log: logging.Logger) -> List[Tuple[str, str]]:
        """
        Parity with original walk_all_files_dfs:
        Return a list of (absolute_file_path, local_save_dir) where local_save_dir mirrors the
        remote folder structure under BASE_DIR/CACHE/Inputs/<last_two_segments>.
        """
        root_abs = self.sp_paths.join_base(root_folder_abs, absolute=True).strip("/")
        tail = root_abs.split("/")
        last_two = tail[-2:] if len(tail) >= 2 else tail
        save_root = Path(base_dir) / cache_name / "Inputs" / Path(*last_two)

        results: List[Tuple[str, str]] = []
        stack: List[Tuple[str, Path]] = [(root_abs, save_root)]

        while stack:
            current_abs, current_local_dir = stack.pop()
            listing = self.list_files(current_abs, absolute=True, log=log)
            if not listing or "items" not in listing:
                log.warning("[WARN] Empty or invalid listing for: %s", current_abs)
                continue

            for item in listing["items"]:
                t = item.get("type")
                name = item.get("name")
                path_abs = (item.get("path") or "").replace("\\", "/").strip("/")
                if not path_abs or not name or not t:
                    log.warning("[WARN] Skipping malformed item under %s: %s", current_abs, item)
                    continue

                if t == "Folder":
                    next_abs = "/" + path_abs if not path_abs.startswith("/") else path_abs
                    next_local = current_local_dir / name
                    stack.append((next_abs, next_local))
                elif t == "File":
                    abs_with_leading = "/" + path_abs if not path_abs.startswith("/") else path_abs
                    results.append((abs_with_leading, str(current_local_dir)))

        return results


# -----------------------------------------------------------------------------
# Backwards-compatible module-level wrappers (same signatures as original)
# -----------------------------------------------------------------------------
# Important: original used "config.cfg" (no subfolder). Keep that for parity.
_config = configparser.ConfigParser(interpolation=None)
_config.read("Config/config.cfg")
_client = SharePointClient(_config)
_log = logging.getLogger("SharePoint")

def download(filePath: str, saveDir: str, absolute: bool = False) -> Optional[str]:
    """
    Original signature: returns str path (not Path). Preserved here.
    """
    out = _client.download(filePath, Path(saveDir), absolute=absolute, log=_log)
    return str(out) if out else None

def list_files(folder_or_abs: str, *, absolute: bool = False) -> Optional[Dict[str, Any]]:
    return _client.list_files(folder_or_abs, absolute=absolute, log=_log)

def upload_file(file_path: str, folderPath: str) -> bool:
    """
    Original behavior: if file_path is falsy, create folder.
    """
    lp = Path(file_path) if file_path else None
    return _client.upload_file(lp, folderPath, log=_log)

def walk_all_files_dfs(root_folder_path: str, BASE_DIR: str, CACHE: str) -> List[Tuple[str, str]]:
    """
    Original signature preserved. Returns DFS plan of (absolute file path, local save dir).
    """
    return _client.walk_all_files_dfs(root_folder_path, BASE_DIR, CACHE, log=_log)
