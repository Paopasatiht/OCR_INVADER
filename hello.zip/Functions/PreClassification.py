# -*- coding: utf-8 -*-
import os
import time
import uuid
import shutil
import logging
from pathlib import Path
from typing import Dict, List


def pre_classify_inputs(
    inputs_root: Path,
    log: logging.Logger,
    finnet_folder_name: str = "FINNET"
) -> Dict[str, List[Path]]:
    """
    Rule-based pre-classification:
    - If file is under a folder named 'finnet' -> classify as FINNET.
    - Else if file is image/pdf -> classify for Azure.
    - Else if file is Excel-readable (.xlsx, .xls, .csv) -> excel (skip Azure).
    Returns buckets:
      {
        "finnet": [FINNET files],
        "azure": [PDF/Image files],
        "excel": [Excel-readable or other files]
      }
    """
    buckets = {
        "finnet": [], 
        "azure": [], 
        "excel": [],
        }

    if not inputs_root or not inputs_root.exists():
        log.error("inputs_root does not exist: %s", inputs_root)
        return buckets

    IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp", ".gif", ".webp"}
    PDF_EXT = ".pdf"
    EXCEL_EXTS = {".xlsx", ".xls", ".csv"}

    for p in inputs_root.rglob("*"):
        if not p.is_file():
            continue

        ext = p.suffix.lower()
        parent_folder = p.parent.name.lower()

        # 1) FINNET folder check
        if parent_folder == finnet_folder_name.lower():
            buckets["finnet"].append(p)
            continue

        # 2) Agent folders: classify by extension
        if ext == PDF_EXT or ext in IMAGE_EXTS:
            buckets["azure"].append(p)
        elif ext in EXCEL_EXTS:
            buckets["excel"].append(p)

    log.info(
        "Pre-classification: %d FINNET, %d Azure, %d Excel",
        len(buckets["finnet"]), len(buckets["azure"]), len(buckets["excel"])
    )
    return buckets


def _try_stage_file(src: Path, dst: Path, use_hardlink_first: bool, log: logging.Logger) -> None:
    """
    Stage src -> dst with overwrite allowed.
    Strategy:
      - If dst exists, unlink it (best effort).
      - Prefer hardlink only if dst does not exist yet (avoid races).
      - Otherwise copy to a temp file and os.replace(tmp, dst) atomically.
    """
    # Ensure parent exists
    dst.parent.mkdir(parents=True, exist_ok=True)

    # If destination exists, try to remove it first (best effort)
    if dst.exists():
        try:
            dst.unlink()
        except Exception as e:
            # Not fatal; we will still attempt to copy/replace below
            log.debug("Could not unlink existing %s: %s", dst, e)

    # Hardlink only when destination is not present
    if use_hardlink_first and not dst.exists():
        try:
            os.link(src, dst)
            return
        except FileExistsError:
            # Another process may have created it; fall through to temp+replace
            pass
        except Exception as e:
            # Hardlink failed (different fs, permissions, etc.) -> fall back
            log.debug("Hardlink failed for %s -> %s: %s (will copy)", src, dst, e)

    # Copy via temp then atomic replace
    tmp = dst.with_name(f".staging_{uuid.uuid4().hex}_{dst.name}")
    try:
        shutil.copy2(src, tmp)  # copy metadata if possible
        os.replace(tmp, dst)    # atomic on Windows; overwrites if exists
    except Exception as e:
        # Clean up tmp if replace failed
        try:
            if tmp.exists():
                tmp.unlink()
        except Exception:
            pass
        raise e


def materialize_di_inbox(
    candidates: List[Path],
    inbox_root: Path,
    inputs_root: Path,
    log: logging.Logger,
    use_hardlink_first: bool = True,
    max_attempts: int = 5,
    base_sleep: float = 0.25,
) -> Path:
    """
    Creates a filtered DI inbox folder and stages only `candidates`.
    Preserves relative subfolder structure under `inbox_root`.
    Overwrites existing files if present.
    Retries on Windows file-in-use errors with exponential backoff.

    Returns the DI inbox path.
    """
    inbox_root = inbox_root.resolve()
    inbox_root.mkdir(parents=True, exist_ok=True)

    staged = 0
    for src in candidates:
        try:
            try:
                rel = src.relative_to(inputs_root)
            except ValueError:
                # If file is outside inputs_root, flatten
                rel = Path(src.name)

            dst = inbox_root / rel

            # Retry loop to handle WinError 32 (file in use)
            attempt = 0
            while True:
                try:
                    _try_stage_file(src, dst, use_hardlink_first, log)
                    staged += 1
                    break
                except PermissionError as e:
                    # Typical for WinError 32 (file in use)
                    attempt += 1
                    if attempt >= max_attempts:
                        log.exception(
                            "PermissionError (likely WinError 32) staging %s -> %s after %d attempts: %s",
                            src, dst, attempt, e
                        )
                        break
                    sleep = base_sleep * (2 ** (attempt - 1))
                    log.warning(
                        "File in use for %s; retrying in %.2fs (attempt %d/%d)",
                        dst, sleep, attempt, max_attempts
                    )
                    time.sleep(sleep)
                except FileExistsError as e:
                    # Very rare race: destination recreated by another process between unlink and replace
                    attempt += 1
                    if attempt >= max_attempts:
                        log.exception("FileExistsError staging %s -> %s after %d attempts: %s",
                                      src, dst, attempt, e)
                        break
                    sleep = base_sleep * (2 ** (attempt - 1))
                    time.sleep(sleep)
                except Exception as e:
                    # Any other error: log and continue
                    log.exception("Failed to stage %s -> %s: %s", src, dst, e)
                    break

        except Exception as e:
            log.exception("Staging error for %s: %s", src, e)

    # Count only files (exclude dirs)
    try:
        file_total = sum(1 for p in inbox_root.rglob("*") if p.is_file())
    except Exception:
        file_total = staged

    log.info("DI inbox ready at %s (staged: %d, files present: %d)", inbox_root, staged, file_total)
    return inbox_root
