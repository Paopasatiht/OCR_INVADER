# Functions/mappers/slip_transaction_OCR.py
from __future__ import annotations

from typing import Any, Dict, List, Tuple
import logging
from pathlib import Path

from Functions.mappers.base import TransactionRecord, TransactionFormMapper
# import helpers
from Functions.mappers.helpers import (
    extract_agent_from_path,
    map_account_number_from_hint,
    normalize_transaction_amount,
    normalize_date,
    load_shared_bank_codes,  # <-- NEW: shared JSON via Config/config.cfg
    load_shared_agent_names,
)


class SlipTransactionFormMapper(TransactionFormMapper):
    """
    Maps OCR results for mobile slip-transaction pay-in forms to TransactionRecord(s).
    Expects extraction_results['extraction_results']['Slip'] to be a list of items.
    """

    def __init__(self, config_path: Path, log: logging.Logger):
        self.config_path = config_path
        self.log = log
        self.bank_codes_mapping = load_shared_bank_codes(config_path, log)
        self.agent_names_mapping = load_shared_agent_names(config_path, log)

    def map(self, extraction_results: Dict[str, Any]) -> Tuple[List[TransactionRecord], List[Dict[str,Any]]]: # also return failed files list

        failed_files: List[Dict[str,Any]] = []

        slip_items = (
            extraction_results.get('extraction_results', {})
                              .get('Slip', [])
        )
        self.log.info("Processing %d 'Slip' items.", len(slip_items))

        records: List[TransactionRecord] = []
        missing_account_map = 0
        missing_fields = 0
        
        for idx, item in enumerate(slip_items, start=1):
            try:
                # ---- Agent: derive from file path (fallback-safe) ----
                file_path = item.get("file_path")
                page_num = item.get("page_num")
                if not file_path:
                    # Defensive: navigate analyze_result/documents[] safely
                    analyze_result = item.get("analyze_result", {})
                    documents = analyze_result.get("documents") or []
                    doc0 = documents[0] if documents else {}
                    file_path = doc0.get("docPath", "")
                agent = extract_agent_from_path(
                    path_str = file_path, 
                    agent_map = self.agent_names_mapping) or ""

                # ---- Fields from OCR (defensive access) ----
                analyze_result = item.get("analyze_result", {})
                documents = analyze_result.get("documents") or []
                fields = (documents[0].get("fields", {}) if documents else {})

                # Bank Account No. (support slight variations in field name)
                raw_acc = (
                    (fields.get("Bank Account No. Hint", {}) or {}).get("valueString")
                    or (fields.get("Bank Account No Hint", {}) or {}).get("valueString")
                    or ""
                )

                # ---- Map Bank Account No & Code ----
                mapped: Tuple[str, str, str] | None = map_account_number_from_hint(raw_acc, self.bank_codes_mapping)
                if mapped:
                    bank_code, bank_name, normalized_acc = mapped
                    bank_account_no_fmt = f"{bank_code} {bank_name} {normalized_acc}"
                else:
                    bank_code = ""
                    bank_account_no_fmt = ""
                    missing_account_map += 1
                    self.log.warning("Unmapped account (item %d): raw='%s'", idx, raw_acc)

                # ---- Amount ----
                raw_amount = (fields.get("Amount", {}) or {}).get("valueString") or ""
                amount = normalize_transaction_amount(raw_amount)


                # ---- Date ---- (OCR returns yyyy-mm-dd)
                raw_date = fields.get('Date', {}).get('valueString') or ""
                date = normalize_date(raw_date)

                # ---- Payment Type ----
                payment_type = "C"  # Pay-in form (Non-slip)

                # Debug: log missing key fields
                if not agent or not raw_acc or not raw_amount or not raw_date:
                    missing_fields += 1
                    self.log.debug(
                        "Item %d has missing fields: agent='%s', acc='%s', amount='%s', date='%s'",
                        idx, agent, raw_acc, raw_amount, raw_date
                    )

                records.append(TransactionRecord(
                    agent=agent,
                    payment_type=payment_type,
                    bank_code=f"{bank_code}",
                    bank_account_no_fmt=bank_account_no_fmt,
                    amount=amount,
                    date=date,
                    source_kind="Slip",
                    source_file=file_path
                ))
            except Exception as e:
                self.log.exception("Failed to process item %d: %s", idx, e)
                failed_files.append({
                    "file_path":file_path,
                    "page_num": page_num,
                    "reason": "Failed to process item"})

        self.log.info("Completed items: %d, unmapped accounts: %d, items with missing fields: %d",
                      len(slip_items), missing_account_map, missing_fields)
        return records, failed_files
