# OCR Smart Reconcile - Clean Code Version

## Coding Instructions (CI)

### Core Principles
1. **1 Function = 1 Purpose** - Each function does exactly one thing
2. **Short Functions** - Keep functions under 15-20 lines
3. **Easy to Read** - Clear naming, minimal nesting, self-documenting
4. **Type Hints** - Use type annotations everywhere
5. **Docstrings** - Brief description + parameters for public functions

### Naming Conventions
| Type | Convention | Example |
|------|------------|---------|
| Functions | snake_case | `normalize_date()` |
| Classes | PascalCase | `TransactionRecord` |
| Constants | UPPER_SNAKE | `IMAGE_EXTENSIONS` |
| Private | _prefix | `_parse_amount()` |
| Modules | snake_case | `single_transaction.py` |

### Function Guidelines
```python
# GOOD: Single purpose, clear name
def normalize_amount(amount_str: str) -> str:
    """Format amount to #,###.00 format."""
    cleaned = _remove_non_digits(amount_str)
    value = _parse_float(cleaned)
    return f"{value:,.2f}"

# BAD: Multiple purposes, unclear
def process(data):
    # does 5 different things...
```

### Error Handling
```python
# GOOD: Specific, informative
def load_config(path: Path) -> ConfigParser:
    if not path.exists():
        raise FileNotFoundError(f"Config not found: {path}")
    ...

# BAD: Silent failure
def load_config(path):
    try:
        ...
    except:
        return None  # Caller doesn't know why
```

### Imports
```python
# Standard library first
import json
import logging
from pathlib import Path

# Third party
import pandas as pd
from azure.ai.documentintelligence import DocumentIntelligenceClient

# Local modules
from src.models.base import TransactionRecord
from src.utils.helpers import normalize_date
```

---

## Project Structure

```
KA_CG_CI/
├── src/
│   ├── __init__.py
│   ├── main.py                 # Entry point
│   │
│   ├── models/
│   │   └── base.py             # Data classes
│   │
│   ├── config/
│   │   └── settings.py         # Configuration loading
│   │
│   ├── utils/
│   │   └── helpers.py          # Shared utilities
│   │
│   ├── services/
│   │   ├── ocr/
│   │   │   ├── client.py       # Azure DI client
│   │   │   ├── classifier.py   # Document classification
│   │   │   └── extractor.py    # Data extraction
│   │   ├── sharepoint/
│   │   │   └── client.py       # SharePoint operations
│   │   └── email/
│   │       └── sender.py       # Email notification
│   │
│   ├── mappers/
│   │   ├── single.py           # Single transaction
│   │   ├── multiple.py         # Multiple transaction
│   │   ├── slip.py             # PromptPay slip
│   │   ├── excel.py            # Generic Excel
│   │   └── finnet.py           # FINNET Excel
│   │
│   └── pipeline/
│       ├── preclassifier.py    # File type detection
│       └── extraction.py       # Main pipeline
│
├── config/
│   └── config.cfg
│
├── step_by_step/               # Development guide
│   ├── 00_Overview.md
│   ├── 01_models_base.md
│   ├── ...
│   └── 16_main.md
│
├── tests/
├── Dockerfile
├── requirements.txt
└── README.md
```

---

## Getting Started

### Prerequisites
- Python 3.10+
- Azure Document Intelligence account
- (Optional) SharePoint API access

### Installation
```bash
cd KA_CG_CI
pip install -r requirements.txt
```

### Configuration
1. Copy `.env.example` to `.env`
2. Set Azure credentials:
   ```
   DI_ENDPOINT=https://your-endpoint.cognitiveservices.azure.com/
   DI_KEY=your-api-key
   ```
3. Update `config/config.cfg` with your paths

### Running
```bash
python -m src.main
```

---

## Development Guide

Follow the step-by-step guide in `step_by_step/` folder:

1. Read `00_Overview.md` for the big picture
2. Follow modules in order (01, 02, 03...)
3. Each file contains:
   - What the module does
   - Key concepts to understand
   - Prompt to generate clean code

---

## Module Dependencies

```
models/base.py ─────────────────────────────────────────┐
                                                        │
config/settings.py ─────────────────────────────────────┤
                                                        │
utils/helpers.py ───────────────────────────────────────┤
        │                                               │
        ├──► services/ocr/client.py                     │
        │           │                                   │
        │           ├──► services/ocr/classifier.py     │
        │           │                                   │
        │           └──► services/ocr/extractor.py      │
        │                       │                       │
        │                       ▼                       │
        ├──► pipeline/preclassifier.py                  │
        │           │                                   │
        │           ▼                                   │
        └──► mappers/single.py ─────────────────────────┤
             mappers/multiple.py                        │
             mappers/slip.py                            │
             mappers/excel.py                           │
             mappers/finnet.py                          │
                    │                                   │
                    ▼                                   │
             pipeline/extraction.py ◄───────────────────┤
                    │                                   │
                    ├──► services/sharepoint/client.py  │
                    │                                   │
                    ├──► services/email/sender.py       │
                    │                                   │
                    ▼                                   │
             main.py ◄──────────────────────────────────┘
```
