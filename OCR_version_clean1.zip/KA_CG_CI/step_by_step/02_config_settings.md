# Step 02: Config Settings

## โมดูล: `src/config.py`

## หน้าที่
จัดการการโหลด configuration จากหลายไฟล์:
- `.env` - API keys และ credentials (ไม่ commit)
- `config/azure.yaml` - Azure services config (ใช้ ${VAR} จาก .env)
- `config/kasset_infra.yaml` - paths, SharePoint, email
- `Config/ocr.yaml` - OCR extractors (model_id mappings)

## ไฟล์ต้นฉบับ
- `Original Code/Functions/Path_Handler.py`
- `Original Code/Config/config.cfg`
- `Original Code/.env`

---

## แนวคิดสำคัญ

### 1. Environment Variables (.env)

**.env** (credentials - ไม่ commit to git)
```bash
# Azure Document Intelligence (OCR)
DI_ENDPOINT="https://your-resource.cognitiveservices.azure.com/"
DI_KEY="your-document-intelligence-key"
DI_API_VERSION="2024-11-30"

# Azure OpenAI
AZURE_OPENAI_KEY="your-openai-key"
AZURE_OPENAI_RESOURCE="https://your-resource.openai.azure.com/"

# Azure Cognitive Search
COG_SEARCH_ENDPOINT="https://your-search.search.windows.net"
COG_SEARCH_ADMIN_KEY="your-search-key"
```

**.env.example** (template สำหรับ reference)
```bash
DI_ENDPOINT="https://your-resource.cognitiveservices.azure.com/"
DI_KEY="your-api-key"
DI_API_VERSION="2024-11-30"
```

### 2. Azure Config (ใช้ ${VAR})

**config/azure.yaml**
```yaml
# Azure Document Intelligence (OCR)
document_intelligence:
  endpoint: "${DI_ENDPOINT}"
  key: "${DI_KEY}"
  api_version: "${DI_API_VERSION}"
  connection_timeout: 300
  read_timeout: 300
  max_retries: 2
  pool_size: 32
  confidence_threshold: 0.6

# Azure OpenAI
openai:
  endpoint: "${AZURE_OPENAI_RESOURCE}"
  key: "${AZURE_OPENAI_KEY}"

# Azure Cognitive Search
cognitive_search:
  endpoint: "${COG_SEARCH_ENDPOINT}"
  admin_key: "${COG_SEARCH_ADMIN_KEY}"
```

### 3. Infrastructure Config

**config/kasset_infra.yaml**
```yaml
paths:
  cache_inputs: Cache/Inputs
  cache_outputs: Cache/Outputs
  cache_temp: Cache/Temp
  logs: Logs

mapper:
  root: config/mapper
  agent: config/mapper/agent.yaml
  bank_code: config/mapper/bank_code.yaml

sharepoint:
  enabled: false  # ใช้ local Cache/ folder

email:
  enabled: false
  sender: user@example.com
  smtp_server: mail.example.com
  smtp_port: 25
```

---

## ฟังก์ชันที่ต้องสร้าง

| ฟังก์ชัน | หน้าที่ |
|----------|---------|
| `load_env(base_dir)` | Load .env file |
| `_expand_env_vars(obj)` | Expand ${VAR} ใน config |
| `load_yaml(path, expand_env)` | Load YAML file |
| `load_json(path)` | Load JSON file |
| `load_azure_config(config_dir, base_dir)` | Load azure.yaml พร้อม .env |
| `load_infra_config(config_dir)` | Load kasset_infra.yaml |
| `load_all_config(config_dir, base_dir)` | Load all configs |
| `resolve_path(base_dir, relative)` | Convert relative to absolute |
| `ensure_directory(path)` | Create directory if not exists |
| `get_cache_paths(infra, base_dir)` | Get cache paths from config |
| `get_document_intelligence_config(cfg)` | Extract DI settings |
| `get_openai_config(cfg)` | Extract OpenAI settings |
| `get_cognitive_search_config(cfg)` | Extract Search settings |

---

## Prompt ที่ใช้

```
เขียน clean Python code สำหรับ src/config.py

ข้อกำหนด:
1. สร้าง load_env(base_dir: Path) -> None
   - Load .env file using python-dotenv
2. สร้าง _expand_env_vars(obj: Any) -> Any
   - Recursively expand ${VAR} in config values
3. สร้าง load_yaml(path: Path, expand_env: bool = False) -> dict
   - โหลด YAML file, optionally expand env vars
4. สร้าง load_azure_config(config_dir: Path, base_dir: Path) -> dict
   - โหลดจาก azure.yaml พร้อม .env expansion
5. สร้าง load_infra_config(config_dir: Path) -> dict
   - โหลดจาก kasset_infra.yaml
6. สร้าง load_all_config(config_dir: Path, base_dir: Path) -> dict
   - โหลด config ทั้งหมดรวมกัน
7. สร้าง get_cache_paths(infra: dict, base_dir: Path) -> dict
8. สร้าง resolve_path(base_dir: Path, relative: str) -> Path
9. สร้าง ensure_directory(path: Path) -> None
10. สร้าง get_document_intelligence_config(azure_config: dict) -> dict
11. สร้าง get_openai_config(azure_config: dict) -> dict
12. สร้าง get_cognitive_search_config(azure_config: dict) -> dict
13. แต่ละฟังก์ชันไม่เกิน 15 บรรทัด
14. ใช้ type hints ทุกที่

อ้างอิง: Original Code/Functions/Path_Handler.py
```

---

## โครงสร้างไฟล์ Config

```
KA_CG_CI/
├── .env                  ← API keys (ไม่ commit)
├── .env.example          ← Template
├── .gitignore            ← มี .env อยู่
├── config/
│   ├── azure.yaml        ← Azure services (ใช้ ${VAR})
│   ├── kasset_infra.yaml ← Infrastructure
│   └── mapper/           ← Mapping configs
└── Config/
    └── ocr.yaml          ← OCR extractors
```

---

## Test ใน main.py

```python
"""
Step 02 Test: config.py
"""
from pathlib import Path
from config import (
    load_env,
    load_azure_config,
    load_infra_config,
    get_cache_paths,
    get_document_intelligence_config,
)


def test_step_02():
    base_dir = Path(__file__).parent.parent
    config_dir = base_dir / "config"

    # Load .env first
    load_env(base_dir)

    # Test load_azure_config with .env expansion
    azure = load_azure_config(config_dir, base_dir)
    di = get_document_intelligence_config(azure)
    assert di.get("endpoint")  # Should have value from .env
    assert di.get("key")

    # Test load_infra_config
    infra = load_infra_config(config_dir)
    assert "paths" in infra
    assert "sharepoint" in infra

    # Test get_cache_paths
    paths = get_cache_paths(infra, base_dir)
    assert "inputs" in paths
    assert paths["inputs"].is_absolute()

    print("STEP 02 PASSED")


if __name__ == "__main__":
    test_step_02()
```

---

## Expected Output

```
STEP 02 PASSED
```

---

## เมื่อ PASS แล้ว

ไปต่อ **Step 03: utils/helpers.py**
