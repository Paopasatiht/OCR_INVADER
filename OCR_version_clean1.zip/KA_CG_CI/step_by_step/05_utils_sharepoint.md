# Step 05: SharePoint Client

## โมดูล: `src/utils/sharepoint.py`

## หน้าที่
จัดการการทำงานกับไฟล์ SharePoint:
- List ไฟล์ในโฟลเดอร์ระยะไกล
- Download ไฟล์มา cache ในเครื่อง
- Upload ไฟล์ที่ประมวลผลแล้วกลับไป
- สร้างโฟลเดอร์บน SharePoint

## ไฟล์ต้นฉบับ
`Original Code/Functions/SharePoint_IO.py`

---

## แนวคิดสำคัญที่ต้องเข้าใจ

### 1. SharePoint API Endpoints
| การทำงาน | Endpoint |
|----------|----------|
| List files | /api/SharePoint/debug/list |
| Download | /api/SharePoint/download |
| Upload | /api/SharePoint/upload |

### 2. Configuration
```yaml
sharepoint:
  site_url: /sites/KasikornAsset/FR
  drive_name: Documents
  base_root: Provident Fund/OCR - Rekey Percent Unvest
  remote_input: /Inputs
  remote_output: /Outputs
  enabled: true
  timeout_get: 30
  timeout_post: 60
  retry_total: 3
```

### 3. การแปลง Path
```
Relative: "Inputs/20240115"
→ Absolute: "/Provident Fund/OCR - Rekey Percent Unvest/Inputs/20240115"
```

### 4. ขั้นตอน Download
```
1. list_files(remote_folder) → ได้ list ไฟล์
2. สำหรับแต่ละไฟล์:
   download(file_path, local_dir)
3. return list ของ paths ที่ download แล้ว
```

---

## ฟังก์ชันที่ต้องสร้าง (Clean Code)

### SharePoint Client Class
```python
class SharePointClient:
    def __init__(self, config: dict)
    def list_files(self, folder_path: str, absolute: bool = False) -> dict | None
    def download_file(self, file_path: str, save_dir: Path, absolute: bool = False) -> Path | None
    def upload_file(self, local_file: Path | None, target_folder: str) -> bool
    def create_folder(self, folder_path: str) -> bool
```

### การทำงานระดับสูง
| ฟังก์ชัน | หน้าที่ |
|----------|---------|
| `list_all_recursive(root_path)` | DFS listing ของทุกไฟล์ |
| `download_tree(root_path, local_dir)` | Download ทั้งโฟลเดอร์ |
| `upload_directory(local_dir, target_folder)` | Upload ทุกไฟล์ใน directory |

### ฟังก์ชันช่วยเหลือ
| ฟังก์ชัน | หน้าที่ |
|----------|---------|
| `_build_session(config)` | สร้าง requests.Session พร้อม retry |
| `_join_path(base_root, relative, absolute)` | แปลง SharePoint paths |
| `_make_request(method, endpoint, params, files)` | ทำ HTTP request |

---

## Prompt ที่ใช้

```
เขียน clean Python code สำหรับ src/utils/sharepoint.py

ข้อกำหนด:
1. สร้าง SharePointClient class พร้อม __init__(self, config: dict)
   - เก็บ endpoints, credentials, paths จาก config
   - สร้าง requests.Session พร้อม retry policy
2. สร้าง list_files(self, folder_path: str, absolute: bool = False) -> dict | None
   - เรียก list endpoint
   - return {"items": [...]} หรือ None ถ้า error
3. สร้าง download_file(self, file_path: str, save_dir: Path, absolute: bool = False) -> Path | None
   - Download เนื้อหาไฟล์
   - บันทึกที่ save_dir/filename
   - return local path หรือ None
4. สร้าง upload_file(self, local_file: Path | None, target_folder: str) -> bool
   - ถ้า local_file เป็น None, สร้างโฟลเดอร์
   - ไม่งั้น upload ไฟล์
5. สร้าง list_all_recursive(self, root_path: str) -> list[dict]
   - DFS traversal ของโฟลเดอร์
   - return flat list ของทุก items
6. สร้าง download_tree(self, root_path: str, local_dir: Path) -> tuple[list[Path], list[str]]
   - Download ทุกไฟล์แบบ recursive
   - return (downloaded_paths, listed_file_paths)
7. สร้าง upload_directory(self, local_dir: Path, target_folder: str) -> list[Path]
   - Upload ทุกไฟล์รักษาโครงสร้าง
   - return list ของ paths ที่ upload แล้ว
8. แต่ละ method ไม่เกิน 20 บรรทัด
9. ใช้ logging สำหรับทุกการทำงาน

อ้างอิง: Original Code/Functions/SharePoint_IO.py
```
