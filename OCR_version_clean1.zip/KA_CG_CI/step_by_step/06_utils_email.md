# Step 06: Email Sender

## โมดูล: `src/utils/email.py`

## หน้าที่
ส่ง email แจ้งเตือนพร้อมผลลัพธ์การประมวลผล:
- สรุปแบบ Plain text ภาษาไทย
- แนบไฟล์ Excel สรุปผล
- ส่งผ่าน SMTP

## ไฟล์ต้นฉบับ
- `Original Code/Functions/Email_Sender.py`
- `Original Code/Functions/email/smtp_handler.py`

---

## แนวคิดสำคัญที่ต้องเข้าใจ

### 1. Status Labels
| Status | เงื่อนไข |
|--------|----------|
| สำเร็จ | ไม่มี failures, มี success |
| สำเร็จบางส่วน | มีทั้ง failures และ success |
| ล้มเหลว | มี failures, ไม่มี success |
| ไม่มีไฟล์ | ไม่มีทั้ง failures และ success |
| SharePoint ผิดพลาด | status == "sharepoint_failed" |

### 2. รูปแบบ Email Subject
```
[สรุปผล OCR] สำเร็จ - 30/01/2026 14:30
[สรุปผล OCR] สำเร็จบางส่วน - 30/01/2026 14:30
[สรุปผล OCR] ล้มเหลว - 30/01/2026 14:30
```

### 3. โครงสร้าง Summary Excel
| คอลัมน์ | คำอธิบาย |
|---------|----------|
| Agent | ชื่อ agent |
| File | ชื่อไฟล์ |
| File Path | path เต็ม |
| Status | success / fail |
| Error | คำอธิบายภาษาไทย |
| Doc Type | ประเภทเอกสาร |

### 4. Extraction Results Keys
```python
{
    "overall_success_files": [...],
    "encrypted_pdf_files": [...],
    "failed_OCR_classification_files": [...],
    "failed_OCR_extraction_files": [...],
    "unknown_or_unused_from_azure": [...],
    "failed_mapping_files": [...],
}
```

---

## ฟังก์ชันที่ต้องสร้าง (Clean Code)

### ฟังก์ชันหลัก
| ฟังก์ชัน | หน้าที่ |
|----------|---------|
| `send_summary_email(results, config_path, to_emails, attachments_dir, cc_emails)` | entry point |

### ฟังก์ชัน Subject & Body
| ฟังก์ชัน | หน้าที่ |
|----------|---------|
| `_build_email_subject(results, prefix)` | สร้าง subject line |
| `_build_email_body(results, agent_names)` | สร้าง plain text body |
| `_determine_status(results)` | กำหนด status label |

### Summary Excel
| ฟังก์ชัน | หน้าที่ |
|----------|---------|
| `build_summary_excel(results, output_dir, agent_names)` | สร้าง run_summary.xlsx |

### ฟังก์ชัน SMTP
| ฟังก์ชัน | หน้าที่ |
|----------|---------|
| `_send_email(smtp_server, smtp_port, sender, to, cc, subject, body, attachments)` | ส่ง SMTP |
| `_attach_files(msg, attachments)` | เพิ่ม attachments |

---

## Prompt ที่ใช้

```
เขียน clean Python code สำหรับ src/utils/email.py

ข้อกำหนด:
1. สร้าง send_summary_email(results: dict, config_path: Path, to_emails: list[str], attachments_dir: Path, cc_emails: list[str] = None) -> None
   - สร้าง subject, body, attachments
   - ส่งผ่าน SMTP
2. สร้าง _build_email_subject(results: dict, prefix: str = "สรุปผล OCR") -> str
   - รูปแบบ: "[prefix] status - DD/MM/YYYY HH:MM"
   - Status: สำเร็จ / สำเร็จบางส่วน / ล้มเหลว / ไม่มีไฟล์
3. สร้าง _build_email_body(results: dict, agent_names: dict) -> str
   - สรุป Plain text ภาษาไทย
   - แสดงจำนวน: success, failed
4. สร้าง build_summary_excel(results: dict, output_dir: Path, agent_names: dict) -> Path
   - สร้าง Excel รวมทุกไฟล์และสถานะ
   - return path ของไฟล์ที่สร้าง
5. สร้าง _determine_status(results: dict) -> str
   - ตรวจสอบ failure keys และ success keys
   - return status label
6. สร้าง _send_email(smtp_server: str, smtp_port: int, sender: str, to: list, cc: list, subject: str, body: str, attachments: list[Path]) -> None
   - ใช้ smtplib
   - แนบไฟล์
7. แต่ละฟังก์ชันไม่เกิน 20 บรรทัด
8. โหลด agent names สำหรับแสดงใน summary

อ้างอิง:
- Original Code/Functions/Email_Sender.py
- Original Code/Functions/email/smtp_handler.py
```
