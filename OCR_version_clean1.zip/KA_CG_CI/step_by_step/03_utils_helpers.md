# Step 03: Utils Helpers

## โมดูล: `src/utils/helpers.py`

## หน้าที่
ฟังก์ชันช่วยเหลือที่ใช้ร่วมกันทั้งระบบ:
- แปลงวันที่ (พ.ศ./ค.ศ., เดือนไทย/อังกฤษ)
- จัดรูปแบบจำนวนเงิน
- แปลงเลขบัญชี
- ดึงชื่อ Agent จาก file path

## ไฟล์ต้นฉบับ
`Original Code/Functions/mappers/helpers.py`

---

## แนวคิดสำคัญ

### 1. กฎการแปลงวันที่
| Input | Output |
|-------|--------|
| 2024-12-25 | 25/12/2024 |
| 25/12/2567 | 25/12/2024 |
| 25 ธ.ค. 68 | 25/12/2025 |

### 2. การแปลงเดือนไทย
```python
THAI_MONTHS = {
    "ม.ค.": "01", "ก.พ.": "02", "มี.ค.": "03",
    "เม.ย.": "04", "พ.ค.": "05", "มิ.ย.": "06",
    "ก.ค.": "07", "ส.ค.": "08", "ก.ย.": "09",
    "ต.ค.": "10", "พ.ย.": "11", "ธ.ค.": "12"
}
```

### 3. การจัดรูปแบบจำนวนเงิน
| Input | Output |
|-------|--------|
| "1234.5" | "1,234.50" |
| "" | "0.00" |

---

## Prompt ที่ใช้

```
เขียน clean Python code สำหรับ src/utils/helpers.py

ข้อกำหนด:
1. แบ่งเป็นฟังก์ชันเล็กๆ (แต่ละฟังก์ชันไม่เกิน 15 บรรทัด)
2. สร้าง normalize_date(date_str: str, options: DateNormOptions = None) -> str
   - รองรับ formats: yyyy-mm-dd, dd/mm/yyyy, เดือนไทย, ปี พ.ศ.
   - แปลงเลขไทย (๐-๙) เป็นเลขอารบิก (0-9)
   - output: dd/mm/yyyy
3. สร้าง normalize_amount(amount_str: str) -> str
   - ล้าง spaces, format เป็น "#,###.00"
4. สร้าง normalize_account_number(acc_str: str) -> str
   - ดึงเฉพาะตัวเลข, รองรับเลขไทย
5. สร้าง map_account_number(raw_acc: str, bank_mapping: dict) -> tuple[str, str, str] | None
   - return (bank_code, bank_name, account_no) หรือ None
6. สร้าง extract_agent_from_path(path: str, agent_map: dict) -> str | None
   - match agent code ใน file path
7. ใช้ helper functions ที่ขึ้นต้นด้วย _ สำหรับใช้ภายใน
8. ไม่ใช้ external dependencies ยกเว้น re, datetime

import จาก models.py:
- from models import DateNormOptions

อ้างอิง: Original Code/Functions/mappers/helpers.py
```

---

## Test ใน main.py

ก่อนทดสอบ ต้องสร้าง `src/utils/__init__.py`:

```python
# src/utils/__init__.py
from .helpers import (
    normalize_date,
    normalize_amount,
    normalize_account_number,
    map_account_number,
    extract_agent_from_path
)
```

แล้ววาง code นี้ใน `src/main.py`:

```python
"""
Step 03 Test: utils/helpers.py
รัน: python src/main.py
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))

from models import DateNormOptions
from utils.helpers import (
    normalize_date,
    normalize_amount,
    normalize_account_number,
    map_account_number,
    extract_agent_from_path
)

def test_step_03():
    print("=" * 50)
    print("STEP 03: Testing utils/helpers.py")
    print("=" * 50)

    # Test 1: normalize_date - ISO format
    result = normalize_date("2024-12-25")
    print(f"[TEST 1] ISO date: 2024-12-25 -> {result}")
    assert result == "25/12/2024", f"Expected 25/12/2024, got {result}"
    print("[PASS] ISO date works!")

    # Test 2: normalize_date - Thai Buddhist year
    result = normalize_date("25/12/2567")
    print(f"[TEST 2] Buddhist year: 25/12/2567 -> {result}")
    assert result == "25/12/2024", f"Expected 25/12/2024, got {result}"
    print("[PASS] Buddhist year works!")

    # Test 3: normalize_date - Thai month
    options = DateNormOptions(prefer_buddhist_shorthand=True, locale_hint="th")
    result = normalize_date("25 ธ.ค. 68", options)
    print(f"[TEST 3] Thai month: 25 ธ.ค. 68 -> {result}")
    assert "12" in result, "Should contain month 12"
    print("[PASS] Thai month works!")

    # Test 4: normalize_amount
    result = normalize_amount("1234.5")
    print(f"[TEST 4] Amount: 1234.5 -> {result}")
    assert result == "1,234.50", f"Expected 1,234.50, got {result}"
    print("[PASS] normalize_amount works!")

    # Test 5: normalize_amount - empty
    result = normalize_amount("")
    print(f"[TEST 5] Empty amount: '' -> {result}")
    assert result == "0.00", f"Expected 0.00, got {result}"
    print("[PASS] Empty amount works!")

    # Test 6: normalize_account_number
    result = normalize_account_number("123-456-7890")
    print(f"[TEST 6] Account: 123-456-7890 -> {result}")
    assert result == "1234567890", f"Expected 1234567890, got {result}"
    print("[PASS] normalize_account_number works!")

    # Test 7: map_account_number
    bank_mapping = {
        "1234567890": {"bank_code": "002", "bank_name": "BBL"}
    }
    result = map_account_number("1234567890", bank_mapping)
    print(f"[TEST 7] Map account: {result}")
    assert result is not None, "Should find account"
    assert result[0] == "002", "Bank code should be 002"
    print("[PASS] map_account_number works!")

    # Test 8: extract_agent_from_path
    agent_map = {"AECS": "AECS - บริษัท หลักทรัพย์"}
    result = extract_agent_from_path("Inputs/20240101/AECS/file.pdf", agent_map)
    print(f"[TEST 8] Agent from path: {result}")
    assert result is not None, "Should find agent"
    assert "AECS" in result, "Should contain AECS"
    print("[PASS] extract_agent_from_path works!")

    print("=" * 50)
    print("STEP 03: ALL TESTS PASSED!")
    print("=" * 50)

if __name__ == "__main__":
    test_step_03()
```

---

## Expected Output

```
==================================================
STEP 03: Testing utils/helpers.py
==================================================
[TEST 1] ISO date: 2024-12-25 -> 25/12/2024
[PASS] ISO date works!
[TEST 2] Buddhist year: 25/12/2567 -> 25/12/2024
[PASS] Buddhist year works!
[TEST 3] Thai month: 25 ธ.ค. 68 -> 25/12/2025
[PASS] Thai month works!
[TEST 4] Amount: 1234.5 -> 1,234.50
[PASS] normalize_amount works!
[TEST 5] Empty amount: '' -> 0.00
[PASS] Empty amount works!
[TEST 6] Account: 123-456-7890 -> 1234567890
[PASS] normalize_account_number works!
[TEST 7] Map account: ('002', 'BBL', '1234567890')
[PASS] map_account_number works!
[TEST 8] Agent from path: AECS - บริษัท หลักทรัพย์
[PASS] extract_agent_from_path works!
==================================================
STEP 03: ALL TESTS PASSED!
==================================================
```

---

## เมื่อ PASS แล้ว

ไปต่อ **Step 04: utils/ocr.py**
