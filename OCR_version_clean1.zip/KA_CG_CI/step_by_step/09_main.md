# Step 09: Main Entry Point

## โมดูล: `src/main.py`

## หน้าที่
จุดเริ่มต้นของแอปพลิเคชันที่ orchestrate:
1. โหลด configuration
2. ตั้งค่า logging
3. รัน extraction pipeline จาก Cache/ folder
4. ส่ง email แจ้งเตือน (optional)
5. Cleanup

**หมายเหตุ:** SharePoint disabled by default (`enabled: false` ใน config)
- ใช้ข้อมูลจาก `Cache/Inputs/` โดยตรง
- บันทึก output ไปที่ `Cache/Outputs/`

## ไฟล์ต้นฉบับ
`Original Code/daily_main.py`

---

## แนวคิดสำคัญที่ต้องเข้าใจ

### 1. ขั้นตอนหลัก (SharePoint Disabled)
```python
def main():
    # 1. Setup
    today = get_today_string()
    config = load_config()
    logger = setup_logging()
    paths = get_cache_paths()

    # 2. Extraction Pipeline (จาก Cache/Inputs/)
    results, dfs = run_extraction_pipeline(
        inputs_dir=paths["inputs"],    # Cache/Inputs
        outputs_dir=paths["outputs"],  # Cache/Outputs
        temp_dir=paths["temp"],        # Cache/Temp
        ...
    )

    # 3. บันทึก Results JSON
    save_results_json()

    # 4. ส่ง Email (optional)
    if email_enabled:
        send_summary_email()

    # 5. Cleanup (optional)
    if cleanup_enabled:
        cleanup_temp()
```

### 2. โครงสร้าง Cache Folder
```
Cache/
├── Inputs/           # ใส่ไฟล์ที่ต้องการประมวลผล
│   ├── AECS/         # แยกตาม Agent
│   │   └── doc.pdf
│   ├── XYZ/
│   │   └── slip.png
│   └── FINNET/       # FINNET Excel files
│       └── data.xlsx
├── Outputs/          # ผลลัพธ์
│   └── payin_mapping_20260130.xlsx
└── Temp/             # temporary files (จะถูกลบ)
```

### 3. Configuration Flags
| Flag | Config File | คำอธิบาย |
|------|-------------|----------|
| `sharepoint.enabled` | kasset_infra.yaml | **false** = ใช้ local Cache/ |
| `cache.delete_after_upload` | kasset_infra.yaml | ลบ cache หลังสำเร็จ |
| `email.enabled` | kasset_infra.yaml | เปิด/ปิด email notification |

### 4. การตั้งค่า Logging
```python
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        FileHandler(f"Logs/log_{today}.txt"),
        StreamHandler()  # Console output
    ]
)
```

### 5. กลยุทธ์ Error Handling
- Extraction errors: Log และตั้ง status = "failed"
- Email errors: Log เท่านั้น (ไม่ให้ fail ทั้ง process)
- Cleanup errors: Log เท่านั้น

---

## ฟังก์ชันที่ต้องสร้าง (Clean Code)

| ฟังก์ชัน | หน้าที่ |
|----------|---------|
| `main()` | Entry point, orchestrate ทุกขั้นตอน |
| `_get_today_string()` | return "YYYYMMDD" |
| `_setup_logging(logs_dir, today)` | ตั้งค่า file + console logging |
| `_get_cache_paths(config)` | return dict ของ paths จาก config |
| `_save_results_json(results, outputs_dir, today)` | บันทึก extraction_results.json |
| `_cleanup_temp(temp_dir, logger)` | ลบ temp directory |

---

## Prompt ที่ใช้

```
เขียน clean Python code สำหรับ src/main.py

ข้อกำหนด:
1. สร้าง main() function เป็น entry point
   - โหลด config จาก config/kasset_infra.yaml
   - ตั้งค่า logging ไป file และ console
   - ดึงวันที่วันนี้เป็น YYYYMMDD string
2. สร้าง _setup_logging(logs_dir: Path, today: str) -> Logger
   - File handler: logs_dir/log_YYYY-MM-DD.txt
   - Console handler สำหรับ output แบบ real-time
3. สร้าง _get_cache_paths(config: dict, base_dir: Path) -> dict
   - return {"inputs": Path, "outputs": Path, "temp": Path}
4. สร้าง _save_results_json(results: dict, outputs_dir: Path, today: str) -> None
   - บันทึกเป็น extraction_results_YYYY-MM-DD.json
5. สร้าง _cleanup_temp(temp_dir: Path, logger: Logger) -> None
   - ลบ temp directory
6. Main flow:
   - Load config
   - Setup logging
   - Get cache paths
   - Run extraction pipeline (from Cache/Inputs)
   - Save results JSON
   - Send email (if configured)
   - Cleanup temp
7. SharePoint disabled: ใช้ local Cache/ folder
8. แต่ละฟังก์ชันไม่เกิน 15 บรรทัด
9. เพิ่ม if __name__ == "__main__": main()

อ้างอิง: Original Code/daily_main.py
```
