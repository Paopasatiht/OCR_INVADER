# คู่มือการเขียน Clean Code ทีละขั้นตอน

## โปรเจค: OCR Smart Reconcile

## หลักการ Clean Code (CI)
- **1 Function = 1 หน้าที่**: แต่ละฟังก์ชันทำงานเพียงอย่างเดียว
- **ฟังก์ชันสั้น**: ไม่เกิน 15-20 บรรทัด
- **อ่านง่าย**: ตั้งชื่อชัดเจน, ไม่ซ้อน logic ลึกเกินไป

---

## วิธีทำงาน: Write → Test → Pass → Next

```
┌─────────────────────────────────────────────────┐
│  Step N                                         │
│  1. เขียน code ตาม prompt                        │
│  2. เขียน test ใน main.py                        │
│  3. รัน: python src/main.py                     │
│  4. ถ้า PASS → ไป Step N+1                       │
│  5. ถ้า FAIL → แก้ไขแล้วรันใหม่                    │
└─────────────────────────────────────────────────┘
```

---

## ลำดับการเขียนโมดูล

```
Phase 1: Foundation (ไม่มี dependencies)
├── Step 01: src/models.py           → Data classes
├── Step 02: src/config.py           → โหลด configuration
└── Step 03: src/utils/helpers.py    → ฟังก์ชันช่วยเหลือ

Phase 2: Utils Services (ต้องการ Phase 1)
├── Step 04: src/utils/ocr.py        → Azure DI client + classify + extract
├── Step 05: src/utils/sharepoint.py → SharePoint I/O
└── Step 06: src/utils/email.py      → ส่ง Email แจ้งเตือน

Phase 3: Business Logic (ต้องการ Phase 1 + 2)
├── Step 07: src/mappers.py          → แปลงข้อมูล
└── Step 08: src/pipeline.py         → Pipeline หลัก

Phase 4: Entry Point (ต้องการทุก Phase)
└── Step 09: src/main.py             → Entry point จริง
```

---

## โครงสร้างแต่ละ Step

แต่ละไฟล์ step มี 4 ส่วน:

### 1. หน้าที่โมดูล
อธิบายว่าโมดูลนี้ทำอะไร

### 2. แนวคิดสำคัญ
สิ่งที่ต้องเข้าใจก่อนเขียน code

### 3. Prompt ที่ใช้
Copy prompt นี้ไปถาม Claude เพื่อสร้าง code

### 4. Test ใน main.py
Code สำหรับทดสอบใน main.py พร้อม expected output

---

## โครงสร้างโฟลเดอร์ (เป้าหมาย)

```
KA_CG_CI/
├── .env                     # 🔑 API Keys (ไม่ commit!)
├── .env.example             # Template
├── .gitignore               # มี .env
│
├── src/
│   ├── main.py              # Step 09 - Entry point
│   ├── models.py            # Step 01 - Data classes
│   ├── config.py            # Step 02 - Config + .env loading
│   ├── utils/
│   │   ├── helpers.py       # Step 03 - Normalize functions
│   │   ├── ocr.py           # Step 04 - Azure DI
│   │   ├── sharepoint.py    # Step 05 - SharePoint
│   │   └── email.py         # Step 06 - Email
│   ├── mappers.py           # Step 07 - Data mapping
│   └── pipeline.py          # Step 08 - Pipeline
│
├── config/
│   ├── azure.yaml           # Azure services (ใช้ ${VAR})
│   ├── kasset_infra.yaml    # Infrastructure
│   └── mapper/              # Mapping configs (YAML)
│       ├── agent.yaml
│       ├── bank_code.yaml
│       └── ...
│
├── Config/
│   └── ocr.yaml             # OCR extractors
│
├── Cache/
│   ├── Inputs/              # Input files
│   ├── Outputs/             # Output Excel/JSON
│   └── Temp/                # Temporary files
│
└── Logs/                    # Log files
```

---

## วิธีใช้คู่มือนี้

1. **อ่าน Step 01** - ทำความเข้าใจ models.py
2. **Copy Prompt** - ไปถาม Claude สร้าง code
3. **วาง code** - ใน src/models.py
4. **Copy Test** - ไปวางใน src/main.py
5. **รัน Test** - `python src/main.py`
6. **ดู Output** - ถ้าตรงกับ Expected → PASS!
7. **ไป Step 02** - ทำซ้ำจนครบ

---

## Quick Reference

| Step | Module | Test Focus |
|------|--------|------------|
| 01 | models.py | สร้าง TransactionRecord, DateNormOptions |
| 02 | config.py | โหลด config.yaml |
| 03 | utils/helpers.py | normalize_date, normalize_amount |
| 04 | utils/ocr.py | create_client, classify, extract |
| 05 | utils/sharepoint.py | list, download, upload |
| 06 | utils/email.py | send_summary_email |
| 07 | mappers.py | map_single, map_multiple, etc. |
| 08 | pipeline.py | run_extraction_pipeline |
| 09 | main.py | Full integration |
