# Step 01: Models (Data Classes)

## โมดูล: `src/models.py`

## หน้าที่
กำหนดโครงสร้างข้อมูลหลักของระบบ:
- `TransactionRecord` - เก็บข้อมูล transaction ที่ดึงมาได้
- `DateNormOptions` - ตัวเลือกการแปลงวันที่
- `FINNETTransactionRecord` - ข้อมูล FINNET พิเศษ

## ไฟล์ต้นฉบับ
`Original Code/Functions/mappers/base.py`

---

## แนวคิดสำคัญ

### 1. TransactionRecord Fields
| Field | Type | คำอธิบาย |
|-------|------|----------|
| agent | str | ชื่อบริษัท/ตัวแทน |
| payment_type | str | "C" = Cash, "T" = Transfer |
| bank_code | str | รหัสธนาคาร (เช่น "014") |
| bank_account_no_fmt | str | "014 SCB 1234567890" |
| amount | str | "1,234.00" |
| date | str | "dd/mm/yyyy" |
| source_kind | str | "Single", "Multiple", "Slip", "Excel", "FINNET" |
| source_file | str | path ไฟล์ต้นฉบับ |

### 2. DateNormOptions Fields
| Field | Default | คำอธิบาย |
|-------|---------|----------|
| prefer_buddhist_shorthand | False | ปีย่อ 2 หลักเป็น พ.ศ.? |
| locale_hint | "en" | "th" หรือ "en" |

---

## Prompt ที่ใช้

```
เขียน clean Python code สำหรับ src/models.py

ข้อกำหนด:
1. ใช้ @dataclass decorator
2. สร้าง TransactionRecord ที่มี fields:
   - agent: str
   - payment_type: str (default "C")
   - bank_code: str
   - bank_account_no_fmt: str
   - amount: str
   - date: str
   - source_kind: str
   - source_file: str
3. สร้าง DateNormOptions ที่มี fields:
   - prefer_buddhist_shorthand: bool = False
   - locale_hint: str = "en"
4. สร้าง FINNETTransactionRecord ที่ inherit จาก TransactionRecord
   - เพิ่ม result_status: str
   - เพิ่ม original_result: str = ""
5. เพิ่ม method to_dict() ใน TransactionRecord
6. เพิ่ม type hints ทุก field
7. ไม่ใช้ external dependencies

อ้างอิง: Original Code/Functions/mappers/base.py
```

---

## Test ใน main.py

```python
"""
Step 01 Test: models.py
"""
from models import TransactionRecord, DateNormOptions, FINNETTransactionRecord


def test_step_01():
    # Test TransactionRecord
    record = TransactionRecord(
        agent="AECS",
        bank_code="002",
        bank_account_no_fmt="002 BBL 1234567890",
        amount="1,234.00",
        date="15/01/2024",
        source_kind="Single",
        source_file="AECS/file.pdf"
    )
    assert record.payment_type == "C"
    assert record.to_dict()["agent"] == "AECS"

    # Test DateNormOptions
    options = DateNormOptions(prefer_buddhist_shorthand=True, locale_hint="th")
    assert options.locale_hint == "th"

    # Test FINNETTransactionRecord
    finnet = FINNETTransactionRecord(
        agent="FINNET",
        bank_code="004",
        bank_account_no_fmt="004 KBANK 9876543210",
        amount="5,000.00",
        date="20/01/2024",
        source_kind="FINNET",
        source_file="FINNET/file.xlsx",
        result_status="success"
    )
    assert finnet.result_status == "success"

    print("STEP 01 PASSED")


if __name__ == "__main__":
    test_step_01()
```

---

## Expected Output

```
STEP 01 PASSED
```

---

## เมื่อ PASS แล้ว

ไปต่อ **Step 02: config.py**
