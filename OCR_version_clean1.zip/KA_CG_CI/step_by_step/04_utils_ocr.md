# Step 04: OCR Module

## โมดูล: `src/utils/ocr.py`

## หน้าที่
จัดการ Azure Document Intelligence สำหรับ OCR:
1. **Config** - โหลด config พร้อม .env expansion
2. **Client** - สร้างและตั้งค่า Azure DI client
3. **Classifier** - จำแนกประเภทเอกสาร
4. **Extractor** - ดึงข้อมูลจากเอกสาร

## ไฟล์ต้นฉบับ
`Original Code/Functions/OCR/OCR.py`

---

## Config Files

### Config/ocr.yaml (ใช้ ${VAR} จาก .env)
```yaml
azure:
  endpoint: "${DI_ENDPOINT}"
  key: "${DI_KEY}"
  api_version: "${DI_API_VERSION}"

client:
  pool_size: 32
  connection_timeout: 300
  read_timeout: 300
  max_retries: 2

classification:
  model_id: "CS-Smart-Reconcile-Classification-20260127"
  confidence_threshold: 0.6

extractors:
  BBL Single:
    model_id: "CS-Smart-reconcile-BBL-Single-Pay-In"
    type: "Single"
  SCB Multiple:
    model_id: "CS-Smart-reconcile-SCB-Multiple-Pay-In"
    type: "Multiple"
```

### .env (API Keys)
```bash
DI_ENDPOINT="https://your-resource.cognitiveservices.azure.com/"
DI_KEY="your-api-key"
DI_API_VERSION="2024-11-30"
```

### ฟังก์ชัน Config
| ฟังก์ชัน | หน้าที่ |
|----------|---------|
| `load_ocr_config(path)` | โหลด YAML พร้อม .env expansion |
| `_expand_env_vars(obj)` | Recursively expand ${VAR} |

---

## ส่วนที่ 1: Client

### แนวคิดสำคัญ

#### 1.1 Azure Document Intelligence
บริการ Azure AI ที่ดึงข้อความ, ตาราง, และข้อมูลโครงสร้างจากเอกสาร:
- **Classifier**: กำหนดประเภทเอกสาร (เช่น "BBL Single", "SCB Multiple")
- **Extractor**: ดึง fields เฉพาะตาม trained model

#### 1.2 Connection Pooling
ใช้ TCP connections ซ้ำสำหรับหลาย requests:
```python
HTTPAdapter(pool_connections=32, pool_maxsize=32)
```

#### 1.3 Retry Configuration
```python
Retry(
    total=2,
    backoff_factor=0.5,  # รอ 0.5s, 1s, 2s...
    status_forcelist=[408, 500, 502, 503, 504]
)
```

### ฟังก์ชัน Client
| ฟังก์ชัน | หน้าที่ |
|----------|---------|
| `create_client(endpoint, key, settings)` | factory function หลัก |
| `_create_session(pool_size)` | สร้าง requests.Session พร้อม pooling |
| `_configure_retry(max_retries)` | สร้าง Retry policy |
| `_create_transport(session, timeout)` | สร้าง Azure transport layer |

---

## ส่วนที่ 2: Classifier

### แนวคิดสำคัญ

#### 2.1 ขั้นตอนการจำแนก
```
Input File (PDF/Image)
    ↓
แบ่ง PDF เป็นหน้า (ถ้าเป็น PDF)
    ↓
ส่งแต่ละหน้าไป Azure Classifier
    ↓
ได้ผลลัพธ์: { doc_type: "BBL Single", confidence: 0.95 }
    ↓
กรองตาม confidence threshold (default 0.6)
```

#### 2.2 ประเภทไฟล์ที่รองรับ
| ประเภท | นามสกุล |
|--------|---------|
| PDF | .pdf |
| Images | .png, .jpg, .jpeg, .tif, .bmp |

#### 2.3 การจัดการ PDF ด้วย PyMuPDF
```python
doc = fitz.open(pdf_path)
for i in range(doc.page_count):
    single = fitz.open()
    single.insert_pdf(doc, from_page=i, to_page=i)
    page_bytes = single.tobytes()
```

### ฟังก์ชัน Classifier
| ฟังก์ชัน | หน้าที่ |
|----------|---------|
| `split_pdf_to_pages(pdf_path)` | แบ่ง PDF, return list ของ (page_num, BytesIO) |
| `check_pdf_openable(pdf_path)` | ตรวจสอบว่า PDF เปิดได้ |
| `classify_document(client, stream, content_type, classifier_id)` | จำแนกเอกสารเดี่ยว |
| `classify_pdf(client, pdf_path, classifier_id)` | จำแนกทุกหน้าใน PDF |
| `classify_image(client, image_path, classifier_id)` | จำแนกภาพเดี่ยว |
| `classify_directory(client, root_dir, classifier_id)` | จำแนกทุกไฟล์แบบ recursive |

---

## ส่วนที่ 3: Extractor

### แนวคิดสำคัญ

#### 3.1 ขั้นตอนการดึงข้อมูล
```
Classification Results
    ↓
จัดกลุ่มตามประเภทเอกสาร
    ↓
หา model_id จาก model_ids.json
    ↓
เรียก Azure analyze_document
    ↓
Return ผลลัพธ์แบบ structured
```

#### 3.2 Model IDs Configuration
```json
{
    "Doc_Classifier": "CS-Smart-Reconcile-Classification",
    "BBL Single": {
        "modelId": "CS-Smart-reconcile-BBL-Single-Pay-In",
        "transactionType": "Single"
    }
}
```

#### 3.3 โครงสร้างผลลัพธ์
```python
{
    "Single": [{
        "page_key": "file_page_1",
        "file_path": "agent/file.pdf",
        "doc_type": "BBL Single",
        "analyze_result": {...}
    }],
    "Multiple": [...],
    "Slip": [...]
}
```

### ฟังก์ชัน Extractor
| ฟังก์ชัน | หน้าที่ |
|----------|---------|
| `extract_documents(client, grouped_docs, model_map)` | entry point |
| `group_by_document_type(results, threshold)` | จัดกลุ่มตาม doc_type |
| `get_model_info(doc_type, model_map)` | ดึง model_id, transaction_type |
| `analyze_document(client, model_id, stream, content_type)` | เรียก Azure extraction |
| `analyze_with_retry(client, model_id, stream, content_type, max_attempts)` | retry wrapper |
| `extract_group_parallel(client, model_id, pages, max_workers)` | parallel extraction |

---

## Prompt ที่ใช้

```
เขียน clean Python code สำหรับ src/utils/ocr.py

ข้อกำหนด:

## ส่วน Client
1. สร้าง create_client(endpoint: str, key: str, settings: dict) -> DocumentIntelligenceClient | None
   - settings ต้องมี: pool_size, connection_timeout, read_timeout, max_retries
   - return None ถ้า endpoint หรือ key ไม่มี
2. สร้าง _create_session(pool_size: int) -> requests.Session
   - ตั้งค่า HTTPAdapter พร้อม connection pooling
3. สร้าง _configure_retry(max_retries: int) -> Retry
   - Retry บน status codes: 408, 500, 502, 503, 504
   - ใช้ exponential backoff (factor=0.5)

## ส่วน Classifier
4. สร้าง split_pdf_to_pages(pdf_path: Path) -> list[tuple[int, BytesIO]]
   - ใช้ PyMuPDF (fitz) แบ่ง PDF
5. สร้าง check_pdf_openable(pdf_path: Path) -> tuple[bool, bool, str | None]
   - return (openable, is_encrypted, error_message)
6. สร้าง classify_document(client, stream: BytesIO, content_type: str, classifier_id: str) -> Any
7. สร้าง classify_directory(client, root_dir: Path, classifier_id: str, max_workers: int = 4) -> list[dict]
   - จำแนกแบบ parallel ใช้ ThreadPoolExecutor

## ส่วน Extractor
8. สร้าง extract_documents(client, classification_results: list, model_map: dict, confidence_threshold: float = 0.6) -> tuple[dict, list]
   - return (extraction_results_by_type, failed_files)
9. สร้าง group_by_document_type(results: list, threshold: float) -> dict[str, dict]
10. สร้าง analyze_document(client, model_id: str, stream: BytesIO, content_type: str) -> dict
11. สร้าง analyze_with_retry(client, model_id, stream, content_type, max_attempts: int = 2) -> dict
12. สร้าง extract_group_parallel(client, model_id: str, pages: dict, max_workers: int = 4) -> list[dict]

## ข้อกำหนดทั่วไป
- แต่ละฟังก์ชันไม่เกิน 20 บรรทัด
- ใช้ logging สำหรับ errors และ progress
- เพิ่ม type hints

Dependencies:
- azure.ai.documentintelligence.DocumentIntelligenceClient
- azure.core.credentials.AzureKeyCredential
- PyMuPDF (fitz)
- requests, urllib3

อ้างอิง: Original Code/Functions/OCR/OCR.py
```
