# OCR Smart Reconcile - Program Flow Guide

## สำหรับ Junior Programmer 🚀

---

## 1. ภาพรวมของโปรแกรม (Big Picture)

โปรแกรมนี้ทำหน้าที่ **อ่านเอกสารการเงิน** (ใบนำฝาก, สลิป, Excel) แล้ว **แปลงเป็นข้อมูล** ที่ใช้งานได้

```
┌─────────────────────────────────────────────────────────────────┐
│                         INPUT                                    │
│  📄 PDF ใบนำฝาก    🖼️ รูปสลิป    📊 Excel                        │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                      PROCESSING                                  │
│  1. จัดหมวดหมู่ไฟล์ (Classify)                                   │
│  2. OCR อ่านข้อความ (Azure AI)                                   │
│  3. แปลงข้อมูล (Map to Records)                                  │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                         OUTPUT                                   │
│  📊 Excel สรุปรายการ    📧 Email แจ้งเตือน                       │
└─────────────────────────────────────────────────────────────────┘
```

---

## 2. โครงสร้างโฟลเดอร์ (Folder Structure)

```
KA_CG_CI/
│
├── 📄 .env                      ← 🔑 API Keys (ไม่ commit!)
├── 📄 .env.example              ← Template สำหรับ .env
├── 📄 .gitignore                ← มี .env อยู่แล้ว
│
├── 📁 Cache/                    ← ข้อมูลที่ต้องประมวลผล
│   ├── Inputs/                  ← ใส่ไฟล์ตรงนี้!
│   │   ├── AECS/               ← แยกตาม Agent
│   │   │   └── deposit.pdf
│   │   ├── XYZ/
│   │   │   └── slip.png
│   │   └── FINNET/             ← ไฟล์ FINNET Excel
│   │       └── data.xlsx
│   ├── Outputs/                 ← ผลลัพธ์ออกตรงนี้
│   │   ├── payin_mapping_20260130.xlsx
│   │   └── extraction_results_2026-01-30.json
│   └── Temp/                    ← ไฟล์ชั่วคราว (ถูกลบทิ้ง)
│
├── 📁 Config/                   ← ตั้งค่า OCR extractors
│   └── ocr.yaml                ← model_id mappings
│
├── 📁 config/                   ← ตั้งค่าทั่วไป
│   ├── azure.yaml              ← Azure credentials (ใช้ ${VAR})
│   ├── kasset_infra.yaml       ← ตั้งค่าหลัก
│   └── mapper/                  ← ตั้งค่า mapping
│       ├── agent.yaml          ← 53 agents
│       ├── bank_code.yaml      ← 17 bank accounts
│       ├── default_account.yaml
│       ├── finnet.yaml
│       ├── multiple_ocr/       ← OCR table schemas
│       │   ├── bbl.yaml
│       │   ├── scb.yaml
│       │   └── ...
│       └── excel_schema/       ← Excel schemas
│           └── kbank_unitlink.yaml
│
├── 📁 Logs/                     ← Log files
│   └── log_2026-01-30.txt
│
└── 📁 src/                      ← Source code
    ├── main.py                  ← 🚀 จุดเริ่มต้น!
    ├── config.py               ← Config loading + .env
    ├── pipeline.py
    ├── mappers.py
    ├── models.py
    └── utils/
        ├── ocr.py
        ├── email.py
        ├── sharepoint.py
        └── helpers.py
```

---

## 3. การทำงานทีละขั้นตอน (Step-by-Step Flow)

### 🚀 Step 1: เริ่มต้นโปรแกรม (main.py)

```python
# เมื่อรัน: python main.py

def main():
    # 1. หาวันที่วันนี้
    today = "20260130"           # สำหรับชื่อไฟล์ output
    today_dashed = "2026-01-30"  # สำหรับ log

    # 2. โหลด config
    config = load_config("config/kasset_infra.yaml")

    # 3. ตั้งค่า logging
    logger = setup_logging("Logs/", today_dashed)
    # → สร้างไฟล์: Logs/log_2026-01-30.txt

    # 4. รัน pipeline
    results = run_extraction_pipeline(...)
```

**💡 เข้าใจง่าย:** main.py เหมือน "ผู้จัดการ" ที่สั่งงานทุกอย่าง

---

### 📂 Step 2: จัดหมวดหมู่ไฟล์ (pipeline.py - classify_inputs)

```python
def classify_inputs(input_dir):
    """แยกไฟล์เป็น 4 กลุ่ม"""

    buckets = {
        "azure": [],   # PDF/รูป → ส่งไป OCR
        "excel": [],   # Excel ทั่วไป
        "finnet": [],  # FINNET Excel
        "skipped": [], # ไฟล์ที่ข้าม (zip, doc, etc.)
    }

    for file in input_dir.rglob("*"):
        if file.suffix == ".pdf":
            buckets["azure"].append(file)
        elif file.suffix in [".png", ".jpg"]:
            buckets["azure"].append(file)
        elif file.suffix == ".xlsx" and "FINNET" in file.parent.name:
            buckets["finnet"].append(file)
        elif file.suffix == ".xlsx":
            buckets["excel"].append(file)
        else:
            buckets["skipped"].append(file)

    return buckets
```

**ตัวอย่าง:**
```
Input:
  Cache/Inputs/AECS/deposit.pdf     → azure
  Cache/Inputs/XYZ/slip.png         → azure
  Cache/Inputs/data.xlsx            → excel
  Cache/Inputs/FINNET/finnet.xlsx   → finnet
  Cache/Inputs/readme.txt           → skipped
```

---

### 🔍 Step 3: OCR อ่านเอกสาร (utils/ocr.py)

```
┌────────────────┐     ┌─────────────────┐     ┌────────────────┐
│   PDF/Image    │ ──► │   Azure AI      │ ──► │  Extracted     │
│   deposit.pdf  │     │   Document      │     │  Data (JSON)   │
└────────────────┘     │   Intelligence  │     └────────────────┘
                       └─────────────────┘
```

**OCR ทำ 2 ขั้นตอน:**

#### 3.1 Classification - จำแนกประเภทเอกสาร
```python
def classify_directory(client, inbox_dir, classifier_id):
    """ส่งเอกสารไป Azure เพื่อจำแนกประเภท"""

    # Azure ตอบกลับมาว่าเอกสารนี้เป็นประเภทอะไร
    # เช่น: "BBL Single", "SCB Multiple", "PromptPay Slip"

    results = []
    for file in inbox_dir.iterdir():
        result = client.begin_classify_document(classifier_id, file)
        doc_type = result.documents[0].doc_type  # "BBL Single"
        results.append({"file": file, "doc_type": doc_type})

    return results
```

#### 3.2 Extraction - ดึงข้อมูลจากเอกสาร
```python
def extract_documents(client, classified_files, extractors):
    """ดึงข้อมูลจากเอกสารตามประเภท"""

    for item in classified_files:
        doc_type = item["doc_type"]       # "BBL Single"
        model_id = extractors[doc_type]   # model ที่ train มาสำหรับ BBL

        # Azure อ่านและดึงข้อมูล
        result = client.begin_analyze_document(model_id, item["file"])

        # ได้ข้อมูลกลับมา:
        fields = {
            "Bank Account No.": "1234567890",
            "Amount": "50,000.00",
            "Date": "15/01/2567"
        }
```

**💡 เข้าใจง่าย:**
- Classification = ดูว่าเอกสารเป็นใบอะไร (BBL? SCB? Slip?)
- Extraction = อ่านตัวเลขจากเอกสารนั้น

---

### 🔄 Step 4: แปลงข้อมูล (mappers.py)

```python
# ข้อมูลดิบจาก OCR
raw_data = {
    "Bank Account No.": "1234567890",
    "Amount": "๕๐,๐๐๐.๐๐",      # ตัวเลขไทย!
    "Date": "15/01/2567"          # ปี พ.ศ.!
}

# หลังจาก normalize
clean_data = {
    "bank_account": "1234567890",
    "amount": "50000.00",         # ตัวเลขอารบิก
    "date": "2024-01-15"          # ปี ค.ศ.
}
```

**Mappers แต่ละประเภท:**

| Mapper | Input | หน้าที่ |
|--------|-------|---------|
| `map_single_transactions` | ใบนำฝาก 1 รายการ | 1 เอกสาร = 1 record |
| `map_multiple_transactions` | ใบนำฝากหลายรายการ | 1 เอกสาร = หลาย records (ตาราง) |
| `map_slip_transactions` | สลิป PromptPay | แก้ปัญหาเลขบัญชีถูก mask |
| `map_excel_files` | Excel ทั่วไป | อ่านตาม schema |
| `map_finnet_files` | FINNET Excel | format เฉพาะ FINNET |

---

### 📊 Step 5: สร้าง Output (pipeline.py)

```python
# รวมข้อมูลทั้งหมดเป็น DataFrame
all_records = single_records + multiple_records + slip_records + excel_records

# สร้าง DataFrame
df = pd.DataFrame([record.to_dict() for record in all_records])

# บันทึกเป็น Excel
df.to_excel("Cache/Outputs/payin_mapping_20260130.xlsx")
```

**ตัวอย่าง Output Excel:**

| agent | bank_code | bank_account_no_fmt | amount | date | source_kind | source_file |
|-------|-----------|---------------------|--------|------|-------------|-------------|
| AECS | 002 | 002 BBL 1234567890 | 50000.00 | 2024-01-15 | Single | AECS/deposit.pdf |
| XYZ | 014 | 014 SCB 9876543210 | 25000.00 | 2024-01-15 | Slip | XYZ/slip.png |

---

## 4. Data Flow Diagram

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                              main.py                                         │
│                           (Orchestrator)                                     │
└─────────────────────────────────────────────────────────────────────────────┘
                                    │
                                    ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                            pipeline.py                                       │
│                                                                              │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐                   │
│  │ classify_    │    │ run_ocr_     │    │ build_all_   │                   │
│  │ inputs()     │───►│ extraction() │───►│ dataframes() │                   │
│  └──────────────┘    └──────────────┘    └──────────────┘                   │
│         │                   │                   │                            │
└─────────┼───────────────────┼───────────────────┼────────────────────────────┘
          │                   │                   │
          ▼                   ▼                   ▼
   ┌─────────────┐    ┌─────────────┐    ┌─────────────┐
   │ File System │    │ utils/ocr.py│    │ mappers.py  │
   │ (Cache/)    │    │ (Azure AI)  │    │ (Transform) │
   └─────────────┘    └─────────────┘    └─────────────┘
                                                │
                                                ▼
                                         ┌─────────────┐
                                         │ models.py   │
                                         │ Transaction │
                                         │ Record      │
                                         └─────────────┘
```

---

## 5. ตัวอย่างการทำงานจริง (Real Example)

### Input
```
Cache/Inputs/
├── AECS/
│   └── bbl_deposit_001.pdf    # ใบนำฝาก BBL
└── XYZ/
    └── promptpay_slip.png      # สลิป PromptPay
```

### Processing Log
```
2026-01-30 09:00:01 [INFO] Starting OCR pipeline for 20260130
2026-01-30 09:00:01 [INFO] Pre-classified: azure=2, excel=0, finnet=0, skipped=0
2026-01-30 09:00:02 [INFO] Classifying documents...
2026-01-30 09:00:05 [INFO] - bbl_deposit_001.pdf → BBL Single
2026-01-30 09:00:07 [INFO] - promptpay_slip.png → PromptPay Slip
2026-01-30 09:00:08 [INFO] Extracting documents...
2026-01-30 09:00:15 [INFO] Single: 1 records, 0 failed
2026-01-30 09:00:16 [INFO] Slip: 1 records, 0 failed
2026-01-30 09:00:17 [INFO] Saved output: payin_mapping_20260130.xlsx (2 rows)
2026-01-30 09:00:17 [INFO] Pipeline completed with status: success
```

### Output
```
Cache/Outputs/
├── payin_mapping_20260130.xlsx
└── extraction_results_2026-01-30.json
```

---

## 6. Config Files อธิบาย

### .env (API Keys - ไม่ commit!)
```bash
# Azure Document Intelligence (OCR)
DI_ENDPOINT="https://your-resource.cognitiveservices.azure.com/"
DI_KEY="your-api-key"
DI_API_VERSION="2024-11-30"

# Azure OpenAI (สำหรับ future use)
AZURE_OPENAI_KEY="your-openai-key"
AZURE_OPENAI_RESOURCE="https://your-resource.openai.azure.com/"

# Azure Cognitive Search (สำหรับ future use)
COG_SEARCH_ENDPOINT="https://your-search.search.windows.net"
COG_SEARCH_ADMIN_KEY="your-search-key"
```

**สำคัญ:**
- ไฟล์ `.env` อยู่ใน `.gitignore` แล้ว = ไม่ถูก commit
- ใช้ `.env.example` เป็น template

### azure.yaml (ใช้ ${VAR} จาก .env)
```yaml
document_intelligence:
  endpoint: "${DI_ENDPOINT}"      # ดึงจาก .env
  key: "${DI_KEY}"                # ดึงจาก .env
  api_version: "${DI_API_VERSION}"
  connection_timeout: 300
  read_timeout: 300

openai:
  endpoint: "${AZURE_OPENAI_RESOURCE}"
  key: "${AZURE_OPENAI_KEY}"

cognitive_search:
  endpoint: "${COG_SEARCH_ENDPOINT}"
  admin_key: "${COG_SEARCH_ADMIN_KEY}"
```

### kasset_infra.yaml (ตั้งค่าหลัก)
```yaml
# ที่อยู่ folders
paths:
  cache_inputs: Cache/Inputs      # อ่านไฟล์จากที่นี่
  cache_outputs: Cache/Outputs    # เขียนผลลัพธ์ที่นี่
  cache_temp: Cache/Temp          # ไฟล์ชั่วคราว
  logs: Logs                      # log files

# SharePoint (ปิดอยู่ = ใช้ local folder)
sharepoint:
  enabled: false

# Email notification
email:
  enabled: false                  # true = ส่ง email หลังเสร็จ
  smtp_server: smtp.example.com
  to:
    - "team@example.com"
```

### ocr.yaml (ตั้งค่า Azure OCR)
```yaml
azure:
  endpoint: "https://xxx.cognitiveservices.azure.com"
  key: "your-api-key"

# Model สำหรับแต่ละประเภทเอกสาร
extractors:
  "BBL Single":
    model_id: "bbl-single-model-v1"
    type: "Single"
  "SCB Multiple":
    model_id: "scb-multiple-model-v1"
    type: "Multiple"
  "PromptPay Slip":
    model_id: "promptpay-slip-model-v1"
    type: "Slip"
```

### bank_code.yaml (mapping เลขบัญชี)
```yaml
# เลขบัญชี → ข้อมูลธนาคาร
"1234567890":
  bank_code: "002"
  bank: "BBL"
  account_no: "1234567890"

"9876543210":
  bank_code: "014"
  bank: "SCB"
  account_no: "9876543210"
```

---

## 7. Error Handling

โปรแกรมจัดการ error แบบนี้:

```python
# ถ้า OCR fail → log error, ไปไฟล์ถัดไป
try:
    result = extract_document(file)
except Exception as e:
    logger.error(f"Failed: {file} - {e}")
    failed_files.append({"file": file, "error": str(e)})
    continue  # ไปไฟล์ถัดไป

# ถ้า Email fail → log warning เท่านั้น (ไม่ fail ทั้ง process)
try:
    send_email(results)
except Exception as e:
    logger.warning(f"Email failed: {e}")
    # ไม่ raise error, ให้โปรแกรมทำงานต่อ
```

**หลักการ:**
- OCR error → บันทึก failed_files, ทำต่อ
- Mapping error → บันทึก failed_files, ทำต่อ
- Email error → Log warning, ทำต่อ
- Critical error → Log exception, หยุดทำงาน

---

## 8. วิธีรันโปรแกรม

### ขั้นตอนที่ 1: เตรียมไฟล์
```bash
# ใส่ไฟล์ใน Cache/Inputs/ แยกตาม agent
Cache/Inputs/AECS/file1.pdf
Cache/Inputs/XYZ/file2.png
Cache/Inputs/FINNET/data.xlsx
```

### ขั้นตอนที่ 2: รันโปรแกรม
```bash
cd KA_CG_CI/src
python main.py
```

### ขั้นตอนที่ 3: ดูผลลัพธ์
```bash
# Output Excel
Cache/Outputs/payin_mapping_YYYYMMDD.xlsx

# Log file
Logs/log_YYYY-MM-DD.txt

# Results JSON
Cache/Outputs/extraction_results_YYYY-MM-DD.json
```

---

## 9. Debugging Tips

### ดู Log
```bash
# Windows
type Logs\log_2026-01-30.txt

# หรือเปิดด้วย text editor
```

### ตรวจสอบ Results JSON
```python
import json

with open("Cache/Outputs/extraction_results_2026-01-30.json") as f:
    results = json.load(f)

# ดู status
print(results["status"])  # "success", "partial", "failed"

# ดูไฟล์ที่ fail
print(results["failed_mapping_files"])

# ดูไฟล์ที่ skip
print(results["skipped_files"])
```

### Test แต่ละ module
```bash
cd src

# Test models
python -c "from models import TransactionRecord; print('OK')"

# Test helpers
python -c "from utils.helpers import normalize_amount; print(normalize_amount('๑,๒๓๔'))"

# Test mappers
python test_step_07.py
```

---

## 10. สรุป Module ทั้งหมด

| Module | ไฟล์ | หน้าที่หลัก |
|--------|------|-------------|
| **Models** | models.py | กำหนดโครงสร้างข้อมูล (TransactionRecord) |
| **Config** | config.py | โหลด config files |
| **Helpers** | utils/helpers.py | Normalize ข้อมูล (วันที่, ตัวเลข, เลขบัญชี) |
| **OCR** | utils/ocr.py | เชื่อมต่อ Azure AI อ่านเอกสาร |
| **SharePoint** | utils/sharepoint.py | (ปิดอยู่) ดาวน์โหลด/อัปโหลดไฟล์ |
| **Email** | utils/email.py | ส่ง email แจ้งผล |
| **Mappers** | mappers.py | แปลงข้อมูล OCR → Records |
| **Pipeline** | pipeline.py | Orchestrate OCR + Mapping |
| **Main** | main.py | Entry point, รันทุกอย่าง |

---

## 11. คำถามที่พบบ่อย (FAQ)

**Q: ทำไมต้องแยก folder ตาม Agent?**
A: เพื่อให้โปรแกรมรู้ว่าไฟล์นี้มาจาก agent ไหน (AECS, XYZ, etc.) จะได้ใส่ข้อมูลถูกต้อง

**Q: ถ้า OCR อ่านผิดทำยังไง?**
A: ดูใน failed_mapping_files ใน results JSON แล้วตรวจสอบไฟล์ต้นฉบับ

**Q: รองรับไฟล์อะไรบ้าง?**
A: PDF, PNG, JPG, JPEG, TIF, TIFF, BMP, XLSX, XLS, CSV

**Q: ทำไมบางไฟล์ถูก skip?**
A: ไฟล์ประเภท .zip, .rar, .doc, .txt จะถูก skip อัตโนมัติ

---

**Happy Coding! 🎉**
