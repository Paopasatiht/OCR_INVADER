# Step 08: Pipeline Module

## โมดูล: `src/pipeline.py`

## หน้าที่
จัดการ pipeline การ extraction ทั้งหมด:
1. **Pre-Classification** - แบ่งไฟล์เป็น buckets ก่อนส่ง Azure
2. **OCR Extraction** - รัน classify + extract
3. **Mapping** - แปลงผลลัพธ์เป็น TransactionRecords
4. **Output** - สร้างและบันทึก DataFrames

## ไฟล์ต้นฉบับ
- `Original Code/Functions/PreClassification.py`
- `Original Code/Functions/Extraction_Core.py`
- `Original Code/Functions/Mapping_to_Excel.py`

---

## ส่วนที่ 1: Pre-Classification

### 1.1 Buckets สำหรับแบ่งประเภท
| Bucket | นามสกุล | คำอธิบาย |
|--------|---------|----------|
| azure | .pdf, .png, .jpg, .jpeg, .tif, .bmp | ส่งไป Azure DI |
| excel | .xlsx, .xls, .csv | ประมวลผลด้วย pandas |
| finnet | .xlsx (ในโฟลเดอร์ FINNET) | จัดการแบบ FINNET พิเศษ |
| skipped | .zip, .doc, .txt, etc. | ไม่รองรับ |

### 1.2 Logic การจำแนกไฟล์
```
สำหรับแต่ละไฟล์ใน input directory:
    ถ้า parent folder == "FINNET":
        → finnet bucket
    ถ้าเป็น PDF/Image:
        → azure bucket
    ถ้าเป็น Excel:
        → excel bucket
    อื่นๆ:
        → skipped bucket (พร้อมเหตุผล)
```

### 1.3 การเตรียมไฟล์สำหรับ DI
ไฟล์ Azure จะถูก copy ไปยังโฟลเดอร์ "di_inbox" ชั่วคราว

### ฟังก์ชัน Pre-Classification
| ฟังก์ชัน | หน้าที่ |
|----------|---------|
| `classify_inputs(input_dir, finnet_folder_name)` | entry หลัก, return buckets dict |
| `_classify_file(file_path, finnet_folder_name)` | จำแนกไฟล์เดี่ยว |
| `_get_file_bucket(extension, parent_folder, finnet_name)` | กำหนด bucket |
| `stage_for_azure(files, inbox_dir, input_dir)` | copy ไฟล์ไป DI inbox |

### Constants
```python
IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp", ".gif", ".webp"}
PDF_EXTENSION = ".pdf"
EXCEL_EXTENSIONS = {".xlsx", ".xls", ".csv"}
SKIP_EXTENSIONS = {".zip", ".rar", ".7z", ".doc", ".docx", ".txt"}
```

---

## ส่วนที่ 2: Pipeline Extraction

### 2.1 ขั้นตอน Pipeline
```
run_extraction_pipeline(inputs_dir, outputs_dir, config)
    │
    ├─► classify_inputs() → {azure, excel, finnet, skipped}
    │
    ├─► stage_for_azure(azure_files) → di_inbox/
    │
    ├─► ocr_extraction(di_inbox) → extraction_results
    │   ├─ classify_directory()
    │   └─ extract_documents()
    │
    ├─► build_all_dataframes(extraction_results + excel + finnet)
    │   ├─ map_single_transactions()
    │   ├─ map_multiple_transactions()
    │   ├─ map_slip_transactions()
    │   ├─ map_excel_files()
    │   └─ map_finnet_files()
    │
    ├─► save_dataframe_outputs()
    │
    └─► Return extraction_results (สำหรับ email)
```

### 2.2 โครงสร้าง Extraction Results
```python
{
    "status": "success",
    "extraction_results": {
        "Single": [...],
        "Multiple": [...],
        "Slip": [...],
        "Excel": ["/path/to/file.xlsx"],
        "FINNET": ["/path/to/finnet.xlsx"]
    },
    "successful_OCR_extraction_files": [...],
    "failed_OCR_classification_files": [...],
    "overall_success_files": [...],
    "skipped_files": [...]
}
```

### 2.3 DataFrame Output
| คอลัมน์ | คำอธิบาย |
|---------|----------|
| Agent | ชื่อ agent/company |
| Payment Type | C (Cash) หรือ T (Transfer) |
| BANK CODE | รหัส 3 หลัก |
| Bank Account No | เลขบัญชีที่ format แล้ว |
| AMOUNT | จำนวนเงินที่ format แล้ว |
| Date | dd/mm/yyyy |
| Source kind | Single/Multiple/Slip/Excel/FINNET |
| Source file | path ไฟล์ต้นฉบับ |

### ฟังก์ชัน Pipeline
| ฟังก์ชัน | หน้าที่ |
|----------|---------|
| `run_extraction_pipeline(inputs_dir, outputs_dir, temp_dir, config_path, today)` | entry point |
| `_load_all_config(config_path)` | โหลดทุก configurations (azure.yaml + .env) |
| `_run_ocr_extraction(di_inbox, config, logger)` | Classify + Extract |
| `build_all_dataframes(extraction_results, config_path, inputs_dir, outputs_dir, today)` | Map ทุกแหล่ง |
| `save_dataframe_outputs(df, outputs_dir, base_name)` | บันทึกเป็น Excel |
| `_track_successful_files(dfs, ocr_success)` | สร้าง success tracking |

### Config Loading Flow
```
_load_all_config(config_path)
    │
    ├─► load_env(base_dir)           # โหลด .env
    │
    ├─► load_azure_config()          # config/azure.yaml + .env expansion
    │   └─► get_document_intelligence_config()
    │
    ├─► load_ocr_config()            # Config/ocr.yaml (extractors)
    │
    ├─► load_mapper_config()         # config/mapper/*.yaml
    │
    └─► load_infra_config()          # config/kasset_infra.yaml
```

---

## Prompt ที่ใช้

```
เขียน clean Python code สำหรับ src/pipeline.py

ข้อกำหนด:

## Pre-Classification
1. สร้าง classify_inputs(input_dir: Path, finnet_folder_name: str = "FINNET") -> dict
   - return {"azure": [], "excel": [], "finnet": [], "skipped": []}
   - scan input_dir แบบ recursive
2. สร้าง _classify_file(file_path: Path, finnet_folder_name: str) -> tuple[str, str | None]
   - return (bucket_name, skip_reason หรือ None)
3. สร้าง _is_pdf(path) -> bool, _is_image(path) -> bool, _is_excel(path) -> bool
4. สร้าง stage_for_azure(files: list[Path], inbox_dir: Path, input_dir: Path) -> Path
   - copy/hardlink ไฟล์ไป inbox_dir
   - รักษาโครงสร้างโฟลเดอร์สัมพัทธ์

## Pipeline
5. สร้าง run_extraction_pipeline(inputs_dir: Path, outputs_dir: Path, temp_dir: Path, config_path: Path, today: str, logger) -> tuple[dict, dict[str, DataFrame]]
   - ฟังก์ชัน orchestration หลัก
   - return (extraction_results, dataframes_by_kind)
6. สร้าง _load_all_config(config_path: Path) -> dict
   - โหลด config.yaml, model_ids.json, bank_codes, agent_names
7. สร้าง _run_ocr_extraction(di_inbox: Path, config: dict, logger) -> dict
   - สร้าง OCR client
   - Classify documents
   - Extract data
8. สร้าง build_all_dataframes(extraction_results: dict, config_path: Path, inputs_dir: Path, outputs_dir: Path, today: str, logger) -> tuple[dict[str, DataFrame], list[dict]]
   - ประมวลผลแต่ละ source kind
   - return (dfs_by_kind, failed_files)
9. สร้าง save_dataframe_outputs(df: DataFrame, outputs_dir: Path, base_name: str, logger) -> None
   - บันทึกเป็น Excel ด้วย openpyxl
   - Format text columns เพื่อรักษา leading zeros
10. สร้าง _track_successful_files(dfs: dict, ocr_success: list) -> list[str]

## ข้อกำหนดทั่วไป
- กำหนด constants ที่ระดับ module สำหรับ extensions
- แต่ละฟังก์ชันไม่เกิน 25 บรรทัด (orchestration อาจยาวกว่าเล็กน้อย)
- ใช้ logging สำหรับติดตาม progress
- ลบ temp files ตอนจบ

อ้างอิง:
- Original Code/Functions/PreClassification.py
- Original Code/Functions/Extraction_Core.py
- Original Code/Functions/Mapping_to_Excel.py
```
