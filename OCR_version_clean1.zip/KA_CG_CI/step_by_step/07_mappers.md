# Step 07: Mappers Module

## โมดูล: `src/mappers.py`

## หน้าที่
แปลงข้อมูลจากหลายแหล่งเป็น TransactionRecord:
1. **Single** - ใบนำฝากแบบ single-transaction
2. **Multiple** - ใบนำฝากแบบ multiple-transaction (ตาราง)
3. **Slip** - สลิป PromptPay/โอนเงิน
4. **Excel** - ไฟล์ Excel ทั่วไป
5. **FINNET** - ไฟล์ Excel รูปแบบ FINNET

## ไฟล์ต้นฉบับ
- `Original Code/Functions/mappers/single_transaction_OCR.py`
- `Original Code/Functions/mappers/multiple_transaction_OCR.py`
- `Original Code/Functions/mappers/slip_transaction_OCR.py`
- `Original Code/Functions/mappers/excel_transaction.py`
- `Original Code/Functions/mappers/FINNET_transaction.py`

---

## Config Structure (YAML)

```
config/mapper/
├── agent.yaml           # agent code → name
├── bank_code.yaml       # account → bank info
├── default_account.yaml # default accounts
├── finnet.yaml          # FINNET config
├── multiple_ocr/        # Multiple OCR schemas
│   ├── bbl.yaml
│   ├── scb.yaml
│   └── kbank.yaml
└── excel_schema/        # Excel schemas
    └── *.yaml
```

### agent.yaml
```yaml
AECS: "AECS - Company Name"
XYZ: "XYZ Holdings"
```

### bank_code.yaml
```yaml
"1234567890":
  bank_code: "002"
  bank: "BBL"
  account_no: "1234567890"
```

### multiple_ocr/bbl.yaml
```yaml
table_types:
  "Transaction Table Type 1":
    columns:
      amount: "Credit amount"
      to_account: "To Account"
      date: "Date"
    row_filter:
      enabled: false
```

### finnet.yaml
```yaml
columns:
  to_account: "To"
  amount: "Amount"
  result: "Result"
success_keywords:
  - "ทำรายการสำเร็จ"
```

---

## ส่วนที่ 1: Single Transaction Mapper

### แนวคิด
หนึ่งเอกสาร = หนึ่ง transaction (เช่น ใบนำฝาก BBL)

### โครงสร้าง Input
```python
{
    "Single": [{
        "file_path": "AECS/file.pdf",
        "analyze_result": {
            "documents": [{
                "fields": {
                    "Bank Account No.": {"valueString": "1234567890"},
                    "Amount": {"valueString": "1,234.00"},
                    "Date": {"valueString": "2024-01-15"}
                }
            }]
        }
    }]
}
```

### ฟังก์ชัน Single
| ฟังก์ชัน | หน้าที่ |
|----------|---------|
| `map_single_transactions(results, config)` | entry point |
| `_map_single_item(item, config)` | แปลง item เดียว |
| `_get_field_value(fields, key)` | ดึง valueString |

---

## ส่วนที่ 2: Multiple Transaction Mapper

### แนวคิด
หนึ่งเอกสาร = หลาย transactions ในตาราง

### ฟังก์ชัน Multiple
| ฟังก์ชัน | หน้าที่ |
|----------|---------|
| `map_multiple_transactions(results, config)` | entry point |
| `_detect_table_type(fields)` | หา field ที่มี valueArray |
| `_load_multiple_schema(schema_dir, doc_type)` | โหลด YAML schema |
| `_map_table_rows(rows, schema, config)` | แปลงทุกแถว |

---

## ส่วนที่ 3: Slip Transaction Mapper

### แนวคิด
สลิป mobile banking ที่เลขบัญชีมักถูก mask

### การ Resolve เลขบัญชีที่ถูก Mask
```
Input: "xxx-x-x6827-x"
Bank Hint: "SCB"
→ ค้นหาบัญชี SCB ที่ลงท้ายด้วย "6827"
→ Match: "4141516827"
```

### ฟังก์ชัน Slip
| ฟังก์ชัน | หน้าที่ |
|----------|---------|
| `map_slip_transactions(results, config)` | entry point |
| `_resolve_masked_account(raw_acc, bank_mapping, bank_hint)` | resolve บัญชี mask |
| `_is_masked_account(acc_str)` | ตรวจสอบ mask chars |

---

## ส่วนที่ 4: Excel Transaction Mapper

### แนวคิด
ใช้ YAML schema กำหนด column mapping, ตรวจจับ schema อัตโนมัติจาก headers

### ฟังก์ชัน Excel
| ฟังก์ชัน | หน้าที่ |
|----------|---------|
| `map_excel_files(file_paths, config)` | entry point |
| `_load_excel_schemas(schema_dir)` | โหลดทุก YAML schemas |
| `_find_matching_schema(df, schemas)` | จับคู่ headers กับ schema |
| `_map_excel_rows(df, schema, config)` | แปลงทุกแถว |

---

## ส่วนที่ 5: FINNET Excel Mapper

### แนวคิด
รูปแบบ FINNET มาตรฐานพร้อมคอลัมน์คงที่

### การแบ่ง Transaction
| ค่า Result | หมวดหมู่ |
|------------|----------|
| มี success keyword | success |
| ว่าง | pending |

### ฟังก์ชัน FINNET
| ฟังก์ชัน | หน้าที่ |
|----------|---------|
| `map_finnet_files(file_paths, config)` | entry point |
| `_categorize_transaction(result_value, keywords)` | กำหนด success/pending |
| `_parse_finnet_account(to_cell, bank_mapping)` | parse "BANKNAME 1234567890" |

---

## Prompt ที่ใช้

```
เขียน clean Python code สำหรับ src/mappers.py

ข้อกำหนด:

## Config Loading
1. สร้าง load_mapper_config(config_dir: Path) -> dict
   - โหลด agent.yaml, bank_code.yaml, default_account.yaml
   - return dict รวม

## Single Transaction
2. สร้าง map_single_transactions(results: dict, config: dict) -> tuple[list[TransactionRecord], list[dict]]
3. สร้าง _get_field_value(fields: dict, key: str) -> str

## Multiple Transaction
4. สร้าง map_multiple_transactions(results: dict, config: dict) -> tuple[list[TransactionRecord], list[dict]]
5. สร้าง _detect_table_type(fields: dict) -> str | None
6. สร้าง _load_multiple_schema(schema_dir: Path, doc_type: str) -> dict | None

## Slip Transaction
7. สร้าง map_slip_transactions(results: dict, config: dict) -> tuple[list[TransactionRecord], list[dict]]
8. สร้าง _resolve_masked_account(raw_acc: str, bank_mapping: dict, bank_hint: str) -> tuple[str, str, str] | None
9. สร้าง _is_masked_account(acc_str: str) -> bool

## Excel Transaction
10. สร้าง map_excel_files(file_paths: list[Path], config: dict) -> tuple[list[TransactionRecord], list[dict]]
11. สร้าง _load_excel_schemas(schema_dir: Path) -> list[dict]
12. สร้าง _find_matching_schema(df: DataFrame, schemas: list) -> dict | None

## FINNET
13. สร้าง map_finnet_files(file_paths: list[Path], config: dict) -> tuple[list[TransactionRecord], list[dict]]
14. สร้าง _categorize_transaction(result_value: str, keywords: list) -> str
15. สร้าง _parse_finnet_account(to_cell: str, bank_mapping: dict) -> tuple[str, str, str] | None

## ข้อกำหนดทั่วไป
- แต่ละฟังก์ชันไม่เกิน 20 บรรทัด
- ใช้ helpers จาก utils/helpers.py สำหรับ normalization
- ใช้ models จาก models.py (TransactionRecord)
- Config เป็น YAML ทั้งหมด (config/mapper/)
- return (records, failed_files) สำหรับทุก entry point

อ้างอิง:
- Original Code/Functions/mappers/*.py
- config/mapper/*.yaml
```
