"""
Step 04: OCR Module - Azure Document Intelligence
"""
import logging
import mimetypes
import os
import random
import re
import time
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from io import BytesIO
from pathlib import Path
from typing import Any, Optional

import fitz
import requests
import yaml
from azure.ai.documentintelligence import DocumentIntelligenceClient
from azure.core.credentials import AzureKeyCredential
from azure.core.pipeline.transport import RequestsTransport
from dotenv import load_dotenv
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

logger = logging.getLogger(__name__)
IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp"}


# =============================================================================
# Config
# =============================================================================

def load_ocr_config(path: Path) -> dict:
    """Load OCR config from YAML and expand environment variables."""
    # Load .env from project root
    env_path = path.parent.parent / ".env"
    if env_path.exists():
        load_dotenv(env_path)

    with open(path, "r", encoding="utf-8") as f:
        config = yaml.safe_load(f)

    return _expand_env_vars(config)


def _expand_env_vars(obj: Any) -> Any:
    """Recursively expand ${VAR} in config values."""
    if isinstance(obj, dict):
        return {k: _expand_env_vars(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_expand_env_vars(i) for i in obj]
    if isinstance(obj, str):
        pattern = r"\$\{(\w+)\}"
        matches = re.findall(pattern, obj)
        for var in matches:
            val = os.environ.get(var, "")
            obj = obj.replace(f"${{{var}}}", val)
        return obj
    return obj


# =============================================================================
# Part 1: Client
# =============================================================================

def create_client(
    endpoint: str, key: str, settings: dict
) -> Optional[DocumentIntelligenceClient]:
    """Create Azure Document Intelligence client."""
    if not endpoint or not key:
        logger.error("Endpoint or key missing")
        return None
    try:
        session = _create_session(settings.get("pool_size", 32))
        transport = _create_transport(session, settings)
        return DocumentIntelligenceClient(
            endpoint=endpoint,
            credential=AzureKeyCredential(key),
            transport=transport
        )
    except Exception as e:
        logger.exception("Failed to create client: %s", e)
        return None


def _create_session(pool_size: int) -> requests.Session:
    """Create session with connection pooling."""
    session = requests.Session()
    session.trust_env = False
    retry = _configure_retry(2)
    adapter = HTTPAdapter(
        pool_connections=pool_size,
        pool_maxsize=pool_size,
        max_retries=retry
    )
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    return session


def _configure_retry(max_retries: int) -> Retry:
    """Create retry policy with exponential backoff."""
    return Retry(
        total=max_retries,
        backoff_factor=0.5,
        status_forcelist=[408, 500, 502, 503, 504],
        allowed_methods=frozenset(["GET", "POST"])
    )


def _create_transport(session: requests.Session, settings: dict) -> RequestsTransport:
    """Create Azure transport layer."""
    return RequestsTransport(
        session=session,
        connection_timeout=settings.get("connection_timeout", 300),
        read_timeout=settings.get("read_timeout", 300)
    )


# =============================================================================
# Part 2: Classifier - Helpers
# =============================================================================

def is_pdf(path: Path) -> bool:
    return path.suffix.lower() == ".pdf"


def is_image(path: Path) -> bool:
    return path.suffix.lower() in IMAGE_EXTS


def make_page_key(file_path: Path, page_num: Optional[int]) -> str:
    return f"{file_path.stem}_page_{page_num}" if page_num else file_path.stem


def guess_content_type(filename: str) -> str:
    ct, _ = mimetypes.guess_type(filename)
    return ct or "application/octet-stream"


# =============================================================================
# Part 2: Classifier - PDF
# =============================================================================

def check_pdf_openable(pdf_path: Path) -> tuple[bool, bool, Optional[str]]:
    """Check if PDF can be opened. Returns (openable, is_encrypted, error)."""
    try:
        doc = fitz.open(str(pdf_path))
        encrypted = getattr(doc, "is_encrypted", False)
        doc.close()
        if encrypted:
            return False, True, "PDF is encrypted"
        return True, False, None
    except Exception as e:
        return False, False, str(e)


def split_pdf_to_pages(pdf_path: Path) -> list[tuple[int, BytesIO]]:
    """Split PDF into pages. Returns list of (page_num, BytesIO)."""
    pages = []
    try:
        src = fitz.open(str(pdf_path))
        for i in range(src.page_count):
            single = fitz.open()
            single.insert_pdf(src, from_page=i, to_page=i)
            bio = BytesIO(single.tobytes())
            bio.seek(0)
            pages.append((i + 1, bio))
            single.close()
        src.close()
    except Exception as e:
        logger.exception("Failed to split PDF %s: %s", pdf_path, e)
    return pages


# =============================================================================
# Part 2: Classifier - Classification
# =============================================================================

def classify_document(
    client: DocumentIntelligenceClient,
    stream: BytesIO,
    content_type: str,
    classifier_id: str
) -> Any:
    """Classify a single document."""
    stream.seek(0)
    poller = client.begin_classify_document(
        classifier_id=classifier_id,
        body=stream,
        content_type=content_type
    )
    return poller.result()


def _classify_file(
    client: DocumentIntelligenceClient,
    file_path: Path,
    root_dir: Path,
    classifier_id: str
) -> list[dict]:
    """Classify a single file (PDF or image)."""
    rel_path = str(file_path.relative_to(root_dir))

    if is_pdf(file_path):
        pages = split_pdf_to_pages(file_path)
        if not pages:
            return [{"file_path": rel_path, "error": "Cannot split PDF"}]
        return [
            _classify_page(client, stream, "application/pdf", classifier_id, rel_path, pn)
            for pn, stream in pages
        ]
    else:
        with open(file_path, "rb") as f:
            stream = BytesIO(f.read())
        ct = guess_content_type(file_path.name)
        return [_classify_page(client, stream, ct, classifier_id, rel_path, None)]


def _classify_page(
    client: DocumentIntelligenceClient,
    stream: BytesIO,
    content_type: str,
    classifier_id: str,
    rel_path: str,
    page_num: Optional[int]
) -> dict:
    """Classify single page and return result dict."""
    page_key = f"{Path(rel_path).stem}_page_{page_num}" if page_num else Path(rel_path).stem
    try:
        result = classify_document(client, stream, content_type, classifier_id)
        return {
            "file_path": rel_path,
            "page_num": str(page_num) if page_num else "",
            "page_key": page_key,
            "page_stream": stream,
            "content_type": content_type,
            "classification_result": result
        }
    except Exception as e:
        logger.exception("Classification failed: %s", page_key)
        return {"file_path": rel_path, "page_num": str(page_num) if page_num else "", "page_key": page_key, "error": str(e)}


def classify_directory(
    client: DocumentIntelligenceClient,
    root_dir: Path,
    classifier_id: str,
    max_workers: int = 4
) -> list[dict]:
    """Classify all files in directory. Returns flat list of results."""
    files = [p for p in root_dir.rglob("*") if p.is_file() and (is_pdf(p) or is_image(p))]
    if not files:
        logger.warning("No files found in %s", root_dir)
        return []

    results = []
    with ThreadPoolExecutor(max_workers=max_workers) as ex:
        futures = {ex.submit(_classify_file, client, f, root_dir, classifier_id): f for f in files}
        for fut in as_completed(futures):
            try:
                results.extend(fut.result())
            except Exception as e:
                logger.exception("Classification error: %s", e)
    return results


# =============================================================================
# Part 3: Extractor
# =============================================================================

def group_by_document_type(results: list, threshold: float) -> dict[str, dict]:
    """Group results by doc_type. Returns {doc_type: {page_key: (stream, file_path)}}."""
    grouped: dict[str, dict] = defaultdict(dict)
    for item in results:
        if "error" in item or "classification_result" not in item:
            continue
        page_key = item.get("page_key")
        stream = item.get("page_stream")
        file_path = item.get("file_path")
        docs = getattr(item["classification_result"], "documents", []) or []
        for doc in docs:
            doc_type = getattr(doc, "doc_type", None)
            confidence = getattr(doc, "confidence", 0)
            if doc_type and confidence >= threshold:
                grouped[doc_type][page_key] = (stream, file_path)
    return grouped


def get_model_info(doc_type: str, model_map: dict) -> tuple[Optional[str], Optional[str]]:
    """Get (model_id, type) from model_map."""
    entry = model_map.get(doc_type)
    if isinstance(entry, dict):
        return entry.get("model_id"), entry.get("type")
    return None, None


def analyze_document(
    client: DocumentIntelligenceClient,
    model_id: str,
    stream: BytesIO,
    content_type: str
) -> dict:
    """Analyze document with model."""
    stream.seek(0)
    poller = client.begin_analyze_document(
        model_id=model_id,
        body=stream,
        content_type=content_type
    )
    return poller.result().as_dict()


def analyze_with_retry(
    client: DocumentIntelligenceClient,
    model_id: str,
    stream: BytesIO,
    content_type: str,
    max_attempts: int = 2
) -> dict:
    """Analyze with retry on failure."""
    for attempt in range(max_attempts):
        try:
            return analyze_document(client, model_id, stream, content_type)
        except Exception as e:
            if attempt + 1 >= max_attempts:
                raise
            wait = (2 ** (attempt + 1)) + random.uniform(0, 0.5)
            logger.warning("Retry %d: %s", attempt + 1, e)
            time.sleep(wait)
    raise RuntimeError("Max attempts exceeded")


def extract_group_parallel(
    client: DocumentIntelligenceClient,
    model_id: str,
    pages: dict,
    max_workers: int = 4
) -> list[dict]:
    """Extract from pages in parallel."""
    results = []
    with ThreadPoolExecutor(max_workers=max_workers) as ex:
        futures = {}
        for page_key, (stream, file_path) in pages.items():
            ct = "application/pdf" if "_page_" in page_key else "image/*"
            futures[ex.submit(analyze_with_retry, client, model_id, stream, ct)] = (page_key, file_path)

        for fut in as_completed(futures):
            page_key, file_path = futures[fut]
            try:
                results.append({"page_key": page_key, "file_path": file_path, "analyze_result": fut.result()})
            except Exception as e:
                results.append({"page_key": page_key, "file_path": file_path, "error": str(e)})
    return results


def extract_documents(
    client: DocumentIntelligenceClient,
    classification_results: list,
    model_map: dict,
    confidence_threshold: float = 0.6
) -> tuple[dict, list]:
    """Extract from classified documents. Returns (results_by_type, failed_files)."""
    grouped = group_by_document_type(classification_results, confidence_threshold)
    all_results: dict[str, list] = defaultdict(list)
    failed: list[dict] = []

    for doc_type, pages in grouped.items():
        if doc_type == "Unused":
            continue
        model_id, tx_type = get_model_info(doc_type, model_map)
        if not model_id:
            logger.warning("No model for: %s", doc_type)
            continue

        logger.info("Extracting %s (%d pages)", doc_type, len(pages))
        extracted = extract_group_parallel(client, model_id, pages)
        for res in extracted:
            res["doc_type"] = doc_type
            if "error" in res:
                failed.append({"file_path": res["file_path"], "error": res["error"]})
            all_results[tx_type or "Uncategorized"].append(res)

    return dict(all_results), failed
