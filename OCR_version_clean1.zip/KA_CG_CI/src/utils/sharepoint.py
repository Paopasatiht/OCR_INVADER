"""
Step 05: SharePoint Client
- enabled=True: use SharePoint API
- enabled=False: use local cache folders
"""
import logging
import shutil
from pathlib import Path
from typing import Any, Optional

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

logger = logging.getLogger(__name__)


class SharePointClient:
    """SharePoint client with local fallback when disabled."""

    def __init__(self, config: dict, local_cache_dir: Optional[Path] = None):
        """
        Initialize client.
        config keys: enabled, api_base_url, api_key, app_name,
                     site_url, drive_name, base_root, timeout_get, timeout_post, retry_total
        """
        self.enabled = config.get("enabled", False)
        self.local_cache = local_cache_dir or Path("Cache")

        if self.enabled:
            self.api_base = config.get("api_base_url", "")
            self.api_key = config.get("api_key", "")
            self.app_name = config.get("app_name", "")
            self.site_url = config.get("site_url", "")
            self.drive_name = config.get("drive_name", "")
            self.base_root = config.get("base_root", "").rstrip("/")
            self.timeout_get = config.get("timeout_get", 30)
            self.timeout_post = config.get("timeout_post", 60)
            self.session = _build_session(config.get("retry_total", 3))
        else:
            logger.info("SharePoint disabled, using local cache: %s", self.local_cache)

    # =========================================================================
    # Path Helpers
    # =========================================================================

    def _join_path(self, relative: str, absolute: bool = False) -> str:
        """Join base_root with relative path."""
        p = relative.replace("\\", "/").strip("/")
        if absolute:
            return f"/{p}"
        return f"/{self.base_root}/{p}" if self.base_root else f"/{p}"

    def _headers(self) -> dict:
        return {"X-API-Key": self.api_key, "X-App-Name": self.app_name}

    def _params(self) -> dict:
        return {"siteUrl": self.site_url, "driveName": self.drive_name}

    # =========================================================================
    # Core Operations
    # =========================================================================

    def list_files(self, folder_path: str, absolute: bool = False) -> Optional[dict]:
        """List files in folder. Returns {"items": [...]} or None."""
        if not self.enabled:
            return self._list_local(folder_path)

        sp_path = self._join_path(folder_path, absolute)
        params = {**self._params(), "folderPath": sp_path}
        try:
            resp = self.session.get(
                f"{self.api_base}/api/SharePoint/debug/list",
                headers=self._headers(),
                params=params,
                timeout=self.timeout_get
            )
            resp.raise_for_status()
            data = resp.json()
            if "items" in data:
                logger.info("Listed: %s", sp_path)
                return data
            return None
        except Exception as e:
            logger.exception("list_files failed: %s", e)
            return None

    def download_file(
        self, file_path: str, save_dir: Path, absolute: bool = False
    ) -> Optional[Path]:
        """Download file to save_dir. Returns local path or None."""
        if not self.enabled:
            return self._copy_local(file_path, save_dir)

        sp_path = self._join_path(file_path, absolute)
        params = {**self._params(), "filePath": sp_path}
        try:
            resp = self.session.get(
                f"{self.api_base}/api/SharePoint/download",
                headers=self._headers(),
                params=params,
                timeout=self.timeout_get
            )
            resp.raise_for_status()
            save_dir.mkdir(parents=True, exist_ok=True)
            filename = Path(sp_path).name
            out_path = save_dir / filename
            out_path.write_bytes(resp.content)
            logger.info("Downloaded: %s -> %s", sp_path, out_path)
            return out_path
        except Exception as e:
            logger.exception("download_file failed: %s", e)
            return None

    def upload_file(self, local_file: Optional[Path], target_folder: str) -> bool:
        """Upload file or create folder if local_file is None."""
        if not self.enabled:
            return self._upload_local(local_file, target_folder)

        sp_folder = self._join_path(target_folder, absolute=False)
        data = {**self._params(), "folderPath": sp_folder}

        if local_file is None:
            return self.create_folder(target_folder)

        try:
            if not local_file.is_file():
                logger.error("File not found: %s", local_file)
                return False
            with local_file.open("rb") as f:
                files = {"file": (local_file.name, f)}
                resp = self.session.post(
                    f"{self.api_base}/api/SharePoint/upload",
                    headers=self._headers(),
                    data=data,
                    files=files,
                    timeout=self.timeout_post
                )
            resp.raise_for_status()
            logger.info("Uploaded: %s -> %s", local_file, sp_folder)
            return True
        except Exception as e:
            logger.exception("upload_file failed: %s", e)
            return False

    def create_folder(self, folder_path: str) -> bool:
        """Create folder on SharePoint."""
        if not self.enabled:
            target = self.local_cache / folder_path
            target.mkdir(parents=True, exist_ok=True)
            return True

        sp_folder = self._join_path(folder_path, absolute=False)
        data = {**self._params(), "folderPath": sp_folder}
        try:
            resp = self.session.post(
                f"{self.api_base}/api/SharePoint/upload",
                headers=self._headers(),
                data=data,
                timeout=self.timeout_post
            )
            resp.raise_for_status()
            logger.info("Created folder: %s", sp_folder)
            return True
        except Exception as e:
            logger.exception("create_folder failed: %s", e)
            return False

    # =========================================================================
    # High-Level Operations
    # =========================================================================

    def list_all_recursive(self, root_path: str) -> list[dict]:
        """DFS listing of all items under root_path."""
        if not self.enabled:
            return self._list_local_recursive(root_path)

        items = []
        stack = [self._join_path(root_path, absolute=True)]
        while stack:
            current = stack.pop()
            listing = self.list_files(current, absolute=True)
            if not listing:
                continue
            for item in listing.get("items", []):
                items.append(item)
                if item.get("type") == "Folder":
                    path = item.get("path", "").replace("\\", "/")
                    stack.append(f"/{path.strip('/')}")
        return items

    def download_tree(
        self, root_path: str, local_dir: Path
    ) -> tuple[list[Path], list[str]]:
        """Download all files recursively. Returns (downloaded_paths, file_paths)."""
        if not self.enabled:
            return self._download_local_tree(root_path, local_dir)

        local_dir.mkdir(parents=True, exist_ok=True)
        items = self.list_all_recursive(root_path)
        downloaded = []
        file_paths = []

        for item in items:
            if item.get("type") == "File":
                path = item.get("path", "").replace("\\", "/")
                file_paths.append(path)
                parent = Path(path).parent.name or "root"
                out = self.download_file(path, local_dir / parent, absolute=True)
                if out:
                    downloaded.append(out)

        return downloaded, file_paths

    def upload_directory(self, local_dir: Path, target_folder: str) -> list[Path]:
        """Upload all files in directory. Returns uploaded paths."""
        if not self.enabled:
            return self._upload_local_directory(local_dir, target_folder)

        uploaded = []
        if not local_dir.exists():
            logger.error("Directory not found: %s", local_dir)
            return uploaded

        for file_path in local_dir.rglob("*"):
            if file_path.is_file():
                rel = file_path.relative_to(local_dir)
                remote_folder = f"{target_folder}/{rel.parent}".replace("\\", "/")
                if self.upload_file(file_path, remote_folder):
                    uploaded.append(file_path)

        return uploaded

    # =========================================================================
    # Local Mode Operations (when enabled=False)
    # =========================================================================

    def _list_local(self, folder_path: str) -> Optional[dict]:
        """List files from local cache."""
        local_path = self.local_cache / folder_path.strip("/")
        if not local_path.exists():
            return None
        items = []
        for p in local_path.iterdir():
            items.append({
                "name": p.name,
                "path": str(p.relative_to(self.local_cache)),
                "type": "Folder" if p.is_dir() else "File"
            })
        return {"items": items}

    def _list_local_recursive(self, root_path: str) -> list[dict]:
        """Recursively list all items from local cache."""
        local_path = self.local_cache / root_path.strip("/")
        items = []
        if not local_path.exists():
            return items
        for p in local_path.rglob("*"):
            items.append({
                "name": p.name,
                "path": str(p.relative_to(self.local_cache)),
                "type": "Folder" if p.is_dir() else "File"
            })
        return items

    def _copy_local(self, file_path: str, save_dir: Path) -> Optional[Path]:
        """Copy file from local cache to save_dir."""
        src = self.local_cache / file_path.strip("/")
        if not src.is_file():
            logger.warning("Local file not found: %s", src)
            return None
        save_dir.mkdir(parents=True, exist_ok=True)
        dst = save_dir / src.name
        shutil.copy2(src, dst)
        logger.info("Copied local: %s -> %s", src, dst)
        return dst

    def _download_local_tree(
        self, root_path: str, local_dir: Path
    ) -> tuple[list[Path], list[str]]:
        """Copy all files from local cache tree."""
        src_root = self.local_cache / root_path.strip("/")
        downloaded = []
        file_paths = []
        if not src_root.exists():
            return downloaded, file_paths

        for p in src_root.rglob("*"):
            if p.is_file():
                rel = p.relative_to(src_root)
                file_paths.append(str(rel))
                dst_dir = local_dir / rel.parent
                dst_dir.mkdir(parents=True, exist_ok=True)
                dst = dst_dir / p.name
                shutil.copy2(p, dst)
                downloaded.append(dst)

        return downloaded, file_paths

    def _upload_local(self, local_file: Optional[Path], target_folder: str) -> bool:
        """Copy file to local cache output folder."""
        target = self.local_cache / target_folder.strip("/")
        target.mkdir(parents=True, exist_ok=True)
        if local_file and local_file.is_file():
            shutil.copy2(local_file, target / local_file.name)
            logger.info("Copied to output: %s -> %s", local_file, target)
        return True

    def _upload_local_directory(
        self, local_dir: Path, target_folder: str
    ) -> list[Path]:
        """Copy directory to local cache output."""
        uploaded = []
        if not local_dir.exists():
            return uploaded
        for p in local_dir.rglob("*"):
            if p.is_file():
                rel = p.relative_to(local_dir)
                dst_dir = self.local_cache / target_folder.strip("/") / rel.parent
                dst_dir.mkdir(parents=True, exist_ok=True)
                shutil.copy2(p, dst_dir / p.name)
                uploaded.append(p)
        return uploaded


def _build_session(retry_total: int) -> requests.Session:
    """Build session with retry policy."""
    retry = Retry(
        total=retry_total,
        backoff_factor=0.5,
        status_forcelist=[429, 500, 502, 503, 504],
        allowed_methods=frozenset(["GET", "POST"])
    )
    session = requests.Session()
    adapter = HTTPAdapter(max_retries=retry)
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    return session
