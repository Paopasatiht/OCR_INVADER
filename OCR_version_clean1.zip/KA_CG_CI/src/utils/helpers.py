"""
Helpers Module - ฟังก์ชันช่วยเหลือสำหรับ normalize ข้อมูล
"""
import re
from datetime import datetime
from typing import Optional
import sys
sys.path.insert(0, str(__file__).rsplit("utils", 1)[0])
from models import DateNormOptions


# === Constants ===
THAI_DIGITS = str.maketrans("๐๑๒๓๔๕๖๗๘๙", "0123456789")

THAI_MONTHS = {
    r"ม\.?ค\.?": "01", r"ก\.?พ\.?": "02", r"มี\.?ค\.?": "03",
    r"เม\.?ย\.?": "04", r"พ\.?ค\.?": "05", r"มิ\.?ย\.?": "06",
    r"ก\.?ค\.?": "07", r"ส\.?ค\.?": "08", r"ก\.?ย\.?": "09",
    r"ต\.?ค\.?": "10", r"พ\.?ย\.?": "11", r"ธ\.?ค\.?": "12",
}

EN_MONTHS = {
    r"\bjan\b": "01", r"\bfeb\b": "02", r"\bmar\b": "03",
    r"\bapr\b": "04", r"\bmay\b": "05", r"\bjun\b": "06",
    r"\bjul\b": "07", r"\baug\b": "08", r"\bsep\b": "09",
    r"\boct\b": "10", r"\bnov\b": "11", r"\bdec\b": "12",
}


# === Date Helpers ===
def _convert_thai_digits(text: str) -> str:
    """แปลงเลขไทย ๐-๙ เป็น 0-9"""
    return text.translate(THAI_DIGITS)


def _replace_thai_months(text: str) -> str:
    """แปลงเดือนไทย เป็นตัวเลข"""
    for pattern, num in THAI_MONTHS.items():
        text = re.sub(pattern, num, text)
    return text


def _replace_english_months(text: str) -> str:
    """แปลงเดือนอังกฤษ เป็นตัวเลข"""
    for pattern, num in EN_MONTHS.items():
        text = re.sub(pattern, num, text, flags=re.IGNORECASE)
    return text


def _has_thai_context(text: str) -> bool:
    """ตรวจสอบว่ามี context ภาษาไทย"""
    return bool(re.search(r"[ก-๙]|พ\.?ศ\.?", text))


def _interpret_year(year_str: str, original: str, options: DateNormOptions) -> str:
    """แปลงปี 2/4 หลักเป็นปี ค.ศ. 4 หลัก"""
    current_year = datetime.now().year

    if len(year_str) == 4:
        y = int(year_str)
        return str(y - 543) if 2400 <= y <= 2600 else str(y)

    if len(year_str) == 2:
        yy = int(year_str)
        buddhist = 2500 + yy - 543
        gregorian = 2000 + yy if yy <= 30 else 1900 + yy

        if options.prefer_buddhist_shorthand:
            return str(buddhist)
        if options.locale_hint == "th" or _has_thai_context(original):
            return str(buddhist)
        return str(gregorian)

    return year_str


def _format_date(day: str, month: str, year: str) -> str:
    """Format เป็น dd/mm/yyyy"""
    return f"{day.zfill(2)}/{month.zfill(2)}/{year}"


def normalize_date(date_str: str, options: DateNormOptions = None) -> str:
    """
    Normalize วันที่เป็น dd/mm/yyyy
    รองรับ: yyyy-mm-dd, dd/mm/yyyy, เดือนไทย, ปี พ.ศ.
    """
    if not date_str:
        return date_str

    options = options or DateNormOptions()
    original = date_str
    s = _convert_thai_digits(date_str.strip().lower())
    s = _replace_thai_months(s)
    s = _replace_english_months(s)
    s = re.sub(r"[^\d/\-\s]", " ", s)
    s = re.sub(r"\s+", " ", s).strip()
    s = re.sub(r"\s*([/\-])\s*", r"\1", s)

    # Pattern: yyyy-mm-dd
    m = re.fullmatch(r"(\d{4})[-/](\d{1,2})[-/](\d{1,2})", s)
    if m:
        y, mth, d = m.groups()
        return _format_date(d, mth, _interpret_year(y, original, options))

    # Pattern: dd/mm/yyyy
    m = re.fullmatch(r"(\d{1,2})[-/](\d{1,2})[-/](\d{2,4})", s)
    if m:
        d, mth, y = m.groups()
        return _format_date(d, mth, _interpret_year(y, original, options))

    # Pattern: dd mm yyyy (space separated)
    m = re.fullmatch(r"(\d{1,2})\s+(\d{1,2})\s+(\d{2,4})", s)
    if m:
        d, mth, y = m.groups()
        return _format_date(d, mth, _interpret_year(y, original, options))

    return date_str


# === Amount Helpers ===
def normalize_amount(amount_str: str) -> str:
    """
    Normalize จำนวนเงินเป็น #,###.00
    """
    if not amount_str:
        return "0.00"

    cleaned = re.sub(r"[^\d.]", "", _convert_thai_digits(str(amount_str)))

    if cleaned.count(".") > 1:
        parts = cleaned.split(".")
        cleaned = parts[0] + "." + "".join(parts[1:])

    if not cleaned or cleaned == ".":
        return "0.00"

    try:
        return f"{float(cleaned):,.2f}"
    except ValueError:
        return "0.00"


# === Account Number Helpers ===
def normalize_account_number(acc_str: str) -> str:
    """ดึงเฉพาะตัวเลขจาก account string"""
    if not acc_str:
        return ""
    s = _convert_thai_digits(str(acc_str))
    return re.sub(r"\D", "", s)


def map_account_number(
    raw_acc: str,
    bank_mapping: dict
) -> Optional[tuple[str, str, str]]:
    """
    Map เลขบัญชีกับ bank_mapping
    Return (bank_code, bank_name, account_no) หรือ None
    """
    normalized = normalize_account_number(raw_acc)
    if not normalized:
        return None

    match = bank_mapping.get(normalized)
    if not match:
        return None

    return (
        match.get("bank_code", ""),
        match.get("bank", ""),
        match.get("account_no", normalized)
    )


# === Agent Helpers ===
def _normalize_for_match(text: str) -> str:
    """Normalize text สำหรับ matching"""
    s = text.lower()
    s = re.sub(r"[\-_/\\.\(\)\[\],:]+", " ", s)
    return re.sub(r"\s+", " ", s).strip()


def extract_agent_from_path(
    path_str: str,
    agent_map: dict
) -> Optional[str]:
    """
    ดึง agent name จาก file path
    Return agent display name หรือ None
    """
    if not path_str or not agent_map:
        return None

    path_norm = _normalize_for_match(path_str)

    # Try exact code match
    for code, display in agent_map.items():
        if code.lower() in path_norm:
            return display

    # Try display name match
    for code, display in agent_map.items():
        if _normalize_for_match(display) in path_norm:
            return display

    return None
