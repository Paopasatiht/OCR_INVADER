"""
Step 06: Email Module - Plain text summary email
"""
import logging
import mimetypes
import smtplib
from datetime import datetime
from email.message import EmailMessage
from pathlib import Path
from typing import Optional

import pandas as pd
import yaml

logger = logging.getLogger(__name__)

FAILURE_KEYS = [
    "encrypted_pdf_files",
    "failed_OCR_classification_files",
    "failed_OCR_extraction_files",
    "unknown_or_unused_from_azure",
    "failed_mapping_files",
]
SUCCESS_KEY = "overall_success_files"


# =============================================================================
# 1. Main Entry Point
# =============================================================================

def send_summary_email(
    results: dict,
    config_path: Path,
    to_emails: list[str],
    attachments_dir: Path,
    cc_emails: Optional[list[str]] = None
) -> None:
    """Send OCR summary email with attachments."""
    config = _load_email_config(config_path)
    agent_names = _load_agent_names(config_path)

    subject = _build_email_subject(results)
    body = _build_email_body(results, agent_names)

    attachments = []
    try:
        summary_path = build_summary_excel(results, attachments_dir, agent_names)
        attachments.append(summary_path)
    except Exception as e:
        logger.exception("Failed to create summary Excel: %s", e)

    attachments.extend(_collect_attachments(attachments_dir))

    _send_email(
        smtp_server=config.get("smtp_server", ""),
        smtp_port=config.get("smtp_port", 25),
        sender=config.get("sender", ""),
        to=to_emails,
        cc=cc_emails or [],
        subject=subject,
        body=body,
        attachments=attachments
    )


# =============================================================================
# 2. Build Email Subject
# =============================================================================

def _build_email_subject(results: dict, prefix: str = "สรุปผล OCR") -> str:
    """Build subject: [prefix] status - DD/MM/YYYY HH:MM"""
    status = _determine_status(results)
    timestamp = datetime.now().strftime("%d/%m/%Y %H:%M")
    return f"[{prefix}] {status} - {timestamp}"


# =============================================================================
# 3. Build Email Body (Plain Text Thai)
# =============================================================================

def _build_email_body(results: dict, agent_names: dict) -> str:
    """Build plain text email body in Thai."""
    success_files = results.get(SUCCESS_KEY, [])
    total_success = len(success_files)
    fail_counts = {k: len(results.get(k, [])) for k in FAILURE_KEYS}
    total_fail = sum(fail_counts.values())
    total_files = total_success + total_fail
    agents = _extract_agents(success_files, agent_names)

    lines = [
        "=" * 50,
        "รายงานผลการประมวลผลเอกสาร OCR",
        "=" * 50, "",
        f"วันที่: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        f"สถานะ: {_determine_status(results)}", "",
        "-" * 50,
        f"ไฟล์ทั้งหมด: {total_files}",
        f"สำเร็จ: {total_success}",
        f"ล้มเหลว: {total_fail}",
        f"Agent: {len(agents)}", "",
    ]

    if total_fail > 0:
        lines.append("รายละเอียดล้มเหลว:")
        for key, count in fail_counts.items():
            if count > 0:
                lines.append(f"  - {_translate_key(key)}: {count}")
        lines.append("")

    lines.extend(["-" * 50, "ดูรายละเอียดที่ run_summary.xlsx", "", "OCR System"])
    return "\n".join(lines)


def _translate_key(key: str) -> str:
    """Translate failure key to Thai."""
    translations = {
        "encrypted_pdf_files": "PDF มีรหัสผ่าน",
        "failed_OCR_classification_files": "จำแนกประเภทไม่ได้",
        "failed_OCR_extraction_files": "สกัดข้อมูลไม่ได้",
        "unknown_or_unused_from_azure": "ไม่รู้จัก",
        "failed_mapping_files": "แมปข้อมูลไม่ได้",
    }
    return translations.get(key, key)


def _extract_agents(files: list, agent_names: dict) -> set:
    """Extract unique agent names from file paths."""
    agents = set()
    for item in files:
        path = item.get("file_path", "") if isinstance(item, dict) else str(item)
        for code, name in agent_names.items():
            if code in path:
                agents.add(name)
                break
    return agents


# =============================================================================
# 4. Build Summary Excel
# =============================================================================

def build_summary_excel(results: dict, output_dir: Path, agent_names: dict) -> Path:
    """Build summary Excel with all files and status."""
    output_dir.mkdir(parents=True, exist_ok=True)
    summary_path = output_dir / "run_summary.xlsx"
    records = []

    for item in results.get(SUCCESS_KEY, []):
        records.append(_make_record(item, "success", "", agent_names))

    error_labels = {
        "encrypted_pdf_files": "PDF มีรหัสผ่าน",
        "failed_OCR_classification_files": "จำแนกประเภทไม่ได้",
        "failed_OCR_extraction_files": "สกัดข้อมูลไม่ได้",
        "unknown_or_unused_from_azure": "ไม่รู้จัก",
        "failed_mapping_files": "แมปข้อมูลไม่ได้",
    }
    for key, label in error_labels.items():
        for item in results.get(key, []):
            records.append(_make_record(item, "fail", label, agent_names))

    df = pd.DataFrame(records) if records else pd.DataFrame([{"Info": "No files"}])
    df.to_excel(summary_path, index=False, sheet_name="Summary", engine="openpyxl")
    logger.info("Summary Excel: %s (%d records)", summary_path, len(records))
    return summary_path


def _make_record(item: dict, status: str, error: str, agent_names: dict) -> dict:
    """Create a record for Excel."""
    path = item.get("file_path", "") if isinstance(item, dict) else str(item)
    agent = next((name for code, name in agent_names.items() if code in path), "Unknown")
    return {
        "Agent": agent,
        "File": Path(path).name if path else "",
        "File Path": path,
        "Status": status,
        "Error": error,
        "Doc Type": item.get("doc_type", "") if isinstance(item, dict) else "",
    }


# =============================================================================
# 5. Determine Status
# =============================================================================

def _determine_status(results: dict) -> str:
    """Determine status label from results."""
    if results.get("status") == "sharepoint_failed":
        return "SharePoint ผิดพลาด"
    has_fail = any(results.get(k) for k in FAILURE_KEYS)
    has_success = bool(results.get(SUCCESS_KEY))
    if has_fail and has_success:
        return "สำเร็จบางส่วน"
    if has_fail:
        return "ล้มเหลว"
    if has_success:
        return "สำเร็จ"
    return "ไม่มีไฟล์"


# =============================================================================
# 6. Send Email via SMTP
# =============================================================================

def _send_email(
    smtp_server: str,
    smtp_port: int,
    sender: str,
    to: list[str],
    cc: list[str],
    subject: str,
    body: str,
    attachments: list[Path]
) -> None:
    """Send email via SMTP with attachments."""
    msg = EmailMessage()
    msg["Subject"] = subject
    msg["From"] = sender
    msg["To"] = ", ".join(to)
    if cc:
        msg["Cc"] = ", ".join(cc)
    msg.set_content(body)

    for path in attachments:
        _attach_file(msg, path)

    with smtplib.SMTP(smtp_server, smtp_port, timeout=30) as server:
        server.send_message(msg)
    logger.info("Email sent to: %s", ", ".join(to))


def _attach_file(msg: EmailMessage, path: Path) -> None:
    """Attach single file to email."""
    if not path.exists():
        return
    ctype, _ = mimetypes.guess_type(str(path))
    maintype, subtype = (ctype or "application/octet-stream").split("/", 1)
    with open(path, "rb") as f:
        msg.add_attachment(f.read(), maintype=maintype, subtype=subtype, filename=path.name)
    logger.info("Attached: %s", path.name)


# =============================================================================
# Helper: Collect Attachments
# =============================================================================

def _collect_attachments(directory: Path, extensions: tuple = (".xlsx", ".xls", ".csv")) -> list[Path]:
    """Collect output files from directory."""
    if not directory.exists():
        return []
    files = [f for ext in extensions for f in directory.glob(f"*{ext}")]
    return [f for f in files if f.name != "run_summary.xlsx"][:10]


# =============================================================================
# 8. Load Agent Names & Config
# =============================================================================

def _load_email_config(config_path: Path) -> dict:
    """Load email config from kasset_infra.yaml."""
    infra_path = config_path.parent / "kasset_infra.yaml"
    with open(infra_path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f).get("email", {})


def _load_agent_names(config_path: Path) -> dict:
    """Load agent names mapping from YAML."""
    try:
        infra_path = config_path.parent / "kasset_infra.yaml"
        with open(infra_path, "r", encoding="utf-8") as f:
            mapper = yaml.safe_load(f).get("mapper", {})
        agent_path = config_path.parent.parent / mapper.get("agent", "config/mapper/agent.yaml")
        with open(agent_path, "r", encoding="utf-8") as f:
            return yaml.safe_load(f) or {}
    except Exception as e:
        logger.warning("Could not load agent names: %s", e)
        return {}
