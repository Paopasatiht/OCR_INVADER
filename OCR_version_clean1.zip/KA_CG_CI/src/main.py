"""
Step 09: Main Entry Point
Orchestrates the OCR extraction pipeline from Cache/ folder
"""
import json
import logging
import shutil
from datetime import datetime
from logging import FileHandler, StreamHandler
from pathlib import Path

import yaml

from pipeline import run_extraction_pipeline
from utils.email import send_summary_email


# =============================================================================
# 1. Date Helper
# =============================================================================

def _get_today_string() -> str:
    """Return today's date as YYYYMMDD string."""
    return datetime.now().strftime("%Y%m%d")


def _get_today_dashed() -> str:
    """Return today's date as YYYY-MM-DD string."""
    return datetime.now().strftime("%Y-%m-%d")


# =============================================================================
# 2. Logging Setup
# =============================================================================

def _setup_logging(logs_dir: Path, today: str) -> logging.Logger:
    """Set up file and console logging."""
    logs_dir.mkdir(parents=True, exist_ok=True)
    log_file = logs_dir / f"log_{today}.txt"

    logger = logging.getLogger("kasset_ocr")
    logger.setLevel(logging.INFO)
    logger.handlers.clear()

    fmt = logging.Formatter("%(asctime)s [%(levelname)s] %(message)s")

    fh = FileHandler(log_file, encoding="utf-8")
    fh.setFormatter(fmt)
    logger.addHandler(fh)

    ch = StreamHandler()
    ch.setFormatter(fmt)
    logger.addHandler(ch)

    return logger


# =============================================================================
# 3. Config and Paths
# =============================================================================

def _load_config(config_path: Path) -> dict:
    """Load infrastructure config from YAML."""
    with open(config_path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}


def _get_cache_paths(config: dict, base_dir: Path) -> dict:
    """Get cache paths from config."""
    paths = config.get("paths", {})
    return {
        "inputs": base_dir / paths.get("cache_inputs", "Cache/Inputs"),
        "outputs": base_dir / paths.get("cache_outputs", "Cache/Outputs"),
        "temp": base_dir / paths.get("cache_temp", "Cache/Temp"),
    }


# =============================================================================
# 4. Results JSON
# =============================================================================

def _save_results_json(results: dict, outputs_dir: Path, today: str) -> None:
    """Save extraction results to JSON file."""
    outputs_dir.mkdir(parents=True, exist_ok=True)
    path = outputs_dir / f"extraction_results_{today}.json"

    with open(path, "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2, default=str)


# =============================================================================
# 5. Cleanup
# =============================================================================

def _cleanup_temp(temp_dir: Path, logger: logging.Logger) -> None:
    """Remove temporary directory."""
    try:
        if temp_dir.exists():
            shutil.rmtree(temp_dir, ignore_errors=True)
            logger.info("Cleaned up temp: %s", temp_dir)
    except Exception as e:
        logger.warning("Cleanup failed: %s", e)


# =============================================================================
# 6. Main Entry Point
# =============================================================================

def main() -> None:
    """Main entry point for OCR extraction pipeline."""
    # 1. Setup
    today = _get_today_string()
    today_dashed = _get_today_dashed()
    base_dir = Path(__file__).parent.parent
    config_path = base_dir / "config" / "kasset_infra.yaml"
    config = _load_config(config_path)

    # 2. Get paths and setup logging
    logs_dir = base_dir / config.get("paths", {}).get("logs", "Logs")
    logger = _setup_logging(logs_dir, today_dashed)
    logger.info("Starting OCR pipeline for %s", today)

    # 3. Get cache paths
    paths = _get_cache_paths(config, base_dir)

    # 4. Run extraction pipeline
    results, dfs = _run_pipeline(paths, config_path, today, logger)

    # 5. Save results JSON
    _save_results_json(results, paths["outputs"], today_dashed)
    logger.info("Saved results JSON")

    # 6. Send email (if configured)
    _send_email_if_enabled(results, config, config_path, paths["outputs"], logger)

    # 7. Cleanup temp (if configured)
    if config.get("cache", {}).get("delete_after_upload", False):
        _cleanup_temp(paths["temp"], logger)

    logger.info("Pipeline completed with status: %s", results.get("status", "unknown"))


def _run_pipeline(paths: dict, config_path: Path, today: str, logger: logging.Logger) -> tuple:
    """Run extraction pipeline with error handling."""
    try:
        return run_extraction_pipeline(
            inputs_dir=paths["inputs"],
            outputs_dir=paths["outputs"],
            temp_dir=paths["temp"],
            config_path=config_path,
            today=today,
            logger=logger,
        )
    except Exception as e:
        logger.exception("Pipeline failed: %s", e)
        return {"status": "failed", "error": str(e)}, {}


def _send_email_if_enabled(results: dict, config: dict, config_path: Path,
                           outputs_dir: Path, logger: logging.Logger) -> None:
    """Send email if enabled in config."""
    email_cfg = config.get("email", {})
    if not email_cfg.get("enabled", False):
        return

    try:
        send_summary_email(
            results=results,
            config_path=config_path,
            to_emails=email_cfg.get("to", []),
            attachments_dir=outputs_dir,
            cc_emails=email_cfg.get("cc"),
        )
        logger.info("Email sent successfully")
    except Exception as e:
        logger.warning("Email failed: %s", e)


if __name__ == "__main__":
    main()
