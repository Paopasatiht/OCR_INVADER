"""
Step 08: Pipeline Module
Orchestrates OCR extraction and mapping
"""
import logging
import shutil
from pathlib import Path
from typing import Optional

import pandas as pd
import yaml

from config import (
    load_env,
    load_azure_config,
    load_infra_config,
    get_document_intelligence_config,
)
from models import TransactionRecord
from utils.ocr import load_ocr_config, create_client, classify_directory, extract_documents
from mappers import (
    load_mapper_config,
    map_single_transactions,
    map_multiple_transactions,
    map_slip_transactions,
    map_excel_files,
    map_finnet_files,
)

# =============================================================================
# Constants
# =============================================================================

PDF_EXT = ".pdf"
IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp"}
EXCEL_EXTS = {".xlsx", ".xls", ".csv"}
SKIP_EXTS = {".zip", ".rar", ".7z", ".doc", ".docx", ".txt", ".ppt", ".pptx"}


# =============================================================================
# 1-4. Pre-Classification
# =============================================================================

def classify_inputs(input_dir: Path, finnet_folder_name: str = "FINNET") -> dict:
    """Classify input files into buckets: azure, excel, finnet, skipped."""
    buckets = {"azure": [], "excel": [], "finnet": [], "skipped": []}

    if not input_dir or not input_dir.exists():
        return buckets

    for p in input_dir.rglob("*"):
        if not p.is_file():
            continue
        bucket, reason = _classify_file(p, finnet_folder_name)
        if reason:
            buckets["skipped"].append({"file_path": str(p), "reason": reason})
        else:
            buckets[bucket].append(p)

    return buckets


def _classify_file(file_path: Path, finnet_folder_name: str) -> tuple[str, Optional[str]]:
    """Classify single file. Returns (bucket, skip_reason or None)."""
    ext = file_path.suffix.lower()
    parent = file_path.parent.name.lower()

    if ext in SKIP_EXTS:
        return "skipped", f"unsupported type: {ext}"

    if parent == finnet_folder_name.lower() and ext in EXCEL_EXTS:
        return "finnet", None

    if _is_pdf(file_path) or _is_image(file_path):
        return "azure", None

    if _is_excel(file_path):
        return "excel", None

    return "skipped", "not recognized"


def _is_pdf(path: Path) -> bool:
    return path.suffix.lower() == PDF_EXT


def _is_image(path: Path) -> bool:
    return path.suffix.lower() in IMAGE_EXTS


def _is_excel(path: Path) -> bool:
    return path.suffix.lower() in EXCEL_EXTS


def stage_for_azure(files: list[Path], inbox_dir: Path, input_dir: Path) -> Path:
    """Stage files to inbox_dir preserving relative structure."""
    inbox_dir.mkdir(parents=True, exist_ok=True)

    for src in files:
        try:
            rel = src.relative_to(input_dir)
        except ValueError:
            rel = Path(src.name)

        dst = inbox_dir / rel
        dst.parent.mkdir(parents=True, exist_ok=True)

        try:
            shutil.copy2(src, dst)
        except Exception:
            pass

    return inbox_dir


# =============================================================================
# 5. Main Pipeline
# =============================================================================

def run_extraction_pipeline(
    inputs_dir: Path,
    outputs_dir: Path,
    temp_dir: Path,
    config_path: Path,
    today: str,
    logger: logging.Logger
) -> tuple[dict, dict[str, pd.DataFrame]]:
    """Main orchestration function."""
    logger.info("Starting pipeline for %s", today)

    # Load configs
    config = _load_all_config(config_path)

    # Pre-classify inputs
    buckets = classify_inputs(inputs_dir)
    logger.info("Pre-classified: azure=%d, excel=%d, finnet=%d, skipped=%d",
                len(buckets["azure"]), len(buckets["excel"]),
                len(buckets["finnet"]), len(buckets["skipped"]))

    # Initialize results
    extraction_results = {
        "status": "running",
        "extraction_results": {},
        "skipped_files": buckets["skipped"],
    }

    # Stage and run OCR
    if buckets["azure"]:
        di_inbox = temp_dir / f"di_inbox_{today}"
        stage_for_azure(buckets["azure"], di_inbox, inputs_dir)
        ocr_results = _run_ocr_extraction(di_inbox, config, logger)
        extraction_results["extraction_results"].update(ocr_results.get("extraction_results", {}))
        extraction_results["successful_OCR_extraction_files"] = ocr_results.get("successful_OCR_extraction_files", [])

    # Add Excel/FINNET paths
    if buckets["excel"]:
        extraction_results["extraction_results"]["Excel"] = [str(p) for p in buckets["excel"]]
    if buckets["finnet"]:
        extraction_results["extraction_results"]["FINNET"] = [str(p) for p in buckets["finnet"]]

    # Build DataFrames
    dfs_by_kind, failed = build_all_dataframes(
        extraction_results, config_path, inputs_dir, outputs_dir, today, logger
    )
    extraction_results["failed_mapping_files"] = failed

    # Track success
    extraction_results["overall_success_files"] = _track_successful_files(
        dfs_by_kind, extraction_results.get("successful_OCR_extraction_files", [])
    )

    # Save combined output
    if dfs_by_kind:
        combined = pd.concat(dfs_by_kind.values(), ignore_index=True)
        save_dataframe_outputs(combined, outputs_dir, f"payin_mapping_{today}", logger)

    # Cleanup
    _cleanup_temp(temp_dir / f"di_inbox_{today}", logger)

    extraction_results["status"] = "success" if dfs_by_kind else "partial" if extraction_results["extraction_results"] else "failed"
    logger.info("Pipeline completed with status: %s", extraction_results["status"])

    return extraction_results, dfs_by_kind


# =============================================================================
# 6. Load Config
# =============================================================================

def _load_all_config(config_path: Path) -> dict:
    """Load all configuration files."""
    config_dir = config_path.parent
    base_dir = config_dir.parent

    # Load .env first
    load_env(base_dir)

    # Load Azure config (credentials from .env)
    azure_config = load_azure_config(config_dir, base_dir)
    di_config = get_document_intelligence_config(azure_config)

    # Load OCR extractors (model_id mappings)
    ocr_config = load_ocr_config(base_dir / "Config" / "ocr.yaml")

    # Merge DI credentials with OCR extractors
    merged_ocr = {
        "azure": {
            "endpoint": di_config.get("endpoint", ""),
            "key": di_config.get("key", ""),
        },
        "client": {
            "pool_size": di_config.get("pool_size", 32),
            "connection_timeout": di_config.get("connection_timeout", 300),
            "read_timeout": di_config.get("read_timeout", 300),
            "max_retries": di_config.get("max_retries", 2),
        },
        "classification": ocr_config.get("classification", {}),
        "extractors": ocr_config.get("extractors", {}),
    }

    # Load mapper config
    mapper_config = load_mapper_config(config_dir)

    # Load infra config
    infra_config = load_infra_config(config_dir)

    return {
        "ocr": merged_ocr,
        "mapper": mapper_config,
        "infra": infra_config,
    }


# =============================================================================
# 7. OCR Extraction
# =============================================================================

def _run_ocr_extraction(di_inbox: Path, config: dict, logger: logging.Logger) -> dict:
    """Run OCR classification and extraction."""
    ocr_cfg = config.get("ocr", {})
    azure = ocr_cfg.get("azure", {})
    client_settings = ocr_cfg.get("client", {})

    client = create_client(azure.get("endpoint", ""), azure.get("key", ""), client_settings)
    if not client:
        logger.error("Failed to create OCR client")
        return {"extraction_results": {}, "successful_OCR_extraction_files": []}

    classifier_id = ocr_cfg.get("classification", {}).get("model_id", "")
    threshold = ocr_cfg.get("classification", {}).get("confidence_threshold", 0.6)
    extractors = ocr_cfg.get("extractors", {})

    # Classify
    logger.info("Classifying documents in %s", di_inbox)
    classification_results = classify_directory(client, di_inbox, classifier_id)

    # Extract
    logger.info("Extracting documents")
    results_by_type, failed = extract_documents(client, classification_results, extractors, threshold)

    # Format results
    extraction_results = {}
    success_files = []

    for tx_type, items in results_by_type.items():
        extraction_results[tx_type] = items
        for item in items:
            if "error" not in item:
                success_files.append({"file_path": item.get("file_path", ""), "doc_type": item.get("doc_type", "")})

    return {"extraction_results": extraction_results, "successful_OCR_extraction_files": success_files}


# =============================================================================
# 8. Build DataFrames
# =============================================================================

def build_all_dataframes(
    extraction_results: dict,
    config_path: Path,
    inputs_dir: Path,
    outputs_dir: Path,
    today: str,
    logger: logging.Logger
) -> tuple[dict[str, pd.DataFrame], list[dict]]:
    """Build DataFrames from all source kinds."""
    config = load_mapper_config(config_path.parent)
    ext_results = extraction_results.get("extraction_results", {})
    dfs = {}
    all_failed = []

    # Single
    if "Single" in ext_results:
        records, failed = map_single_transactions({"extraction_results": ext_results}, config)
        if records:
            dfs["Single"] = _records_to_df(records)
        all_failed.extend(failed)

    # Multiple
    if "Multiple" in ext_results:
        records, failed = map_multiple_transactions({"extraction_results": ext_results}, config)
        if records:
            dfs["Multiple"] = _records_to_df(records)
        all_failed.extend(failed)

    # Slip
    if "Slip" in ext_results:
        records, failed = map_slip_transactions({"extraction_results": ext_results}, config)
        if records:
            dfs["Slip"] = _records_to_df(records)
        all_failed.extend(failed)

    # Excel
    if "Excel" in ext_results:
        paths = [Path(p) for p in ext_results["Excel"]]
        records, failed = map_excel_files(paths, config)
        if records:
            dfs["Excel"] = _records_to_df(records)
        all_failed.extend(failed)

    # FINNET
    if "FINNET" in ext_results:
        paths = [Path(p) for p in ext_results["FINNET"]]
        records, failed = map_finnet_files(paths, config)
        if records:
            dfs["FINNET"] = _records_to_df(records)
        all_failed.extend(failed)

    logger.info("Built %d DataFrames, %d failed files", len(dfs), len(all_failed))
    return dfs, all_failed


def _records_to_df(records: list[TransactionRecord]) -> pd.DataFrame:
    """Convert TransactionRecords to DataFrame."""
    return pd.DataFrame([r.to_dict() for r in records])


# =============================================================================
# 9. Save Outputs
# =============================================================================

def save_dataframe_outputs(
    df: pd.DataFrame,
    outputs_dir: Path,
    base_name: str,
    logger: logging.Logger
) -> None:
    """Save DataFrame to Excel with text formatting."""
    outputs_dir.mkdir(parents=True, exist_ok=True)
    path = outputs_dir / f"{base_name}.xlsx"

    with pd.ExcelWriter(path, engine="openpyxl") as writer:
        df.to_excel(writer, index=False, sheet_name="Data")

        # Format columns as text to preserve leading zeros
        ws = writer.sheets["Data"]
        for col_idx, col in enumerate(df.columns, 1):
            if df[col].dtype == object:
                for row_idx in range(2, len(df) + 2):
                    ws.cell(row=row_idx, column=col_idx).number_format = "@"

    logger.info("Saved output: %s (%d rows)", path, len(df))


# =============================================================================
# 10. Track Success
# =============================================================================

def _track_successful_files(dfs: dict[str, pd.DataFrame], ocr_success: list) -> list[dict]:
    """Track files that were successfully processed."""
    success_files = []
    seen = set()

    for kind, df in dfs.items():
        if "source_file" in df.columns:
            for f in df["source_file"].dropna().unique():
                if f not in seen:
                    success_files.append({"file_path": f, "source_kind": kind})
                    seen.add(f)

    return success_files


def _cleanup_temp(temp_path: Path, logger: logging.Logger) -> None:
    """Remove temporary directory."""
    try:
        if temp_path.exists():
            shutil.rmtree(temp_path, ignore_errors=True)
            logger.info("Cleaned up: %s", temp_path)
    except Exception as e:
        logger.warning("Cleanup failed: %s", e)
