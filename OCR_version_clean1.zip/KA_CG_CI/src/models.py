"""
Models Module - Data Classes สำหรับ OCR Smart Reconcile

โมดูลนี้กำหนดโครงสร้างข้อมูลหลักของระบบ:
- TransactionRecord: เก็บข้อมูล transaction ที่ดึงมาได้
- DateNormOptions: ตัวเลือกการแปลงวันที่
- FINNETTransactionRecord: ข้อมูล FINNET พิเศษ
"""
from dataclasses import dataclass, field, asdict
from typing import Optional


@dataclass
class TransactionRecord:
    """
    โครงสร้างข้อมูล Transaction ที่ดึงมาจากเอกสาร

    Attributes:
        agent: ชื่อบริษัท/ตัวแทน (เช่น "AECS - บริษัท หลักทรัพย์...")
        payment_type: "C" = Cash/Pay-in, "T" = Transfer
        bank_code: รหัสธนาคาร (เช่น "002", "014")
        bank_account_no_fmt: เลขบัญชีที่ format แล้ว (เช่น "002 BBL 1234567890")
        amount: จำนวนเงินที่ format แล้ว (เช่น "1,234.00")
        date: วันที่ที่ normalize แล้ว (dd/mm/yyyy)
        source_kind: ประเภทแหล่งที่มา ("Single", "Multiple", "Slip", "Excel", "FINNET")
        source_file: path ไฟล์ต้นฉบับ
    """
    agent: str
    bank_code: str
    bank_account_no_fmt: str
    amount: str
    date: str
    source_kind: str
    source_file: str
    payment_type: str = "C"

    def to_dict(self) -> dict:
        """แปลง record เป็น dictionary"""
        return asdict(self)


@dataclass
class DateNormOptions:
    """
    ตัวเลือกสำหรับการ normalize วันที่

    Attributes:
        prefer_buddhist_shorthand: True = ปีย่อ 2 หลักใช้ พ.ศ., False = ใช้ ค.ศ.
        locale_hint: "th" = บริบทภาษาไทย, "en" = บริบทภาษาอังกฤษ
    """
    prefer_buddhist_shorthand: bool = False
    locale_hint: str = "en"


@dataclass
class FINNETTransactionRecord(TransactionRecord):
    """
    โครงสร้างข้อมูล Transaction สำหรับ FINNET (ขยายจาก TransactionRecord)

    Attributes เพิ่มเติม:
        result_status: สถานะ ("success", "pending", "failed")
        original_result: ค่าดิบจาก Excel (เช่น "ทำรายการสำเร็จ")
    """
    result_status: str = ""
    original_result: str = ""
