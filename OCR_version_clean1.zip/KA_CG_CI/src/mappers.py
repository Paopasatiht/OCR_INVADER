"""
Step 07: Mappers Module
Transform OCR/Excel data to TransactionRecord
"""
import logging
import re
from pathlib import Path
from typing import Optional

import pandas as pd
import yaml

from models import TransactionRecord
from utils.helpers import (
    normalize_date,
    normalize_amount,
    normalize_account_number,
    map_account_number,
    extract_agent_from_path,
)

logger = logging.getLogger(__name__)


# =============================================================================
# 1. Config Loading
# =============================================================================

def load_mapper_config(config_dir: Path) -> dict:
    """Load all mapper configs from config/mapper/."""
    mapper_dir = config_dir / "mapper"
    return {
        "agent": _load_yaml(mapper_dir / "agent.yaml"),
        "bank_code": _load_yaml(mapper_dir / "bank_code.yaml"),
        "default_account": _load_yaml(mapper_dir / "default_account.yaml"),
        "finnet": _load_yaml(mapper_dir / "finnet.yaml"),
        "multiple_ocr_dir": mapper_dir / "multiple_ocr",
        "excel_schema_dir": mapper_dir / "excel_schema",
    }


def _load_yaml(path: Path) -> dict:
    """Load YAML file safely."""
    try:
        with open(path, "r", encoding="utf-8") as f:
            return yaml.safe_load(f) or {}
    except Exception as e:
        logger.warning("Failed to load %s: %s", path, e)
        return {}


# =============================================================================
# 2-3. Single Transaction Mapper
# =============================================================================

def map_single_transactions(
    results: dict, config: dict
) -> tuple[list[TransactionRecord], list[dict]]:
    """Map Single OCR items to TransactionRecords."""
    items = results.get("extraction_results", {}).get("Single", [])
    records, failed = [], []

    for item in items:
        try:
            rec = _map_single_item(item, config)
            if rec:
                records.append(rec)
        except Exception as e:
            logger.exception("Single item failed: %s", e)
            failed.append({"file_path": item.get("file_path", ""), "error": str(e)})

    logger.info("Single: %d records, %d failed", len(records), len(failed))
    return records, failed


def _map_single_item(item: dict, config: dict) -> Optional[TransactionRecord]:
    """Map a single OCR item to TransactionRecord."""
    file_path = item.get("file_path", "")
    fields = _get_fields(item)

    agent = extract_agent_from_path(file_path, config.get("agent", {})) or ""
    raw_acc = _get_field_value(fields, "Bank Account No.")
    raw_amount = _get_field_value(fields, "Amount")
    raw_date = _get_field_value(fields, "Date")

    mapped = map_account_number(normalize_account_number(raw_acc), config.get("bank_code", {}))
    bank_code, bank, acc_no = mapped if mapped else ("", "", "")

    return TransactionRecord(
        agent=agent,
        bank_code=bank_code,
        bank_account_no_fmt=f"{bank_code} {bank} {acc_no}".strip(),
        amount=normalize_amount(raw_amount),
        date=normalize_date(raw_date),
        source_kind="Single",
        source_file=file_path,
    )


def _get_fields(item: dict) -> dict:
    """Extract fields from analyze_result."""
    docs = item.get("analyze_result", {}).get("documents", [])
    return docs[0].get("fields", {}) if docs else {}


def _get_field_value(fields: dict, key: str) -> str:
    """Get valueString from field, try variations."""
    for k in [key, key.replace(".", ""), key.replace(" ", "")]:
        v = fields.get(k, {})
        if isinstance(v, dict):
            return v.get("valueString") or v.get("valueDate") or v.get("content") or ""
    return ""


# =============================================================================
# 4-6. Multiple Transaction Mapper
# =============================================================================

def map_multiple_transactions(
    results: dict, config: dict
) -> tuple[list[TransactionRecord], list[dict]]:
    """Map Multiple OCR items to TransactionRecords."""
    items = results.get("extraction_results", {}).get("Multiple", [])
    records, failed = [], []

    for item in items:
        try:
            recs = _map_multiple_item(item, config)
            records.extend(recs)
        except Exception as e:
            logger.exception("Multiple item failed: %s", e)
            failed.append({"file_path": item.get("file_path", ""), "error": str(e)})

    logger.info("Multiple: %d records, %d failed", len(records), len(failed))
    return records, failed


def _map_multiple_item(item: dict, config: dict) -> list[TransactionRecord]:
    """Map a multiple OCR item to TransactionRecords."""
    file_path = item.get("file_path", "")
    doc_type = item.get("doc_type", "")
    fields = _get_fields(item)
    agent = extract_agent_from_path(file_path, config.get("agent", {})) or ""

    table_type = _detect_table_type(fields)
    if not table_type:
        return []

    schema = _load_multiple_schema(config.get("multiple_ocr_dir"), doc_type, table_type)
    if not schema:
        logger.warning("No schema for %s/%s", doc_type, table_type)
        return []

    rows = fields.get(table_type, {}).get("valueArray", [])
    return _map_table_rows(rows, schema, fields, file_path, agent, config)


def _detect_table_type(fields: dict) -> Optional[str]:
    """Find field with valueArray (table data)."""
    for key, val in fields.items():
        if key == "Date":
            continue
        if isinstance(val, dict) and val.get("valueArray"):
            return key
    return None


def _load_multiple_schema(schema_dir: Path, doc_type: str, table_type: str) -> Optional[dict]:
    """Load YAML schema for multiple OCR."""
    if not schema_dir:
        return None
    # Try exact match first
    candidates = [
        schema_dir / f"{doc_type.lower().replace(' ', '_')}.yaml",
        schema_dir / f"{doc_type.split()[0].lower()}.yaml",
    ]
    for path in candidates:
        if path.exists():
            data = _load_yaml(path)
            return data.get("table_types", {}).get(table_type, {})
    return None


def _map_table_rows(
    rows: list, schema: dict, fields: dict, file_path: str, agent: str, config: dict
) -> list[TransactionRecord]:
    """Map table rows to TransactionRecords."""
    records = []
    columns = schema.get("columns", {})
    bank_mapping = config.get("bank_code", {})

    for row_entry in rows:
        row_obj = row_entry.get("valueObject", {})
        raw_acc = _get_row_value(row_obj, columns.get("to_account", ""))
        raw_amount = _get_row_value(row_obj, columns.get("amount", ""))
        raw_date = _get_row_value(row_obj, columns.get("date", "")) or _get_field_value(fields, "Date")

        mapped = map_account_number(normalize_account_number(raw_acc), bank_mapping)
        bank_code, bank, acc_no = mapped if mapped else ("", "", "")

        records.append(TransactionRecord(
            agent=agent, bank_code=bank_code,
            bank_account_no_fmt=f"{bank_code} {bank} {acc_no}".strip(),
            amount=normalize_amount(raw_amount), date=normalize_date(raw_date),
            source_kind="Multiple", source_file=file_path,
        ))
    return records


def _get_row_value(row_obj: dict, key: str) -> str:
    """Get value from row object."""
    if not key:
        return ""
    v = row_obj.get(key, {})
    return v.get("valueString") or v.get("content") or "" if isinstance(v, dict) else ""


# =============================================================================
# 7-9. Slip Transaction Mapper
# =============================================================================

def map_slip_transactions(
    results: dict, config: dict
) -> tuple[list[TransactionRecord], list[dict]]:
    """Map Slip OCR items to TransactionRecords."""
    items = results.get("extraction_results", {}).get("Slip", [])
    records, failed = [], []

    for item in items:
        try:
            rec = _map_slip_item(item, config)
            if rec:
                records.append(rec)
        except Exception as e:
            logger.exception("Slip item failed: %s", e)
            failed.append({"file_path": item.get("file_path", ""), "error": str(e)})

    logger.info("Slip: %d records, %d failed", len(records), len(failed))
    return records, failed


def _map_slip_item(item: dict, config: dict) -> Optional[TransactionRecord]:
    """Map a slip OCR item to TransactionRecord."""
    file_path = item.get("file_path", "")
    fields = _get_fields(item)
    agent = extract_agent_from_path(file_path, config.get("agent", {})) or ""

    raw_acc = _get_field_value(fields, "Bank Account No. Hint")
    raw_amount = _get_field_value(fields, "Amount")
    raw_date = _get_field_value(fields, "Date")
    bank_hint = _get_field_value(fields, "Bank Name") or _get_field_value(fields, "Bank")

    mapped = _resolve_masked_account(raw_acc, config.get("bank_code", {}), bank_hint)
    bank_code, bank, acc_no = mapped if mapped else ("", "", "")

    return TransactionRecord(
        agent=agent, bank_code=bank_code,
        bank_account_no_fmt=f"{bank_code} {bank} {acc_no}".strip(),
        amount=normalize_amount(raw_amount), date=normalize_date(raw_date),
        source_kind="Slip", source_file=file_path,
    )


def _resolve_masked_account(
    raw_acc: str, bank_mapping: dict, bank_hint: str
) -> Optional[tuple[str, str, str]]:
    """Resolve masked account using bank hint."""
    # Check masking on original string
    if not _is_masked_account(raw_acc):
        clean_acc = normalize_account_number(raw_acc)
        return map_account_number(clean_acc, bank_mapping)

    # Extract visible digits only
    visible = re.sub(r"[xX*\-\s]", "", raw_acc)
    hint_lower = bank_hint.lower() if bank_hint else ""

    for acc_no, info in bank_mapping.items():
        bank_name = info.get("bank", "").lower()
        if hint_lower and hint_lower not in bank_name and bank_name not in hint_lower:
            continue
        if acc_no.endswith(visible) or visible in acc_no:
            return info.get("bank_code"), info.get("bank"), info.get("account_no")
    return None


def _is_masked_account(acc_str: str) -> bool:
    """Check if account contains mask characters."""
    return bool(re.search(r"[xX*]", acc_str))


# =============================================================================
# 10-12. Excel Transaction Mapper
# =============================================================================

def map_excel_files(
    file_paths: list[Path], config: dict
) -> tuple[list[TransactionRecord], list[dict]]:
    """Map Excel files to TransactionRecords."""
    schemas = _load_excel_schemas(config.get("excel_schema_dir"))
    records, failed = [], []

    for path in file_paths:
        try:
            df = pd.read_excel(path)
            schema = _find_matching_schema(df, schemas)
            if not schema:
                failed.append({"file_path": str(path), "error": "No matching schema"})
                continue
            recs = _map_excel_rows(df, schema, str(path), config)
            records.extend(recs)
        except Exception as e:
            logger.exception("Excel failed %s: %s", path, e)
            failed.append({"file_path": str(path), "error": str(e)})

    logger.info("Excel: %d records, %d failed", len(records), len(failed))
    return records, failed


def _load_excel_schemas(schema_dir: Path) -> list[dict]:
    """Load all Excel schemas from directory."""
    if not schema_dir or not schema_dir.exists():
        return []
    schemas = []
    for path in schema_dir.glob("*.yaml"):
        data = _load_yaml(path)
        if data:
            schemas.append(data)
    return schemas


def _find_matching_schema(df: pd.DataFrame, schemas: list) -> Optional[dict]:
    """Find schema matching DataFrame headers."""
    df_headers = {_normalize_header(str(c)) for c in df.columns}
    for schema in schemas:
        required = schema.get("required_headers", [])
        required_norm = {_normalize_header(h) for h in required}
        if required_norm.issubset(df_headers):
            return schema
    return None


def _normalize_header(name: str) -> str:
    """Normalize header for comparison."""
    return re.sub(r"\s+", "", name.lower().strip())


def _map_excel_rows(
    df: pd.DataFrame, schema: dict, file_path: str, config: dict
) -> list[TransactionRecord]:
    """Map Excel rows to TransactionRecords."""
    records = []
    columns = schema.get("columns", {})
    bank_mapping = config.get("bank_code", {})
    agent = extract_agent_from_path(file_path, config.get("agent", {})) or ""

    for _, row in df.iterrows():
        raw_acc = str(row.get(columns.get("to_account", ""), ""))
        raw_amount = str(row.get(columns.get("amount", ""), ""))
        raw_date = str(row.get(columns.get("date", ""), ""))

        mapped = map_account_number(normalize_account_number(raw_acc), bank_mapping)
        bank_code, bank, acc_no = mapped if mapped else ("", "", "")

        records.append(TransactionRecord(
            agent=agent, bank_code=bank_code,
            bank_account_no_fmt=f"{bank_code} {bank} {acc_no}".strip(),
            amount=normalize_amount(raw_amount), date=normalize_date(raw_date),
            source_kind="Excel", source_file=file_path,
        ))
    return records


# =============================================================================
# 13-15. FINNET Excel Mapper
# =============================================================================

def map_finnet_files(
    file_paths: list[Path], config: dict
) -> tuple[list[TransactionRecord], list[dict]]:
    """Map FINNET Excel files to TransactionRecords."""
    finnet_cfg = config.get("finnet", {})
    records, failed = [], []

    for path in file_paths:
        try:
            df = pd.read_excel(path, header=finnet_cfg.get("header_row", 0))
            recs = _map_finnet_rows(df, finnet_cfg, str(path), config)
            records.extend(recs)
        except Exception as e:
            logger.exception("FINNET failed %s: %s", path, e)
            failed.append({"file_path": str(path), "error": str(e)})

    logger.info("FINNET: %d records, %d failed", len(records), len(failed))
    return records, failed


def _map_finnet_rows(
    df: pd.DataFrame, finnet_cfg: dict, file_path: str, config: dict
) -> list[TransactionRecord]:
    """Map FINNET rows to TransactionRecords."""
    records = []
    columns = finnet_cfg.get("columns", {})
    keywords = finnet_cfg.get("success_keywords", [])
    bank_mapping = config.get("bank_code", {})
    agent = extract_agent_from_path(file_path, config.get("agent", {})) or ""

    for _, row in df.iterrows():
        to_cell = str(row.get(columns.get("to_account", "To"), ""))
        raw_amount = str(row.get(columns.get("amount", "Amount"), ""))
        result_val = str(row.get(columns.get("result", "Result"), ""))

        parsed = _parse_finnet_account(to_cell, bank_mapping)
        bank_code, bank, acc_no = parsed if parsed else ("", "", "")
        status = _categorize_transaction(result_val, keywords)

        records.append(TransactionRecord(
            agent=agent, bank_code=bank_code,
            bank_account_no_fmt=f"{bank_code} {bank} {acc_no}".strip(),
            amount=normalize_amount(raw_amount), date="",
            source_kind=f"FINNET_{status}", source_file=file_path,
        ))
    return records


def _categorize_transaction(result_value: str, keywords: list) -> str:
    """Categorize as success or pending based on keywords."""
    val_lower = result_value.lower().strip()
    for kw in keywords:
        if kw.lower() in val_lower:
            return "success"
    return "pending"


def _parse_finnet_account(
    to_cell: str, bank_mapping: dict
) -> Optional[tuple[str, str, str]]:
    """Parse FINNET 'To' cell: 'BANKNAME 1234567890'."""
    parts = to_cell.strip().split()
    if len(parts) < 2:
        return None
    acc_no = normalize_account_number(parts[-1])
    mapped = map_account_number(acc_no, bank_mapping)
    if mapped:
        return mapped
    # Fallback: use bank name from cell
    bank_name = " ".join(parts[:-1])
    return "", bank_name, acc_no
