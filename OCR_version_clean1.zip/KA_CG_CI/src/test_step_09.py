"""
Step 09 Test: main.py
"""
import logging
import tempfile
from pathlib import Path

from main import (
    _get_today_string,
    _get_today_dashed,
    _setup_logging,
    _load_config,
    _get_cache_paths,
    _save_results_json,
    _cleanup_temp,
)


def test_step_09():
    # Test _get_today_string (YYYYMMDD)
    today = _get_today_string()
    assert len(today) == 8
    assert today.isdigit()

    # Test _get_today_dashed (YYYY-MM-DD)
    today_dashed = _get_today_dashed()
    assert len(today_dashed) == 10
    assert today_dashed[4] == "-" and today_dashed[7] == "-"

    # Test _load_config
    config_path = Path(__file__).parent.parent / "config" / "kasset_infra.yaml"
    config = _load_config(config_path)
    assert "paths" in config
    assert "sharepoint" in config

    # Test _get_cache_paths
    base_dir = Path(__file__).parent.parent
    paths = _get_cache_paths(config, base_dir)
    assert "inputs" in paths
    assert "outputs" in paths
    assert "temp" in paths

    # Test _setup_logging (log_YYYY-MM-DD.txt)
    logs_dir = base_dir / "Logs"
    logger = _setup_logging(logs_dir, today_dashed)
    assert logger is not None
    log_file = logs_dir / f"log_{today_dashed}.txt"
    assert log_file.exists()
    for handler in logger.handlers[:]:
        handler.close()
        logger.removeHandler(handler)

    # Test _save_results_json (extraction_results_YYYY-MM-DD.json)
    with tempfile.TemporaryDirectory() as tmpdir:
        outputs_dir = Path(tmpdir) / "outputs"
        results = {"status": "success", "count": 10}
        _save_results_json(results, outputs_dir, today_dashed)
        json_path = outputs_dir / f"extraction_results_{today_dashed}.json"
        assert json_path.exists()

    # Test _cleanup_temp
    with tempfile.TemporaryDirectory() as tmpdir:
        temp_dir = Path(tmpdir) / "temp"
        temp_dir.mkdir()
        (temp_dir / "test.txt").write_text("test")

        test_logger = logging.getLogger("test_cleanup")
        _cleanup_temp(temp_dir, test_logger)
        assert not temp_dir.exists()

    print("STEP 09 PASSED")


if __name__ == "__main__":
    test_step_09()
