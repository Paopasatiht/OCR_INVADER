"""
Config Module - โหลด configuration จาก YAML files

Files:
- config/azure.yaml: Azure credentials (uses .env)
- config/kasset_infra.yaml: paths, sharepoint, email
"""
import json
import os
import re
from pathlib import Path
from typing import Any

import yaml
from dotenv import load_dotenv


# =============================================================================
# Environment Variables
# =============================================================================

def load_env(base_dir: Path) -> None:
    """Load .env file from project root."""
    env_path = base_dir / ".env"
    if env_path.exists():
        load_dotenv(env_path)


def _expand_env_vars(obj: Any) -> Any:
    """Recursively expand ${VAR} in config values."""
    if isinstance(obj, dict):
        return {k: _expand_env_vars(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_expand_env_vars(i) for i in obj]
    if isinstance(obj, str):
        pattern = r"\$\{(\w+)\}"
        matches = re.findall(pattern, obj)
        for var in matches:
            val = os.environ.get(var, "")
            obj = obj.replace(f"${{{var}}}", val)
        return obj
    return obj


# =============================================================================
# File Loaders
# =============================================================================

def load_yaml(path: Path, expand_env: bool = False) -> dict:
    """โหลด YAML file และ return เป็น dict"""
    with open(path, "r", encoding="utf-8") as f:
        config = yaml.safe_load(f) or {}
    if expand_env:
        config = _expand_env_vars(config)
    return config


def load_json(path: Path) -> dict:
    """โหลด JSON file และ return เป็น dict"""
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


# =============================================================================
# Config Loaders
# =============================================================================

def load_azure_config(config_dir: Path, base_dir: Path = None) -> dict:
    """โหลด Azure credentials จาก azure.yaml (with .env expansion)"""
    if base_dir:
        load_env(base_dir)
    path = config_dir / "azure.yaml"
    return load_yaml(path, expand_env=True)


def load_infra_config(config_dir: Path) -> dict:
    """โหลด infrastructure config จาก kasset_infra.yaml"""
    path = config_dir / "kasset_infra.yaml"
    return load_yaml(path)


def load_all_config(config_dir: Path, base_dir: Path) -> dict:
    """โหลด config ทั้งหมดรวมกัน"""
    load_env(base_dir)
    return {
        "azure": load_azure_config(config_dir),
        "infra": load_infra_config(config_dir),
    }


# =============================================================================
# Path Helpers
# =============================================================================

def resolve_path(base_dir: Path, relative: str) -> Path:
    """แปลง relative path เป็น absolute path"""
    path = Path(relative.replace("\\", "/"))
    if path.is_absolute():
        return path
    return (base_dir / path).resolve()


def ensure_directory(path: Path) -> None:
    """สร้าง directory ถ้ายังไม่มี"""
    path.mkdir(parents=True, exist_ok=True)


def get_cache_paths(infra: dict, base_dir: Path) -> dict[str, Path]:
    """สร้าง cache paths จาก config"""
    paths_config = infra.get("paths", {})
    return {
        "inputs": resolve_path(base_dir, paths_config.get("cache_inputs", "Cache/Inputs")),
        "outputs": resolve_path(base_dir, paths_config.get("cache_outputs", "Cache/Outputs")),
        "temp": resolve_path(base_dir, paths_config.get("cache_temp", "Cache/Temp")),
        "logs": resolve_path(base_dir, paths_config.get("logs", "Logs")),
    }


# =============================================================================
# Convenience Functions
# =============================================================================

def get_document_intelligence_config(azure_config: dict) -> dict:
    """Extract Document Intelligence settings from azure config."""
    return azure_config.get("document_intelligence", {})


def get_openai_config(azure_config: dict) -> dict:
    """Extract OpenAI settings from azure config."""
    return azure_config.get("openai", {})


def get_cognitive_search_config(azure_config: dict) -> dict:
    """Extract Cognitive Search settings from azure config."""
    return azure_config.get("cognitive_search", {})
