# วิธีเพิ่ม Slip/Mobile Banking รูปแบบใหม่

## คำถาม
> จะเพิ่ม Slip รูปแบบใหม่ ต้องทำอย่างไร?

## ตอบ

### Slip คืออะไร?
- รูป screenshot จาก mobile banking app
- เลขบัญชีมักถูก mask บางส่วน (เช่น xxx-x-x6827-x)
- ตัวอย่างที่มีอยู่: `Slip` (PromptPay Slip)

### ความแตกต่างจาก Single

| | Single | Slip |
|--|--------|------|
| Field name | `Bank Account No.` | `Bank Account No. Hint` |
| เลขบัญชี | เต็ม (1234567890) | mask (xxx-x-x6827-x) |
| Mapper | `SingleTransactionFormMapper` | `SlipTransactionFormMapper` |
| Account matching | exact match | partial/mask match |

### ขั้นตอน

#### Step 1: สร้าง Extraction Model บน Azure DI Studio

1. สร้าง **Custom extraction model**
2. Label fields:
   ```
   Bank Account No. Hint  ← เลขบัญชี (อาจถูก mask)
   Amount                 ← จำนวนเงิน
   Date                   ← วันที่
   ```
3. Train model
4. จด **Model ID**

#### Step 2: Update Classifier

1. เพิ่ม class ใหม่ หรือ เพิ่ม samples ให้ class `Slip` ที่มีอยู่
2. Re-train classifier

#### Step 3: แก้ไข `Config/ocr_config/model_ids.json`

**กรณี A: ใช้ class Slip เดิม (แค่เพิ่ม training samples)**
```json
{
    "Slip": ["CS-Smart-reconcile-PromptPay-Slip", "Slip"]  // ไม่ต้องแก้
}
```

**กรณี B: สร้าง class ใหม่ (เช่น Slip รูปแบบต่าง)**
```json
{
    "Slip": ["CS-Smart-reconcile-PromptPay-Slip", "Slip"],
    "Slip KBank": ["CS-Smart-reconcile-KBank-Slip", "Slip"]  // ← เพิ่ม
}
```

### การ Match เลขบัญชีแบบ Mask

`SlipTransactionFormMapper` ใช้ `map_account_number_from_hint()` ซึ่งสามารถ:

1. **Mask alignment** - เทียบตำแหน่ง x กับเลข
   ```
   Hint: xxx-x-x6827-x
   Full: 123-4-56827-0  ← match ถ้าเลขที่เห็นตรงกัน
   ```

2. **Suffix matching** - ถ้ามีเลขท้าย 4-6 หลัก
   ```
   Hint: ****6827
   Full: 1234567890  ← match ถ้าลงท้าย 6827 (พิจารณา position)
   ```

### Files ที่เกี่ยวข้อง
| File | Action |
|------|--------|
| `Config/ocr_config/model_ids.json` | เพิ่ม/แก้ไข entry |
| `Config/mapping_config/Bank_Codes.json` | ต้องมีเลขบัญชีเต็มเพื่อ match |

### หมายเหตุ
- ❌ ไม่ต้องสร้าง schema file (Slip ใช้ fixed fields)
- ⚠️ ต้องมีเลขบัญชีเต็มใน `Bank_Codes.json` เพื่อให้ match กับ hint ได้
