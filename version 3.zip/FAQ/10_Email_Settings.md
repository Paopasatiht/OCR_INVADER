# วิธี Config Email Settings

## คำถาม 1
> จะเปลี่ยนคนรับ email สรุปผล ต้องแก้ที่ไหน?

## ตอบ

### File Location
```
Config/config.cfg → [Email]
```

### Setting
```ini
[Email]
to_emails = email1@company.com, email2@company.com, email3@company.com
```

### รูปแบบ
- คั่นด้วย comma (,)
- มี space หลัง comma ได้

### ตัวอย่าง
```ini
# คนเดียว
to_emails = admin@company.com

# หลายคน
to_emails = admin@company.com, manager@company.com, team@company.com
```

---

## คำถาม 2
> จะเปลี่ยน SMTP server ต้องแก้ที่ไหน?

## ตอบ

### File Location
```
Config/config.cfg → [Email]
```

### Settings
```ini
[Email]
sender_email = noreply@company.com
smtp_server = smtp.company.com
smtp_port = 25
```

### ตัวอย่างค่าปัจจุบัน
```ini
[Email]
sender_email = OCR_Master@kasikornasset.com
smtp_server = kamail01.tfam.co.th
smtp_port = 25
```

### Common SMTP Ports

| Port | Usage |
|------|-------|
| 25 | Standard SMTP (no encryption) |
| 465 | SMTP over SSL |
| 587 | SMTP with STARTTLS |

### หมายเหตุ
- ระบบปัจจุบันใช้ SMTP แบบไม่มี authentication
- ถ้าต้องการ authentication ต้องแก้ code ใน `Functions/email/smtp_handler.py`

---

## คำถาม 3
> จะแก้ไข email template (HTML) ต้องแก้ที่ไหน?

## ตอบ

### Folder Location
ตาม config:
```ini
[Local_Paths]
Email_Template_Path = Email Format\
```

### Template Files

| File | ใช้เมื่อ |
|------|--------|
| `Success.html` | ทุกไฟล์ process สำเร็จ |
| `Partial_Success.html` | บางไฟล์สำเร็จ บางไฟล์ fail |
| `Fail.html` | ทุกไฟล์ fail |
| `No_Valid_File.html` | ไม่มีไฟล์ที่ valid |
| `SharePoint_Fail.html` | SharePoint error |

### Template Selection Logic

```python
if sharepoint_failed:
    template = "SharePoint_Fail.html"
elif no_failures and no_success:
    template = "No_Valid_File.html"
elif no_failures and has_success:
    template = "Success.html"
elif has_failures and has_success:
    template = "Partial_Success.html"
else:  # has_failures and no_success
    template = "Fail.html"
```

### การแก้ไข Template

1. เปิดไฟล์ HTML ที่ต้องการแก้
2. แก้ไข HTML/CSS ตามต้องการ
3. Save

### ตัวอย่าง Template Structure
```html
<!DOCTYPE html>
<html>
<head>
    <style>
        /* CSS styles */
    </style>
</head>
<body>
    <h1>OCR Processing Summary</h1>
    <p>Date: ...</p>
    <p>Status: SUCCESS</p>
    <!-- content -->
</body>
</html>
```

---

## Email Subject Format

Email subject ถูกสร้างอัตโนมัติ:
```
[OCR Summary] SUCCESS - 2026-01-25 10:30
[OCR Summary] PARTIAL SUCCESS - 2026-01-25 10:30
[OCR Summary] FAILED - 2026-01-25 10:30
[OCR Summary] SHAREPOINT FAILED - 2026-01-25 10:30
```

### เปลี่ยน Prefix
แก้ไขใน `Functions/Email_Sender.py`:
```python
subject_prefix: str = "OCR Summary"  # ← เปลี่ยนตรงนี้
```
