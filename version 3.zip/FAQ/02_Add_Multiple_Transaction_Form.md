# วิธีเพิ่ม Pay-in Form แบบ Multiple Transaction (ธนาคารใหม่)

## คำถาม
> จะเพิ่ม Pay-in form ของธนาคารใหม่ (แบบ Multiple/ตาราง) ต้องทำอย่างไร?

## ตอบ

### Multiple Form คืออะไร?
- เอกสาร 1 หน้า = หลายรายการ transaction (เป็นตาราง)
- มี table ที่มี columns: เลขบัญชี, จำนวนเงิน, วันที่
- ตัวอย่างที่มีอยู่: `KBANK Multiple`, `SCB Multiple`, `BBL Multiple`, `KTB Multiple`, `KKP Multiple`, `BAY Multiple`, `GSB Multiple`

### ขั้นตอน

#### Step 1: สร้าง Extraction Model บน Azure DI Studio

1. เข้า [Document Intelligence Studio](https://documentintelligence.ai.azure.com/)
2. สร้าง **Custom extraction model**
3. Upload ตัวอย่างเอกสาร 5-10 ชุด
4. Label **table** และ columns:
   - Table name: `Transaction Table Type 1`
   - Columns ที่ต้องมี (ชื่อตาม document จริง)
5. Train model
6. จด **Model ID**

#### Step 2: Update Classifier บน Azure DI Studio

1. ไปที่ Custom classifier
2. เพิ่ม class ใหม่ เช่น `TTB Multiple`
3. Upload training samples
4. Re-train classifier

#### Step 3: แก้ไข `Config/ocr_config/model_ids.json`

```json
{
    "KBANK Multiple": ["CS-Smart-reconcile-KBank-Multiple-Pay-In", "Multiple"],
    "SCB Multiple": ["CS-Smart-reconcile-SCB-Multiple-Pay-In", "Multiple"],
    "BBL Multiple": ["CS-Smart-reconcile-BBL-Multiple-Pay-In-2", "Multiple"],
    "KTB Multiple": ["CS-Smart-reconcile-KTB-Multiple-Pay-In", "Multiple"],
    "KKP Multiple": ["CS-Smart-reconcile-KKP-Multiple-Pay-In", "Multiple"],
    "BAY Multiple": ["CS-Smart-reconcile-BAY-Multiple-Pay-In", "Multiple"],
    "GSB Multiple": ["CS-Smart-reconcile-GSB-Multiple-Pay-In-20260128", "Multiple"],
    "NEW Bank Multiple": ["<Model ID จาก Step 1>", "Multiple"],  // ← เพิ่มบรรทัดนี้
    "Doc_Classifier": "CS-Smart-Reconcile-Classification-20260127"
}
```

### Multiple Forms ที่มีอยู่ในระบบ (ปัจจุบัน)

| Class Name | Model ID | ธนาคาร |
|------------|----------|--------|
| KBANK Multiple | CS-Smart-reconcile-KBank-Multiple-Pay-In | กสิกรไทย |
| SCB Multiple | CS-Smart-reconcile-SCB-Multiple-Pay-In | ไทยพาณิชย์ |
| BBL Multiple | CS-Smart-reconcile-BBL-Multiple-Pay-In-2 | กรุงเทพ |
| KTB Multiple | CS-Smart-reconcile-KTB-Multiple-Pay-In | กรุงไทย |
| KKP Multiple | CS-Smart-reconcile-KKP-Multiple-Pay-In | เกียรตินาคินภัทร |
| BAY Multiple | CS-Smart-reconcile-BAY-Multiple-Pay-In | กรุงศรี |
| GSB Multiple | CS-Smart-reconcile-GSB-Multiple-Pay-In-20260128 | ออมสิน |

#### Step 4: สร้าง Schema File

สร้าง folder และ file:
```
Config/mapping_config/multiple_OCR/TTB Multiple/Transaction Table Type 1.json
```

เนื้อหา:
```json
{
  "schemas": [
    {
        "name": "TTB Transaction Table Type 1",
        "table_name": "Transaction Table Type 1",
        "mapping_config": {
            "cells": {
                "date": "Date"           // ถ้า date อยู่นอก table (เป็น cell เดี่ยว)
            },
            "columns": {
                "date": "วันที่",          // ถ้า date อยู่ใน table
                "to_account": "เลขบัญชี",
                "amount": "จำนวนเงิน"
            }
        }
    }
  ]
}
```

### Schema Config อธิบาย

| Field | คำอธิบาย |
|-------|---------|
| `name` | ชื่อ schema (อะไรก็ได้) |
| `table_name` | ชื่อ table ที่ label ใน Azure DI |
| `cells` | mapping สำหรับ fields ที่อยู่นอก table |
| `columns` | mapping สำหรับ columns ใน table |

### Mapping Keys ที่ต้องมี

| Key | คำอธิบาย | ตัวอย่าง Column Name |
|-----|---------|---------------------|
| `date` | วันที่ทำรายการ | "วันที่ทำ รายการ", "settle date" |
| `to_account` | เลขบัญชีปลายทาง | "บัญชีผู้รับเงิน", "Account CR." |
| `amount` | จำนวนเงิน | "จำนวนเงิน", "Net Amount" |

### ตัวอย่าง Schema ที่มีอยู่

**KBank Multiple:**
```json
{
  "schemas": [
    {
        "name": "KBank Transaction Table Type 1",
        "table_name": "Transaction Table Type 1",
        "mapping_config": {
            "cells": {},
            "columns": {
                "date": "วันที่ทำ รายการ",
                "to_account": "บัญชีผู้รับเงิน",
                "amount": "จำนวนเงิน"
            }
        }
    }
  ]
}
```

**SCB Multiple:**
```json
{
  "schemas": [
    {
        "name": "SCB Transaction Table Type 1",
        "table_name": "Transaction Table Type 1",
        "mapping_config": {
            "cells": {},
            "columns": {
                "date": "settle date",
                "to_account": "Account CR.",
                "amount": "Net Amount ( THB )"
            },
            "other_settings": {
                "prefer_buddhist_shorthand": "False"
            }
        }
    }
  ]
}
```

**KTB Multiple:**
```json
{
  "schemas": [
    {
        "name": "KTB Transaction Table Type 1",
        "table_name": "Transaction Table Type 1",
        "mapping_config": {
            "cells": {
                "date": "Date"
            },
            "columns": {
                "to_account": "Account No",
                "amount": "Tr. Amt"
            }
        }
    }
  ]
}
```

**KKP Multiple:**
```json
{
  "schemas": [
    {
        "name": "KKP Transaction Table Type 1",
        "table_name": "Transaction Table Type 1",
        "mapping_config": {
            "cells": {
                "date": "Date"
            },
            "columns": {
                "to_account": "เลขที่บัญชี/พร้อมเพย์",
                "amount": "จำนวนเงินเข้าบัญชีปลายทาง"
            }
        }
    }
  ]
}
```

**GSB Multiple (พร้อม row_filter):**
```json
{
  "schemas": [
    {
        "name": "GSB Transaction Table Type 1",
        "table_name": "Transaction Table Type 1",
        "mapping_config": {
            "cells": {
                "to_account": "Account No"
            },
            "columns": {
                "date": "Date",
                "amount": "Credits"
            },
            "row_filter": {
                "enabled": true,
                "column": "Description",
                "match_type": "contains",
                "keywords": ["DDA Deposit by Cash"],
                "case_sensitive": false
            },
            "other_settings": {
                "prefer_buddhist_shorthand": true,
                "locale_hint": "th"
            }
        }
    }
  ]
}
```

### Files ที่เกี่ยวข้อง
| File | Action |
|------|--------|
| `Config/ocr_config/model_ids.json` | เพิ่ม entry ใหม่ |
| `Config/mapping_config/multiple_OCR/<Bank>/` | สร้าง folder + schema.json |
| `Config/mapping_config/Bank_Codes.json` | เพิ่มเลขบัญชี (ถ้ามีใหม่) |
