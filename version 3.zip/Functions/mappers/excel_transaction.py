
# -*- coding: utf-8 -*-
from __future__ import annotations

from typing import Union, Optional, Dict, List, Tuple
from pathlib import Path
import logging
import json
import configparser
import glob
import re

import pandas as pd

# Reuse your existing base types and helpers
from Functions.mappers.base import TransactionRecord, TransactionFormMapper, DateNormOptions
from Functions.mappers.helpers import (
    extract_agent_from_path,
    normalize_date,
    normalize_header,            # your helper: str -> str
    load_shared_agent_names,     # optional shared mappings (reuse if needed)
    load_shared_bank_codes,      # optional shared mappings (reuse if needed)
    map_account_number,           # optional account parsing utility
    to_optional_bool,
    to_int,
    to_bool,
    to_locale
)


class OtherExcelDirectoryMapper(TransactionFormMapper):
    """
    Schema-driven mapper for non-FINNET Excels.

    Flow:
      1) Discover & match schema (header_row_index + normalized columns)
      2) Read "cells" from mapping_config (fixed values like date in preheader, A1-notation)
      3) Read row values from "columns" in mapping_config (normalized column names)
      4) Emit List[TransactionRecord] with robust fallbacks

    Differences from FINNETExcelMapper:
      - Returns List[TransactionRecord] only (no FINNETMapResult tiers).
      - No CSV saving here.
      - Discovery-based: finds schema dynamically by header index + column match.
    """

    # -----------------------------------------------------------------------
    # 0) Initialization & shared resources
    # -----------------------------------------------------------------------
    def __init__(
        self,
        config_path: Path,
        log: logging.Logger,
        sheet_name: Optional[Union[int, str]] = 0
    ):
        self.log = log
        self.sheet_name = sheet_name

        cfg = configparser.ConfigParser()
        cfg.read(str(config_path))
        # Allow override via config. Defaults to "Config/mapping_config/other_excels"
        self.schema_root_dir = Path(
            cfg.get("Local_Paths", "other_excel_mapping_schema_dir",
                    fallback="Config/mapping_config/other_excels")
        )

        # Shared JSONs (available for account parsing & agent naming)
        self.bank_codes_mapping = load_shared_bank_codes(config_path, log)
        self.agent_names_mapping = load_shared_agent_names(config_path, log)

    # -----------------------------------------------------------------------
    # 1) Schema discovery utilities
    # -----------------------------------------------------------------------

    def _iter_schema_files(self) -> List[Path]:
        """
        Find all schema files under the schema root directory.

        New structure: each leaf folder contains *.json named by schema, e.g.:
        .../other_excels/KBank/unitlink/KBank_unitlink.json

        We now glob **all JSON files** instead of a fixed 'schema.json'.
        """
        pattern = str(self.schema_root_dir / "**" / "*.json")
        candidates = [Path(p) for p in glob.glob(pattern, recursive=True)]
        return candidates

    @staticmethod
    def _schema_name_to_basename(name: str) -> str:
        """
        Convert a logical schema name to a JSON basename for matching file names.
        Accepts hyphen/space/underscore variants.

        'KBank-unitlink' -> 'KBank_unitlink.json'
        """
        base = re.sub(r"[\s-]+", "_", name.strip())
        return f"{base}.json"


    def _load_schema_file(self, path: Path) -> Dict:
        """Load a single schema.json file."""
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)

    def _normalize_list(self, xs: List[str]) -> List[str]:
        """Normalize a list of header names with your normalize_header()."""
        return [normalize_header(str(x)) for x in xs]

    # -----------------------------------------------------------------------
    # 2) Reading helpers (by header row index + A1 cells)
    # -----------------------------------------------------------------------
    def _read_with_header_index(
        self,
        excel_source: Union[Path, str, bytes, bytearray, pd.DataFrame],
        header_row_index: int,
        sheet_name: Optional[Union[int, str]] = None
    ) -> pd.DataFrame:
        """
        Read as DataFrame using header_row_index (dtype=str to avoid numeric coercion).
        """
        sn = self.sheet_name if sheet_name is None else sheet_name

        # DataFrame passthrough
        if isinstance(excel_source, pd.DataFrame):
            return excel_source.copy()

        # Bytes/bytearray (try XLSX first, then CSV, then XLS)
        if isinstance(excel_source, (bytes, bytearray)):
            from io import BytesIO, StringIO
            try:
                return pd.read_excel(BytesIO(excel_source), sheet_name=sn,
                                    header=None, engine="openpyxl", dtype=str)
            except Exception:
                try:
                    text = excel_source.decode("utf-8")
                    return pd.read_csv(StringIO(text), header=None, dtype=str)
                except Exception:
                    # Optionally try xlrd for XLS bytes
                    from io import BytesIO as BIO
                    return pd.read_excel(BIO(excel_source), sheet_name=sn,
                                        header=None, engine="xlrd", dtype=str)


        # Path/str
        ext = Path(str(excel_source)).suffix.lower().lstrip(".")
        if ext == "csv":
            return pd.read_csv(excel_source, header=header_row_index, dtype=str)
        elif ext in ("xlsx", "xlsm"):
            return pd.read_excel(excel_source, sheet_name=sn, header=header_row_index,
                                 engine="openpyxl", dtype=str)
        elif ext == "xls":
            return pd.read_excel(excel_source, sheet_name=sn, header=header_row_index,
                                 engine="xlrd", dtype=str)
        else:
            # Unknown: try CSV, then XLSX
            self.log.debug("Unknown extension for '%s'; trying CSV then XLSX", excel_source)
            try:
                return pd.read_csv(excel_source, header=header_row_index, dtype=str)
            except Exception as e_csv:
                self.log.debug("CSV read failed: %s", e_csv)
                return pd.read_excel(excel_source, sheet_name=sn, header=header_row_index,
                                     engine="openpyxl", dtype=str)

    def _read_preview_no_header(
        self,
        excel_source: Union[Path, str, bytes, bytearray],
        sheet_name: Optional[Union[int, str]] = None
    ) -> pd.DataFrame:
        """
        Read the sheet with header=None to allow cell-level access by row/col.
        Used for 'cells' from mapping_config (e.g., 'B1').
        """
        sn = self.sheet_name if sheet_name is None else sheet_name

        if isinstance(excel_source, (bytes, bytearray)):
            from io import BytesIO
            return pd.read_excel(BytesIO(excel_source), sheet_name=sn,
                                 header=None, engine="openpyxl", dtype=str)

        ext = Path(str(excel_source)).suffix.lower().lstrip(".")
        if ext in ("xlsx", "xlsm", "xls"):
            engine = "openpyxl" if ext in ("xlsx", "xlsm") else "xlrd"
            return pd.read_excel(excel_source, sheet_name=sn, header=None, engine=engine, dtype=str)
        elif ext == "csv":
            # CSV has no cells in A1 sense; treat as row/col nonetheless
            return pd.read_csv(excel_source, header=None, dtype=str)
        else:
            # fallback
            return pd.read_excel(excel_source, sheet_name=sn, header=None, engine="openpyxl", dtype=str)

    # -----------------------------------------------------------------------
    # 3) A1 notation parsing
    # -----------------------------------------------------------------------
    @staticmethod
    def _a1_to_idx(a1: str) -> Tuple[int, int]:
        """
        Convert A1 address (e.g., 'B1', 'AA12') to zero-based (row_idx, col_idx).
        """
        if not a1 or not isinstance(a1, str):
            raise ValueError(f"Invalid A1 address: {a1}")
        m = re.match(r"^([A-Za-z]+)(\d+)$", a1.strip())
        if not m:
            raise ValueError(f"Invalid A1 address format: {a1}")
        col_letters, row_digits = m.groups()
        row_idx = int(row_digits) - 1  # 1-based -> 0-based

        # Convert letters to number (A=1, B=2, ... AA=27, ...), then 0-based
        col_idx = 0
        for ch in col_letters.upper():
            col_idx = col_idx * 26 + (ord(ch) - ord('A') + 1)
        col_idx -= 1
        return row_idx, col_idx

    # -----------------------------------------------------------------------
    # 4) Schema matching (returns normalized columns)
    # -----------------------------------------------------------------------
    def _find_matching_schema(
        self,
        excel_source: Union[Path, str, bytes, bytearray, pd.DataFrame],
        explicit_schema_name: Optional[str] = None
    ) -> Tuple[Dict, Path, pd.DataFrame]:
        """
        Iterate all schema JSONs and return (schema_dict, schema_path, df) when:
        - df read with schema['header_row_index']
        - normalized df.columns == normalized schema['columns']
        If explicit_schema_name is provided, only consider JSONs whose basename
        matches that schema name (underscores vs hyphens are normalized).
        """
        schema_files = self._iter_schema_files()
        if not schema_files:
            raise FileNotFoundError(f"No schema JSON files found under: {self.schema_root_dir}")

        if explicit_schema_name:
            expected_basename = self._schema_name_to_basename(explicit_schema_name)
            # Filter to only files whose basename (case-insensitive) equals the expected one
            schema_files = [p for p in schema_files if p.name.lower() == expected_basename.lower()]
            if not schema_files:
                raise FileNotFoundError(
                    f"Schema file for '{explicit_schema_name}' not found. "
                    f"Expected basename: {expected_basename}"
                )

        for spath in schema_files:
            sobj = self._load_schema_file(spath)
            schemas = sobj.get("schemas") or []

            # File contains one or more schema entries; iterate each
            for s in schemas:
                # Validate minimal keys
                if "header_row_index" not in s or "columns" not in s:
                    self.log.debug("Skipping schema without header_row_index/columns in %s", spath)
                    continue

                hdr_idx = int(s["header_row_index"])
                df = self._read_with_header_index(excel_source, header_row_index=hdr_idx, sheet_name=self.sheet_name)

                # Normalize both sides
                df_cols_norm = self._normalize_list(list(df.columns))
                schema_cols_norm = self._normalize_list(list(s.get("columns", [])))

                set_df = set(df_cols_norm)
                set_schema = set(schema_cols_norm)

                if set_schema.issubset(set_df): # Allow superset checking in-case the real files return extra columns
                    # Important: set normalized columns on df for downstream mapping
                    df.columns = df_cols_norm
                    # Prefer 'name' in schema, else fallback to filename stem
                    matched_name = s.get("name") or spath.stem
                    self.log.info("Matched schema '%s' in %s", matched_name, spath)
                    return (s, spath, df)

        raise ValueError("No matching schema found using header_row_index + columns match.")

    # -----------------------------------------------------------------------
    # 5) Column resolver (uses mapping_config.columns)
    # -----------------------------------------------------------------------
    def _resolve_column(self, df: pd.DataFrame, colmap: Dict[str, str], key: str,
                        fallbacks: Optional[List[str]] = None) -> str:
        """
        Resolve logical key to concrete df column via schema mapping_config.columns.
        Everything normalized via normalize_header(). If not found, optional fallbacks are tried.
        """
        fallbacks = fallbacks or []
        columns_map = colmap or {}  # expecting a dict of logical->header
        if key in columns_map:
            mapped = normalize_header(columns_map[key])
            if mapped in df.columns:
                return mapped
        for fb in fallbacks:
            n = normalize_header(fb)
            if n in df.columns:
                return n
        return ""  # unresolved

    # -----------------------------------------------------------------------
    # 6) Cells reader (uses mapping_config.cells)
    # -----------------------------------------------------------------------
    def _extract_fixed_fields_from_cells(
        self,
        excel_source: Union[Path, str, bytes, bytearray],
        cells_map: Dict[str, str]
    ) -> Dict[str, str]:
        """
        Read fixed per-table values from A1-style cells (e.g., {"date": "B1"}).
        Returns a dict of {logical_field: cell_value_as_str}.
        """
        fixed: Dict[str, str] = {}
        if not cells_map:
            return fixed

        try:
            preview = self._read_preview_no_header(excel_source, sheet_name=self.sheet_name)
        except Exception as e:
            self.log.debug("Failed to read preview for cells: %s", e)
            return fixed

        for logical_key, a1 in (cells_map or {}).items():
            val = ""
            try:
                r, c = self._a1_to_idx(str(a1))
                if 0 <= r < len(preview.index) and 0 <= c < len(preview.columns):
                    raw = preview.iloc[r, c]
                    val = "" if pd.isna(raw) else str(raw).strip()
                else:
                    self.log.debug("A1 '%s' out of bounds (r=%d,c=%d).", a1, r, c)
            except Exception as e:
                self.log.debug("Failed to read A1 '%s': %s", a1, e)
            fixed[logical_key] = val
        return fixed

    # -----------------------------------------------------------------------
    # 7) Map
    # -----------------------------------------------------------------------
    def map(
        self,
        excel_source: Union[Path, str, bytes, bytearray, pd.DataFrame],
        input_dir: Path, # For saving relative path
        explicit_schema_name: Optional[str] = None,
        source_path_for_agent: Optional[Union[str, Path]] = None
    ) -> Union[List[TransactionRecord], str]:
        """
        1) Identify matching schema
        2) Extract fixed fields from mapping_config.cells (A1 notation)
        3) Resolve row-level columns from mapping_config.columns
        4) Emit TransactionRecord list (agent via path; date uses row value else fixed 'date')
        """
        # --- Step 1: match schema & normalize df columns
        try:
            schema, schema_path, df = self._find_matching_schema(excel_source, explicit_schema_name)
        except Exception:
            # no schema found flag
            return "no_schema"

        # --- Step 2: mapping_config (cells & columns)
        mc: Dict[str, Dict[str, str]] = schema.get("mapping_config", {}) or {}
        cells_map: Dict[str, str] = mc.get("cells", {}) or {}
        columns_map: Dict[str, str] = mc.get("columns", {}) or {}

        # --- Step 3: extract fixed fields (A1 notation) BEFORE row mapping -> Use as fallback automatically if columns key does not contain that value
        fixed_fields = self._extract_fixed_fields_from_cells(excel_source, cells_map)
        # Any found fixed cells in schema will be stored
        
        # ---------------- Date normalization options (schema-driven) ----------------
        schema_other_options = mc.get("other_settings", {}) or {}

        # Determine defaults from your dataclass (for clarity; you could hardcode too)
        _default = DateNormOptions()
        prefer_buddhist_shorthand = to_optional_bool(
            schema_other_options.get("prefer_buddhist_shorthand", None)
        )
        pivot_offset = to_int(
            schema_other_options.get("pivot_offset", _default.pivot_offset),
            _default.pivot_offset
        )
        buddhist_proximity_window = to_int(
            schema_other_options.get("buddhist_proximity_window", _default.buddhist_proximity_window),
            _default.buddhist_proximity_window
        )
        assume_day_first = to_bool(
            schema_other_options.get("assume_day_first", _default.assume_day_first),
            _default.assume_day_first
        )
        locale_hint = to_locale(schema_other_options.get("locale_hint", _default.locale_hint))

        
        # Optional: inferred tweaks—if locale_hint is 'th' but assume_day_first missing, enforce True
        if schema_other_options.get("assume_day_first") is None and locale_hint == "th":
            assume_day_first = True

        options = DateNormOptions(
            prefer_buddhist_shorthand=prefer_buddhist_shorthand,
            pivot_offset=pivot_offset,
            buddhist_proximity_window=buddhist_proximity_window,
            assume_day_first=assume_day_first,
            locale_hint=locale_hint
        )

        # --- Step 4: derive agent from path (no column)
        if isinstance(excel_source, (str, Path)):
            path_str = str(excel_source)
        elif source_path_for_agent is not None:
            path_str = str(source_path_for_agent)
        else:
            path_str = ""
        agent = extract_agent_from_path(
            path_str = path_str, 
            agent_map = self.agent_names_mapping) if path_str else ""

        
        # --- Step 5: resolve logical columns (normalized names)
        c_toacct = self._resolve_column(df, columns_map, "to_account", []) or None
        c_amount = self._resolve_column(df, columns_map, "amount", [])     or None
        c_date   = self._resolve_column(df, columns_map, "date", [])       or None
        # Any absent field will be filled with stored fixed value
                                        
        
        # Precompute column indices for robust row access
        idx_toacct = df.columns.get_loc(c_toacct) if c_toacct else None
        idx_amount = df.columns.get_loc(c_amount) if c_amount else None
        idx_date   = df.columns.get_loc(c_date)   if c_date   else None   

        # --- Step 6: build records (with robust fallbacks)
        # --- Parse ignore_rows config ---
        ignore_cfg = mc.get("ignore_rows", {}) or {}
        ignore_last_n = int(ignore_cfg.get("last_n", 0))

        raw_keywords = ignore_cfg.get("keywords", []) or []
        resolved_keywords: List[Tuple[str, Optional[int]]] = []

        for item in raw_keywords:
            if isinstance(item, str):
                # Search across ALL columns
                kw = item.strip().lower()
                if kw:
                    resolved_keywords.append((kw, None))
                else:
                    self.log.warning("Empty keyword in ignore_rows.keywords is ignored.")
            elif isinstance(item, (list, tuple)) and len(item) == 2:
                kw = str(item[0]).strip().lower()
                col_idx: Optional[int] = None
                if kw:
                    try:
                        # Treat second element as 1-based column index; convert to 0-based
                        col_idx_1b = int(item[1])
                        if col_idx_1b >= 1:
                            col_idx = col_idx_1b - 1
                        else:
                            # 0 or negative → invalid → fall back to ALL columns
                            self.log.warning(
                                "ignore_rows.keywords entry has non-positive index %r; "
                                "falling back to all-column search for keyword '%s'.",
                                item[1], kw
                            )
                            col_idx = None
                    except Exception:
                        # Not an int → fall back to ALL columns
                        self.log.warning(
                            "ignore_rows.keywords entry index %r is not an integer; "
                            "falling back to all-column search for keyword '%s'.",
                            item[1], kw
                        )
                        col_idx = None
                    resolved_keywords.append((kw, col_idx))
                else:
                    self.log.warning("Empty keyword tuple in ignore_rows.keywords is ignored: %r", item)                   

        def _clean_str(val: Optional[str]) -> str:
            s = "" if val is None else str(val).strip()
            return "" if s == "" or s.lower() in {"nan", "none", "null"} else s

        total_rows = len(df)
        records: List[TransactionRecord] = []

        for ridx, row in enumerate(df.itertuples(index=False)):
            # --- Index-based skip of trailing rows (e.g., totals/footer) ---
            if ignore_last_n > 0 and ridx >= total_rows - ignore_last_n:
                continue

            # Materialize row texts for keyword search across columns
            try:
                row_texts = [(_clean_str(x)).lower() for x in list(row)]
            except Exception:
                row_texts = []

            # --- Keyword-based skip ---
            skip_by_keyword = False
            for kw, col_idx in resolved_keywords:
                if not kw:
                    continue
                if col_idx is None:
                    # Search keyword across ALL columns
                    if any(kw in cell for cell in row_texts):
                        skip_by_keyword = True
                        break
                else:
                    # Search keyword only in specified column (0-based)
                    if 0 <= col_idx < len(row_texts):
                        if kw in row_texts[col_idx]:
                            skip_by_keyword = True
                            break
                    else:
                        # Out-of-range: fallback to global search
                        if any(kw in cell for cell in row_texts):
                            skip_by_keyword = True
                            break
            if skip_by_keyword:
                continue

            # --- Extract raw values via precomputed indices ---
            toacct_raw = row[idx_toacct] if idx_toacct is not None else None
            amount_raw = row[idx_amount] if idx_amount is not None else None
            date_raw   = row[idx_date]   if idx_date   is not None else None

            # Normalize
            toacct     = _clean_str(toacct_raw)
            amount_str = _clean_str(amount_raw)
            date_val   = _clean_str(date_raw)
            date_out   = date_val or fixed_fields.get("date", "")

            # --- Amount must be numeric and non-zero ---
            if not amount_str:
                continue
            amt_parse = (
                amount_str.replace(",", "").replace(" ", "")
                .replace("(", "-").replace(")", "")
            )
            amt_parse = re.sub(r"[^\d.\-]", "", amt_parse)
            try:
                amount_val = float(amt_parse)
            except Exception:
                continue
            if amount_val == 0.0:
                continue

            # --- Require valid account mapping ---
            mapped: Optional[Tuple[str, str, str]] = None
            if toacct:
                try:
                    mapped = map_account_number(toacct, self.bank_codes_mapping)
                except Exception as e:
                    self.log.debug("Account map error for '%s': %s", toacct, e)
            if not mapped:
                continue

            code, bank_name, normalized_acc = mapped
            bank_code = code or ""
            bank_account_no_fmt = f"{code} {bank_name} {normalized_acc}".strip()

            records.append(TransactionRecord(
                agent=agent,
                payment_type="C",
                bank_code=bank_code,
                bank_account_no_fmt=bank_account_no_fmt,
                amount=amount_str,  # keep original textual amount; change to amt_parse if needed downstream
                date=normalize_date(date_out, options=options),
                source_kind="Excel",
                source_file=excel_source.relative_to(input_dir)
            ))

        self.log.info(
            "Schema '%s' produced %d records (from %s). Fixed fields=%s",
            schema.get("name"), len(records), schema_path, fixed_fields
        )
        return records
    
