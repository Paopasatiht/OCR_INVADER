
# mappers/base.py
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Protocol, Union, Tuple
import pandas as pd
from typing import Optional

# -----------------------------
# Options / Knobs
# -----------------------------
@dataclass(frozen=True)
class DateNormOptions:
    """
    Optional knobs to control date interpretation.

    prefer_buddhist_shorthand:
        - True  : always interpret 2-digit years as Buddhist shorthand (2500+yy -> -543)
        - False : always interpret 2-digit years as Gregorian (pivot-based)
        - None  : auto (context-aware + proximity to current year)
    pivot_offset:
        - Offset added to (current_year % 100) to build the 2-digit Gregorian pivot.
          Example: in 2025, current_year % 100 = 25 → pivot = 25 + 5 = 30
          yy <= pivot -> 2000+yy else 1900+yy
    buddhist_proximity_window:
        - If auto mode and Buddhist candidate (1957+yy) is within ±window years of
          current year, prefer Buddhist (captures '68' → 2025 in 2025).
    assume_day_first:
        - Controls fallback parsing when order is ambiguous (DD/MM vs MM/DD). Thailand
          uses DD/MM; set True for Thai docs.
    locale_hint:
        - 'th' or 'en' (or None). If 'th', we treat the text as Thai context even
          without explicit tokens like 'พ.ศ.'; helps for OCR streams known to be Thai.
    """
    prefer_buddhist_shorthand: Optional[bool] = None
    pivot_offset: int = 5
    buddhist_proximity_window: int = 2
    assume_day_first: bool = True
    locale_hint: Optional[str] = None


@dataclass(frozen=True)
class FINNETTransactionRecord:
    """
    FINNET-specific record that mirrors TransactionRecord, but
    prepends 'no' (the 'No.' column from the sheet).
    """
    no: str  # from sheet column 'No.'
    agent: str
    payment_type: str
    bank_code: str
    bank_account_no_fmt: str
    amount: str
    date: str
    source_kind: str
    source_file: str
    result_status: str


@dataclass(frozen=True)
class FINNETMapResult:
    """
    Container returned by FINNETExcelMapper.map(...)
    - records: filtered + mapped rows (SUCCESS)
    - success_transactions: synonym of records for explicitness
    - pending_transactions: rows with empty 'Result' (not 'Total Amount')
    """
    records: List[TransactionRecord]
    success_transactions: List[FINNETTransactionRecord]
    pending_transactions: List[FINNETTransactionRecord]


@dataclass(frozen=True)
class TransactionRecord:
    agent: str
    payment_type: str
    bank_code: str
    bank_account_no_fmt: str
    amount: str
    date: str
    source_kind: str
    source_file: str


class TransactionFormMapper(Protocol):
    """A mapper turns raw OCR/parsed inputs into normalized TransactionRecord(s)."""
    def map(self, extraction_results: Dict[str, Any]) -> Union[List[TransactionRecord], Tuple[List[TransactionRecord], List[Dict[str,Any]]]]:
        ...

def records_to_dataframe(records: Iterable[TransactionRecord]) -> pd.DataFrame:
    columns = ["Agent", "Payment Type", "BANK CODE", "Bank Account No", "AMOUNT", "Date", "Source kind", "Source file"]
    rows = [
        {
            "Agent": r.agent,
            "Payment Type": r.payment_type,
            "BANK CODE": r.bank_code,
            "Bank Account No": r.bank_account_no_fmt,
            "AMOUNT": r.amount,
            "Date": r.date,
            "Source kind": r.source_kind,
            "Source file": r.source_file
        }
        for r in records
    ]
    return pd.DataFrame(rows, columns=columns)
