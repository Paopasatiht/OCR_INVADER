# .\extraction_core.py
# -*- coding: utf-8 -*-
import os
import sys
import json
from typing import Dict, Any, Tuple
from pathlib import Path
from datetime import datetime
from dotenv import load_dotenv
import shutil
import configparser
import pandas as pd

from Functions.OCR.OCR import ocr_extraction_main
from Functions.Path_Handler import get_base_dir, ensure_dir_exists
from Functions.Mapping_to_Excel import build_all_dataframes_from_extractions, save_dataframe_outputs
from Functions.PreClassification import *



def extraction_core_main(
    today: int,
    cfg: configparser.ConfigParser,
    log: logging.Logger,
    CONFIG_PATH: str = "Config/config.cfg",
    rerun: bool = False,
    inputs_dir: Path | str | None = None,
    outputs_dir: Path | str | None = None,
    temp_dir: Path | str | None = None,
) -> Tuple[Dict[str, Any], Dict[str, pd.DataFrame]]:
    """
    Runs the OCR extraction and mapping pipeline.

    :param today: Date in integer format (e.g., 20251209).
    :param cfg: Loaded configuration object from configparser.
    :param log: Logger instance for logging pipeline steps.
    :param CONFIG_PATH: Path to the configuration file (default: 'Config/config.cfg').
    :return: A tuple containing:
        - extraction_results: Dict with OCR and mapping results.
        - dfs_by_kind: Dict mapping source kinds to their DataFrames.
    """

    # -------------------------------------------------------------------------
    # 0) Load environment variables
    # -------------------------------------------------------------------------
    load_dotenv()
    if rerun:
        log.info(f"This is a rerun for date: {today}.")

    # -------------------------------------------------------------------------
    # 1) Initialize base directory
    # -------------------------------------------------------------------------
    BASE_DIR = get_base_dir()
    try:
        os.chdir(BASE_DIR)
        print(f"Working directory set to: {Path.cwd()}")
    except Exception as e:
        print(f"[WARN] Could not change working dir to {BASE_DIR}: {e}", file=sys.stderr)
    

    # -------------------------------------------------------------------------
    # 2) Resolve Azure DI credentials
    # -------------------------------------------------------------------------
    di_endpoint = os.getenv("DI_ENDPOINT") or cfg.get("Azure_DI", "Endpoint", fallback=None)
    di_key = os.getenv("DI_KEY") or cfg.get("Azure_DI", "Key", fallback=None)

    if not di_endpoint or not di_key:
        log.error("Azure Document Intelligence endpoint/key not configured (env or config).")

    # -------------------------------------------------------------------------
    # 3) Load Model IDs
    # -------------------------------------------------------------------------
    model_json_rel = cfg.get("Local_Paths", "Model_IDs_JSON", fallback=None)
    if not model_json_rel:
        log.error("'Model_IDs_JSON' not configured under [Local_Paths]")

    model_json_path = Path(model_json_rel).resolve()
    if not model_json_path.exists():
        possible = Path(BASE_DIR) / model_json_rel
        if possible.exists():
            model_json_path = possible
        else:
            log.error("MODEL_IDs JSON missing: %s", model_json_path)

    MODEL_IDs: Dict[str, Any] = {}
    try:
        with open(model_json_path, "r", encoding="utf-8") as f:
            MODEL_IDs = json.load(f)
    except Exception as e:
        log.exception("Failed to load MODEL_IDs JSON from %s: %s", model_json_path, e)

    classifier_id = MODEL_IDs.get("Doc_Classifier")
    if not classifier_id:
        log.error("'Doc_Classifier' missing in MODEL_IDs JSON. Cannot classify.")

    log.info("DI endpoint: %s", di_endpoint)
    log.info("Cache inputs dir: %s", inputs_dir)
    log.info("Model IDs JSON: %s", model_json_path)
    log.info("Classifier ID: %s", classifier_id)

    # -------------------------------------------------------------------------
    # 4) Rule-based pre-classify files before OCR
    # -------------------------------------------------------------------------
    # inputs_dir comes from set_cache_paths(...)
    
    try:
        pre = pre_classify_inputs(inputs_root=inputs_dir, log=log, finnet_folder_name="FINNET")
    except Exception:
        log.exception("Pre-classification failed.")
        pre = {"azure": [], "excel": [], "finnet": []}

    # =========================================================================
    # STEP 4.1: COLLECT SKIPPED FILES
    # =========================================================================
    # รวบรวมไฟล์ที่ถูก skip (zip, unsupported types)
    skipped_files = []

    # ถ้า PreClassification return skipped files
    if "skipped" in pre:
        skipped_files.extend(pre["skipped"])

    # หรือ scan หาไฟล์ที่ไม่ได้อยู่ใน azure/excel/finnet
    try:
        all_input_files = set()
        for p in Path(inputs_dir).rglob("*"):
            if p.is_file():
                all_input_files.add(str(p))

        classified_files = set()
        for category in ["azure", "excel", "finnet"]:
            for f in pre.get(category, []):
                classified_files.add(str(f))

        # ไฟล์ที่ไม่ได้ถูก classify = skipped
        unclassified = all_input_files - classified_files
        for fp in unclassified:
            ext = Path(fp).suffix.lower()
            if ext in (".zip", ".rar", ".7z"):
                reason = "please extract and add to excel file"
            elif ext in (".doc", ".docx", ".txt", ".ppt", ".pptx"):
                reason = "unsupported file type"
            else:
                reason = "not recognized by pre-classification"

            skipped_files.append({
                "file_path": fp,
                "reason": reason
            })
            log.info("Skipped file: %s (%s)", fp, reason)

    except Exception as e:
        log.warning("Could not collect skipped files: %s", e)


    # Create a filtered DI inbox and route only Azure-eligible files there
    current_date = f"{today[:4]}-{today[4:6]}-{today[6:]}"
    di_inbox_dir = temp_dir / f"di_inbox_{current_date}"
    try:
        di_inbox_dir = materialize_di_inbox(
            candidates=pre["azure"],
            inbox_root=di_inbox_dir,
            inputs_root=inputs_dir,
            log=log
        )
    except Exception:
        log.exception("Failed to create DI inbox.")
        di_inbox_dir = temp_dir / "di_inbox_failed"
        ensure_dir_exists(di_inbox_dir)


    # -------------------------------------------------------------------------
    # 5) Run OCR extraction pipeline, but on the DI inbox
    # -------------------------------------------------------------------------
    Doc_Classification_Confidence_Threshold = cfg.getfloat("Azure_DI_settings", "Doc_Classification_Confidence_Threshold", fallback=0.6)
    connection_timeout = cfg.getfloat("Azure_DI_settings", "connection_timeout", fallback=300)
    read_timeout = cfg.getfloat("Azure_DI_settings", "read_timeout", fallback=300)
    timeout = (connection_timeout,read_timeout)
    max_retries = cfg.getint("Azure_DI_settings", "max_reties", fallback=2)
    log.info("Connection timeout =%f, Read timeout =%f, Max retries =%d, Doc classification confidence threshold =%f)", connection_timeout, read_timeout, max_retries, Doc_Classification_Confidence_Threshold)

    

    extraction_results: Dict[str, Any] = {
        "status": "running",
        "extraction_results": {},
        "successful_OCR_extraction_files": [],
        "skipped_files": [],
    }
    
    if not di_endpoint or not di_key:
        extraction_results["status"] = "config_error"
        extraction_results["error"] = "Missing DI credentials"
    else:
        if not MODEL_IDs or not classifier_id:
            extraction_results["status"] = "config_error"
            extraction_results["error"] = "Missing MODEL_IDs or Doc_Classifier"
            log.error("Skipping OCR due to missing model configuration.")
        else:
            try:
                POOL_SIZE = cfg.getint("Network", "POOL_SIZE", fallback=32)
                extraction_results = ocr_extraction_main(
                    logger=log,
                    di_endpoint=di_endpoint,
                    di_key=di_key,
                    classifier_id=classifier_id,
                    model_ids=MODEL_IDs,
                    cache_inputs_dir=di_inbox_dir,   # <-- use filtered inbox, not the raw inputs_dir
                    POOL_SIZE=POOL_SIZE,
                    timeout=timeout,
                    adapter_retry_total=max_retries,
                    Doc_Classification_Confidence_Threshold = Doc_Classification_Confidence_Threshold
                )
                extraction_results["status"] = "ocr_success"
                log.info("OCR extraction completed successfully.")
            except Exception as e:
                extraction_results["status"] = "ocr_failed"
                log.exception("Unhandled exception in extraction_core: %s", e)

    # -------------------------------------------------------------------------
    # 6) Add Excel paths (non-FINNET) to extraction_results payload
    # -------------------------------------------------------------------------
    try:
        excel_files = pre["excel"]  # From pre_classify_inputs()
        if excel_files:
            log.info("Found %d Excel-readable files (non-FINNET).", len(excel_files))
            for fp in excel_files[:10]:
                log.info("  - %s", fp)

            if "extraction_results" not in extraction_results:
                extraction_results["extraction_results"] = {}

            # Inject Excel payload (list of paths as strings)
            extraction_results["extraction_results"]["Excel"] = [str(p) for p in excel_files]
        else:
            log.warning("No Excel-readable files found under inputs: %s", inputs_dir)

    except Exception as e:
        log.exception("Failed to add NON-FINNET Excel paths to extraction_results: %s", e)

    # -------------------------------------------------------------------------
    # 7) Add FINNET Excel paths to extraction_results payload
    # -------------------------------------------------------------------------
    try:
        finnet_excels = pre.get("finnet", [])

        if finnet_excels:
            log.info("Found %d FINNET Excel files.", len(finnet_excels))
            for fp in finnet_excels[:10]:
                log.info("  - %s", fp)

            # Ensure nested structure exists
            if "extraction_results" not in extraction_results:
                extraction_results["extraction_results"] = {}

            # Inject FINNET payload (list of paths as strings)
            extraction_results["extraction_results"]["FINNET"] = [str(p) for p in finnet_excels]
        else:
            log.warning("No FINNET Excel files found in pre-classification.")
    except Exception as e:
        log.exception("Failed to add FINNET Excel paths to extraction_results: %s", e)


    # -------------------------------------------------------------------------
    # 8) Build mapping DataFrame(s) and save outputs
    # -------------------------------------------------------------------------
    
    dfs_by_kind: Dict[str, pd.DataFrame] = {}
    failed_files_during_mapping: list[str] = []

    try:
        # If you already adopted the multi-kind build, use it here.
        # Otherwise, keep single-kind call but update source_kind per bucket.

        # --- Multi-kind (recommended) ---
        dfs_by_kind, failed_files_during_mapping = build_all_dataframes_from_extractions(
            extraction_results=extraction_results.get("extraction_results", {}),
            config_path=CONFIG_PATH,
            log=log,
            inputs_dir=inputs_dir,
            outputs_dir=outputs_dir,
            today=today
        )

        # Add list of files that failed during mapping specifically
        extraction_results["failed_mapping_files"] = failed_files_during_mapping

        if not dfs_by_kind:
            log.error("No DataFrames were built; nothing to save.")

        if failed_files_during_mapping:
            log.warning("Some files failed during mapping:")
            for f in failed_files_during_mapping:
                log.warning(" - %s", f)
            print("\nFailed files during mapping:")
            for f in failed_files_during_mapping:
                print(" -", f)

        # Combined output for single, multiple, and excel
        if dfs_by_kind:
            try:
                combined = pd.concat(dfs_by_kind.values(), ignore_index=True)
                save_dataframe_outputs(combined, outputs_dir, f"payin_mapping_all_{current_date}", log)
                log.info("Combined mapping saved (rows=%d)", len(combined))
            except Exception:
                log.exception("Failed to build/save combined outputs")
        else:
            log.warning("No DataFrames were built; skipping combined output.")

    except Exception as e:
        log.exception("Failed to build/save mapping DataFrame(s): %s", e)
    
    # -------------------------------------------------------------------------
    # 9) Track files that mapped successfully (success with no exception at 11)
    # -------------------------------------------------------------------------
    try:
        # Helper: collect per-kind success using the 'source_file' column from each DF
        def _collect_successful_mapping_files(dfs_by_kind_local: Dict[str, pd.DataFrame]) -> Dict[str, List[str]]:
            per_kind: Dict[str, List[str]] = {}
            for kind, df_k in dfs_by_kind_local.items():
                if isinstance(df_k, pd.DataFrame) and not df_k.empty and "Source file" in df_k.columns:
                    files = (
                        df_k["Source file"]
                        .dropna()
                        .astype(str)
                        .unique()
                        .tolist()
                    )
                    # Normalize path strings to POSIX-like for consistency
                    per_kind[kind.lower()] = sorted(files)
                else:
                    per_kind[kind.lower()] = []
            return per_kind

        successful_mapping_files_by_kind = _collect_successful_mapping_files(dfs_by_kind)
        successful_mapping_files_by_kind = successful_mapping_files_by_kind if dfs_by_kind else {}

        # Flatten as a single list (de-duplicated)
        successful_mapping_files = sorted({
            f for files in successful_mapping_files_by_kind.values() for f in files
        })

        # Build DI success intersection: OCR success ∩ mapped success (only for DI kinds)
        di_success_paths = {
            it.get("file_path")
            for it in extraction_results.get("successful_OCR_extraction_files", [])
            if it.get("file_path")
        }

        # DI kinds in dfs_by_kind should be lower-case keys: 'single', 'multiple', 'slip'
        mapped_di_paths = set(successful_mapping_files_by_kind.get("single", [])) \
                        | set(successful_mapping_files_by_kind.get("multiple", [])) \
                        | set(successful_mapping_files_by_kind.get("slip", []))

        overall_di_success = sorted(di_success_paths & mapped_di_paths)

        # Non-DI kinds just rely on mapping success
        overall_excel_success  = successful_mapping_files_by_kind.get("excel", [])
        overall_finnet_success = successful_mapping_files_by_kind.get("finnet", [])

        overall_success_files = sorted(set(overall_di_success) | set(overall_excel_success) | set(overall_finnet_success))

        # Persist in the enriched payload
        extraction_results["successful_mapping_files_by_kind"] = successful_mapping_files_by_kind
        extraction_results["successful_mapping_files"] = successful_mapping_files
        extraction_results["overall_success_files"] = overall_success_files
        # เพิ่ม skipped files
        extraction_results["skipped_files"] = skipped_files
        log.info("Skipped files: %d total", len(skipped_files))

        log.info("Tracked successful mapping files: %d total", len(successful_mapping_files))
        log.info("Overall success files (DI mapped + Excel/FINNET mapped): %d", len(overall_success_files))

    except Exception as e:
        log.exception("Failed to save list of successfully mapped files: %s", e)

 
    # -------------------------------------------------------------------------
    # 10) Cleanup staged DI inbox files
    # -------------------------------------------------------------------------
    try:
        if di_inbox_dir.exists():
            shutil.rmtree(di_inbox_dir, ignore_errors=True)
            log.info("Removed DI inbox directory and all contents: %s", di_inbox_dir)
        else:
            log.info("DI inbox directory does not exist; nothing to clean.")
        
        if extraction_results.get("status") in (None, "running"):
            # Infer a final status
            final_status = "success" if dfs_by_kind else "partial_success" if extraction_results.get("extraction_results") else "failed"
            extraction_results["status"] = final_status


    except Exception as e:
        log.exception("Failed to clear staged Azure DI files: %s", e)

    return extraction_results, dfs_by_kind
