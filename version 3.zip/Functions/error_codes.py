# Functions/error_codes.py
# -*- coding: utf-8 -*-
"""
Error Codes สำหรับระบบ OCR
แบ่งเป็น 5 หมวด: INPUT, CLASS, EXTRACT, MAP, UNKNOWN
"""

from typing import Dict, Tuple

# =============================================================================
# Error Code Definitions
# Format: ERROR_CODE -> (short_description, full_description_thai)
# =============================================================================

ERROR_CODES: Dict[str, Tuple[str, str]] = {
    # -------------------------------------------------------------------------
    # INPUT - ปัญหาอ่านไฟล์ไม่ได้
    # -------------------------------------------------------------------------
    "INPUT_001": ("PDF Encrypted", "PDF เข้ารหัส กรุณาใส่ password แล้ว scan ใหม่"),
    "INPUT_002": ("PDF Corrupted", "ไฟล์ PDF เสีย กรุณา scan ใหม่"),
    "INPUT_003": ("Image Read Error", "อ่านไฟล์รูปไม่ได้ กรุณาตรวจสอบไฟล์"),
    "INPUT_004": ("Empty File", "ไฟล์ว่างเปล่า (0 bytes)"),
    "INPUT_005": ("Unsupported Extension", "นามสกุลไฟล์ไม่รองรับ"),
    "INPUT_006": ("Invalid Path", "path ไฟล์มีปัญหา"),
    "INPUT_007": ("File Too Large", "ไฟล์ใหญ่เกิน limit"),

    # -------------------------------------------------------------------------
    # CLASS - Azure แยกประเภทไม่ได้
    # -------------------------------------------------------------------------
    "CLASS_001": ("Low Confidence", "ไม่สามารถระบุประเภทเอกสาร (Confidence ต่ำ)"),
    "CLASS_002": ("Unused Type", "ประเภทเอกสาร 'Unused' ไม่รองรับ"),
    "CLASS_003": ("Classification Timeout", "Classification timeout กรุณาลองใหม่"),
    "CLASS_004": ("Classification API Error", "Classification API error"),

    # -------------------------------------------------------------------------
    # EXTRACT - Azure ดึงข้อมูลไม่ได้
    # -------------------------------------------------------------------------
    "EXTRACT_001": ("No Model Found", "ไม่พบ model สำหรับประเภทนี้"),
    "EXTRACT_002": ("Missing Required Fields", "ไม่พบข้อมูลที่จำเป็น (เลขบัญชี/จำนวนเงิน/วันที่)"),
    "EXTRACT_003": ("Extraction Timeout", "Extraction timeout กรุณาลองใหม่"),
    "EXTRACT_004": ("Extraction API Error", "Extraction API error"),
    "EXTRACT_005": ("Table Extraction Failed", "อ่านตาราง transaction ไม่ได้"),
    "EXTRACT_006": ("Date Parse Error", "อ่านวันที่ไม่ได้"),
    "EXTRACT_007": ("Amount Parse Error", "อ่านจำนวนเงินไม่ได้"),

    # -------------------------------------------------------------------------
    # MAP - Map ข้อมูลไม่ได้
    # -------------------------------------------------------------------------
    "MAP_001": ("Account Not Found", "ไม่พบบัญชีใน Bank_Codes.json"),
    "MAP_002": ("Agent Not Found", "ไม่พบ Agent ใน Agent_Names.json"),
    "MAP_003": ("Schema Not Found", "ไม่พบ schema สำหรับธนาคารนี้"),
    "MAP_004": ("Column Mismatch", "Column ใน schema ไม่ตรงกับเอกสาร"),
    "MAP_005": ("Date Conversion Error", "แปลงวันที่ผิดพลาด (พ.ศ./ค.ศ.)"),
    "MAP_006": ("Amount Conversion Error", "แปลงจำนวนเงินผิดพลาด"),
    "MAP_007": ("Required Field Null", "Required field เป็นค่าว่าง"),
    "MAP_008": ("Excel Format Error", "Excel format ผิด"),
    "MAP_009": ("FINNET Format Error", "FINNET format ไม่ตรง"),

    # -------------------------------------------------------------------------
    # UNKNOWN - ประเภทไม่รู้จัก/ถูก Skip
    # -------------------------------------------------------------------------
    "UNKNOWN_001": ("Unused Document Type", "ประเภทเอกสาร 'Unused' ไม่รองรับ"),
    "UNKNOWN_002": ("No Extraction Model", "ไม่มี extraction model สำหรับประเภทนี้"),
    "UNKNOWN_003": ("Unsupported File Type", "ไฟล์ไม่รองรับ กรุณาแตกไฟล์แล้วใส่ Excel"),
}


def get_error_message(error_code: str, detail: str = "") -> str:
    """
    สร้างข้อความ error แบบรวม code + description

    Args:
        error_code: รหัส error เช่น "INPUT_001"
        detail: รายละเอียดเพิ่มเติม (optional)

    Returns:
        str: ข้อความรวม เช่น "INPUT_001: PDF เข้ารหัส กรุณาใส่ password แล้ว scan ใหม่"

    Example:
        >>> get_error_message("INPUT_001")
        "INPUT_001: PDF เข้ารหัส กรุณาใส่ password แล้ว scan ใหม่"

        >>> get_error_message("CLASS_001", "Confidence 0.45")
        "CLASS_001: ไม่สามารถระบุประเภทเอกสาร (Confidence 0.45)"
    """
    if error_code not in ERROR_CODES:
        return f"{error_code}: {detail}" if detail else error_code

    _, thai_desc = ERROR_CODES[error_code]

    # ถ้ามี detail และ description มี placeholder
    if detail:
        # สำหรับ CLASS_001 ใส่ confidence
        if error_code == "CLASS_001" and "Confidence" not in detail:
            return f"{error_code}: ไม่สามารถระบุประเภทเอกสาร (Confidence {detail})"
        # สำหรับ error อื่นๆ ที่มี detail
        return f"{error_code}: {thai_desc} ({detail})"

    return f"{error_code}: {thai_desc}"


def get_error_code_from_category(category: str, item: dict) -> str:
    """
    แปลง category เดิมเป็น error code ใหม่

    Args:
        category: หมวดหมู่เดิม เช่น "encrypted_pdf", "classification_failed"
        item: dict ข้อมูลของไฟล์ (อาจมี error_reason, confidence, etc.)

    Returns:
        str: error code เช่น "INPUT_001"
    """
    # Mapping จาก category เดิมเป็น error code
    category_mapping = {
        # Encrypted PDF
        "encrypted_pdf": "INPUT_001",
        "encrypted": "INPUT_001",

        # Classification failures
        "classification_failed": "CLASS_001",
        "classify_failed": "CLASS_001",
        "low_confidence": "CLASS_001",

        # Extraction failures
        "extraction_failed": "EXTRACT_001",
        "extract_failed": "EXTRACT_001",
        "missing_fields": "EXTRACT_002",

        # Mapping failures
        "mapping_failed": "MAP_001",
        "account_not_found": "MAP_001",
        "schema_not_found": "MAP_003",

        # Unknown/Unused
        "unknown": "UNKNOWN_001",
        "unused": "UNKNOWN_001",
        "unsupported": "UNKNOWN_003",
        "skipped": "UNKNOWN_003",
    }

    # ตรวจสอบ error_reason ใน item
    error_reason = ""
    if isinstance(item, dict):
        error_reason = str(item.get("error_reason", "") or item.get("error", "")).lower()

    # ตรวจสอบ specific errors จาก error_reason
    if "encrypt" in error_reason or "password" in error_reason:
        return "INPUT_001"
    if "corrupt" in error_reason or "damaged" in error_reason:
        return "INPUT_002"
    if "empty" in error_reason or "0 bytes" in error_reason:
        return "INPUT_004"
    if "confidence" in error_reason:
        return "CLASS_001"
    if "unused" in error_reason:
        return "CLASS_002"
    if "timeout" in error_reason:
        if "classif" in error_reason:
            return "CLASS_003"
        if "extract" in error_reason:
            return "EXTRACT_003"
    if "account" in error_reason and "not found" in error_reason:
        return "MAP_001"
    if "schema" in error_reason:
        return "MAP_003"

    # Default mapping by category
    category_lower = category.lower().replace(" ", "_")
    return category_mapping.get(category_lower, "UNKNOWN_001")


def format_error_for_summary(category: str, item: dict) -> str:
    """
    สร้างข้อความ error สำหรับใส่ใน Summary Excel

    Args:
        category: หมวดหมู่ เช่น "encrypted_pdf", "classification_failed"
        item: dict ข้อมูลของไฟล์

    Returns:
        str: ข้อความ error เช่น "INPUT_001: PDF เข้ารหัส กรุณาใส่ password แล้ว scan ใหม่"
    """
    error_code = get_error_code_from_category(category, item)

    # ดึง detail จาก item
    detail = ""
    if isinstance(item, dict):
        if item.get("confidence"):
            detail = f"{item['confidence']:.2f}"
        elif item.get("error_reason"):
            # ตัดให้สั้นถ้ายาวเกิน
            detail = str(item["error_reason"])[:50]
        elif item.get("error"):
            detail = str(item["error"])[:50]

    return get_error_message(error_code, detail)
