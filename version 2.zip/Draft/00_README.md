# Draft: ออกแบบระบบ Error และ Summary ใหม่

## สถานะ: IMPLEMENTED

**เฉพาะ Error ระดับไฟล์** - การอ่านไฟล์/ประมวลผลไฟล์/แสดง Summary
(ไม่รวม System Error เช่น SharePoint, Azure, Network, SMTP)

---

## ไฟล์ที่แก้ไข

| ไฟล์ | การเปลี่ยนแปลง |
|------|---------------|
| `Functions/error_codes.py` | **NEW** - Error Codes 31 codes |
| `Functions/email/smtp_handler.py` | อัพเดท `_build_flat_summary_excel` และ `_build_smart_reconcile_email_body` |

---

## เอกสาร

| ไฟล์ | เนื้อหา |
|------|---------|
| `01_File_Error_Categories.md` | หมวด Error ทั้งหมด 31 codes |
| `02_What_If_Cases.md` | สถานการณ์สมมติ และคำถามที่ต้องตัดสินใจ |

---

## สรุปย่อ

### Status: แค่ 2 ค่า
- `success` = ไฟล์สำเร็จ
- `fail` = ไฟล์มี error

### หมวด Error: 5 หมวด

| หมวด | จำนวน | ตัวอย่าง |
|------|-------|----------|
| INPUT | 7 codes | PDF เข้ารหัส, ไฟล์ว่าง, ไฟล์ไม่รองรับ |
| CLASS | 4 codes | Confidence ต่ำ, ประเภท Unused |
| EXTRACT | 7 codes | field หาย, อ่านตารางไม่ได้ |
| MAP | 9 codes | ไม่พบบัญชี, ไม่พบ Agent |
| UNKNOWN | 4 codes | ไฟล์ zip, ประเภทไม่รองรับ |

### กรณีที่ยังไม่ได้ Log: 10 กรณี
1. ไฟล์ว่าง (0 bytes)
2. ไฟล์ใหญ่เกิน limit
3. อ่านวันที่ไม่ได้
4. อ่านจำนวนเงินไม่ได้
5. ไม่พบบัญชี (warning แต่ไม่อยู่ summary)
6. ไม่พบ Agent (ใช้ Unknown แทน)
7. แปลงวันที่ผิด
8. แปลงจำนวนเงินผิด
9. Required field null
10. path มีปัญหา

---

## คำถามที่ต้องตัดสินใจ

| # | กรณี | ตัวเลือก |
|---|------|----------|
| 1 | ไฟล์ zip/doc | `fail` หรือ ไม่นับเลย? |
| 2 | ไม่พบ Agent | `fail` หรือ `success` + "Unknown"? |
| 3 | ไม่พบบัญชี | `fail` หรือ `success`? |
| 4 | วันที่/เงิน parse ไม่ได้ | `fail` หรือ `success` + ค่าว่าง? |
