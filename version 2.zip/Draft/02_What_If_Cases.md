# What If Cases - สถานการณ์สมมติ

## สถานะ: IMPLEMENTED

---

## 1. Agent ใหม่ที่ไม่มีใน config (ตัดสินใจแล้ว)

**สถานการณ์:** มี folder ใน SharePoint ชื่อ `NEWAGENT` แต่ไม่มีใน `Agent_Names.json`

**การตัดสินใจ:**
- Status = `สำเร็จ` (ถ้าไฟล์ process ได้)
- Agent column = แสดงชื่อ folder + ระบุว่าไม่มีใน config
- ตัวอย่าง: `NEWAGENT (ไม่มีใน config)`

---

## 2. Confidence ต่ำกว่า threshold (ตัดสินใจแล้ว)

**สถานการณ์:** Azure อ่านไฟล์แล้ว classify ได้ confidence 0.45 (threshold = 0.60)

**การตัดสินใจ:**
- Status = `ผิดพลาด`
- Error = `CLASS_001: ไม่สามารถระบุประเภทเอกสาร (Confidence 0.45)`
- Doc Type = **ว่าง** (เพราะไม่รู้ประเภท)

---

## 3. เมื่อไหร่ค่าจะว่างใน Summary?

| Column | ว่างเมื่อ | หมายเหตุ |
|--------|----------|----------|
| **Agent** | ไม่มีทางว่าง | ดึงจาก folder path เสมอ (ถ้าไม่มีใน config ก็แสดงชื่อ folder) |
| **File** | ไม่มีทางว่าง | - |
| **File Path** | ไม่มีทางว่าง | - |
| **Status** | ไม่มีทางว่าง | - |
| **Error** | status = สำเร็จ | ว่างปกติ |
| **Doc Type** | classification fail หรือ input error | CLASS_xxx, INPUT_xxx |

**หมายเหตุ:** Path มีปัญหา parse ไม่ได้ (INPUT_006) ไม่ต้องกังวล เพราะ user มี file path structure ที่ถูกต้องแล้ว
