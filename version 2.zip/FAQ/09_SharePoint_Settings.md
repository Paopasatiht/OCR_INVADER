# วิธี Config SharePoint Settings

## คำถาม 1
> จะปิด SharePoint integration (ใช้ local files แทน) ต้องทำอย่างไร?

## ตอบ

### File Location
```
Config/config.cfg → [SharePoint_API_setting]
```

### ปิด SharePoint
```ini
[SharePoint_API_setting]
Enable_SharePoint_API = false
```

### ผลที่ได้
- ไม่ download files จาก SharePoint
- ไม่ upload results ไป SharePoint
- ใช้ files ใน local `Cache/Inputs/` แทน
- Output จะอยู่ใน local `Cache/Outputs/`

### วิธีใช้งาน Local Mode

1. ปิด SharePoint:
```ini
Enable_SharePoint_API = false
```

2. ใส่ files ที่ต้องการ process ใน:
```
Cache/Inputs/
├── KSEC/
│   └── document1.pdf
└── KSAMF/
    └── document2.pdf
```

3. รัน script:
```bash
python main_rerun.py
# Input: 20260125
```

4. ดู output ที่:
```
Cache/Outputs/
```

---

## คำถาม 2
> จะเปลี่ยน folder บน SharePoint ที่ใช้ upload/download ต้องแก้ที่ไหน?

## ตอบ

### File Location
```
Config/config.cfg → [SharePoint_Paths]
```

### Settings
```ini
[SharePoint_Paths]
siteURL = /sites/KasikornAsset/FR
driveName = Documents
base_root = Provident Fund/OCR - Rekey Percent Unvest
Remote_Input = /Inputs
Remote_Output = /Outputs
```

### Path Structure
```
SharePoint Site: /sites/KasikornAsset/FR
    └── Documents (drive)
        └── Provident Fund/OCR - Rekey Percent Unvest (base_root)
            ├── /Inputs/20260125/    ← Remote_Input + date
            │   └── (files to process)
            └── /Outputs/20260125/   ← Remote_Output + date
                └── (result files)
```

### ตัวอย่างการเปลี่ยน Path

**เปลี่ยน base folder:**
```ini
base_root = NewProject/OCR-Files
```

**เปลี่ยน input/output folders:**
```ini
Remote_Input = /RawDocuments
Remote_Output = /ProcessedResults
```

---

## คำถาม 3
> SharePoint error แต่อยากให้ระบบทำงานต่อ ต้อง config อย่างไร?

## ตอบ

### File Location
```
Config/config.cfg → [SharePoint_API_setting]
```

### Setting
```ini
[SharePoint_API_setting]
Ignore_SharePoint_Error = true
```

### ผลที่ได้

| Ignore_SharePoint_Error | SharePoint Error | ผลลัพธ์ |
|-------------------------|------------------|---------|
| false (default) | Download fail | หยุดทำงาน, ส่ง email แจ้ง error |
| true | Download fail | ทำงานต่อด้วย local files |
| false | Upload fail | ส่ง email แจ้ง SharePoint fail |
| true | Upload fail | ส่ง email ปกติ (ignore error) |

### Use Cases

**Production (แนะนำ):**
```ini
Ignore_SharePoint_Error = false
```
- ถ้า SharePoint fail = ต้องรู้ทันที

**Development/Testing:**
```ini
Ignore_SharePoint_Error = true
```
- ไม่สนใจ SharePoint error ระหว่าง dev

---

## SharePoint API Settings อื่นๆ

```ini
[SharePoint_API_setting]
Enable_SharePoint_API = true
Ignore_SharePoint_Error = false
sharepoint_api_timeout_get = 30      # timeout สำหรับ GET requests (วินาที)
sharepoint_api_timeout_post = 60     # timeout สำหรับ POST requests (วินาที)
sharepoint_api_retry_total = 3       # จำนวน retry
sharepoint_api_backoff_factor = 0.5  # exponential backoff factor
```

### Retry Behavior
```
Attempt 1: immediate
Attempt 2: wait 0.5s
Attempt 3: wait 1.0s
Attempt 4: wait 2.0s
...
```
