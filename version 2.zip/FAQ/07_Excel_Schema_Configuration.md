# วิธี Config Excel Schema

## คำถาม 1
> Multiple form ของธนาคารใหม่มี column names ต่างจากที่มีอยู่ ต้องทำอย่างไร?

## ตอบ

### File Location
```
Config/mapping_config/multiple_OCR/<Bank Multiple>/
```

### สร้าง Schema File

1. สร้าง folder:
```
Config/mapping_config/multiple_OCR/TTB Multiple/
```

2. สร้างไฟล์ `Transaction Table Type 1.json`:
```json
{
  "schemas": [
    {
        "name": "TTB Transaction Table Type 1",
        "table_name": "Transaction Table Type 1",
        "mapping_config": {
            "cells": {},
            "columns": {
                "date": "<column name สำหรับวันที่>",
                "to_account": "<column name สำหรับเลขบัญชี>",
                "amount": "<column name สำหรับจำนวนเงิน>"
            }
        }
    }
  ]
}
```

### ตัวอย่างจริงจากระบบ

**KBank Multiple:**
```json
"columns": {
    "date": "วันที่ทำ รายการ",
    "to_account": "บัญชีผู้รับเงิน",
    "amount": "จำนวนเงิน"
}
```

**SCB Multiple:**
```json
"columns": {
    "date": "settle date",
    "to_account": "Account CR.",
    "amount": "Net Amount ( THB )"
}
```

**BBL Multiple:**
```json
"columns": {
    "to_account": "Bene. A/C No/ PromptPay ID",
    "amount": "Amount"
},
"cells": {
    "date": "Date"  // Date อยู่นอก table
}
```

**KTB Multiple:**
```json
"cells": {
    "date": "Date"
},
"columns": {
    "to_account": "Account No",
    "amount": "Tr. Amt"
}
```

**KKP Multiple:**
```json
"cells": {
    "date": "Date"
},
"columns": {
    "to_account": "เลขที่บัญชี/พร้อมเพย์",
    "amount": "จำนวนเงินเข้าบัญชีปลายทาง"
}
```

**BAY Multiple:**
```json
"cells": {
    "date": "Date"
},
"columns": {
    "to_account": "Benef. Account, PromptPay",
    "amount": "Amount"
}
```

**GSB Multiple (พร้อม row_filter):**
```json
"cells": {
    "to_account": "Account No"
},
"columns": {
    "date": "Date",
    "amount": "Credits"
},
"row_filter": {
    "enabled": true,
    "column": "Description",
    "match_type": "contains",
    "keywords": ["DDA Deposit by Cash"],
    "case_sensitive": false
},
"other_settings": {
    "prefer_buddhist_shorthand": true,
    "locale_hint": "th"
}
```

---

## คำถาม 2
> Multiple form มีหลาย table types ต้อง config อย่างไร?

## ตอบ

### สร้างหลาย Schema Files

```
Config/mapping_config/multiple_OCR/KBank Multiple/
├── Transaction Table Type 1.json
└── Transaction Table Type 2.json
```

### ระบบ Auto-Detect อย่างไร

1. Azure DI จะ extract table พร้อม `table_name`
2. ระบบจะหา schema file ที่มี `table_name` ตรงกัน
3. ใช้ schema นั้นในการ map columns

### ตัวอย่าง

**Type 1** - มี column "วันที่ทำ รายการ":
```json
{
  "schemas": [{
    "table_name": "Transaction Table Type 1",
    "mapping_config": {
      "columns": {
        "date": "วันที่ทำ รายการ",
        "to_account": "บัญชีผู้รับเงิน",
        "amount": "จำนวนเงิน"
      }
    }
  }]
}
```

**Type 2** - มี column "Transaction Date":
```json
{
  "schemas": [{
    "table_name": "Transaction Table Type 2",
    "mapping_config": {
      "columns": {
        "date": "Transaction Date",
        "to_account": "Beneficiary Account",
        "amount": "Amount"
      }
    }
  }]
}
```

---

## คำถาม 3
> มี Excel file รูปแบบใหม่ที่ไม่ใช่ FINNET ต้อง config อย่างไร?

## ตอบ

### File Location
```
Config/mapping_config/other_excels/<Bank>/
```

### สร้าง Schema File

```json
{
  "schemas": [
    {
        "name": "KBank-unitlink",
        "header_row_index": 1,
        "columns": [
            "column_1_name",
            "column_2_name",
            "..."
        ],
        "mapping_config": {
            "cells": {
                "date": "B1"
            },
            "columns": {
                "to_account": "credit",
                "amount": "จำนวนเงิน"
            },
            "ignore_rows": {
                "last_n": 1,
                "keywords": [["ยอดรวม", 1]]
            }
        }
    }
  ]
}
```

### Schema Fields อธิบาย

| Field | คำอธิบาย |
|-------|---------|
| `header_row_index` | บรรทัดที่เป็น header (0-based) |
| `columns` | รายชื่อ column headers ทั้งหมด (ใช้ match Excel) |
| `cells.date` | A1 notation สำหรับ cell ที่เก็บวันที่ |
| `columns.to_account` | ชื่อ column สำหรับเลขบัญชี |
| `columns.amount` | ชื่อ column สำหรับจำนวนเงิน |
| `ignore_rows.last_n` | ข้าม N บรรทัดสุดท้าย |
| `ignore_rows.keywords` | ข้าม row ที่มี keyword |

---

## คำถาม 4
> Excel มี header row อยู่บรรทัดอื่น (ไม่ใช่บรรทัดแรก) ต้อง config อย่างไร?

## ตอบ

### ใช้ `header_row_index`

```json
{
  "schemas": [{
    "header_row_index": 2,  // Header อยู่บรรทัดที่ 3 (0-based index)
    "columns": ["col1", "col2", "col3"],
    ...
  }]
}
```

### ตัวอย่าง Excel
```
Row 0: (blank or title)
Row 1: (blank or subtitle)
Row 2: Column1 | Column2 | Column3   ← header_row_index = 2
Row 3: data    | data    | data
```

---

## คำถาม 5
> Excel มี row ที่ต้อง ignore (เช่น ยอดรวม) ต้อง config อย่างไร?

## ตอบ

### ใช้ `ignore_rows`

```json
{
  "mapping_config": {
    "ignore_rows": {
      "last_n": 1,
      "keywords": [
        ["ยอดรวม", 1],
        ["Total", 0]
      ]
    }
  }
}
```

### Options

| Option | คำอธิบาย |
|--------|---------|
| `last_n` | ข้าม N บรรทัดสุดท้าย |
| `keywords` | `[["keyword", column_index], ...]` |

### ตัวอย่าง Keywords
```json
"keywords": [
  ["ยอดรวม", 1],    // ข้าม row ที่ column 1 มีคำว่า "ยอดรวม"
  ["Total", 0],     // ข้าม row ที่ column 0 มีคำว่า "Total"
  ["---", 2]        // ข้าม row ที่ column 2 มี "---"
]
```

---

## คำถาม 6 (ใหม่)
> Table มี rows ที่ต้อง filter เอาเฉพาะบาง rows ต้อง config อย่างไร?

## ตอบ

### ใช้ `row_filter`

ใช้สำหรับ **เลือกเฉพาะ rows ที่ต้องการ** (ต่างจาก ignore_rows ที่ข้าม rows)

```json
{
  "mapping_config": {
    "row_filter": {
      "enabled": true,
      "column": "Description",
      "match_type": "contains",
      "keywords": ["DDA Deposit by Cash"],
      "case_sensitive": false
    }
  }
}
```

### Options

| Option | คำอธิบาย |
|--------|---------|
| `enabled` | เปิด/ปิด row filter |
| `column` | ชื่อ column ที่ใช้ filter |
| `match_type` | วิธี match: `contains`, `equals`, `startswith`, `endswith` |
| `keywords` | array ของ keywords ที่ต้องการ match |
| `case_sensitive` | true/false สำหรับ case sensitivity |

### ตัวอย่าง: GSB Multiple

GSB statement มีหลาย transaction types ใน table เดียว ต้อง filter เอาเฉพาะ deposit:

```json
{
  "row_filter": {
    "enabled": true,
    "column": "Description",
    "match_type": "contains",
    "keywords": ["DDA Deposit by Cash"],
    "case_sensitive": false
  }
}
```

### ความแตกต่าง: row_filter vs ignore_rows

| Feature | row_filter | ignore_rows |
|---------|-----------|-------------|
| Logic | **เลือก** rows ที่ match | **ข้าม** rows ที่ match |
| Use case | เอาเฉพาะ transaction บางประเภท | ข้ามยอดรวม, header ซ้ำ |
| Match by | column value contains keyword | keyword in specific column index |

---

## คำถาม 7 (ใหม่)
> วันที่ใน document เป็นแบบย่อ (เช่น 67 แทน 2567) ต้อง config อย่างไร?

## ตอบ

### ใช้ `other_settings`

```json
{
  "mapping_config": {
    "other_settings": {
      "prefer_buddhist_shorthand": true,
      "locale_hint": "th"
    }
  }
}
```

### Options

| Option | คำอธิบาย |
|--------|---------|
| `prefer_buddhist_shorthand` | true = ปี 2 หลัก = พ.ศ. ย่อ (67 = 2567 = 2024 CE) |
| `locale_hint` | "th" = Thai locale สำหรับ date parsing |

### ตัวอย่าง

| Document | prefer_buddhist_shorthand | ผลลัพธ์ |
|----------|--------------------------|--------|
| Date: 25/01/67 | true | 25/01/2024 (CE) |
| Date: 25/01/67 | false | 25/01/2067 (CE) |
| Date: 25/01/2567 | (auto-detect) | 25/01/2024 (CE) |
