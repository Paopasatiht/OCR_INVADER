# วิธี Config Azure Document Intelligence Settings

## คำถาม 1
> Azure DI timeout เกิดบ่อย ต้องแก้อย่างไร?

## ตอบ

### File Location
```
Config/config.cfg → [Azure_DI_settings]
```

### Settings ที่เกี่ยวข้อง
```ini
[Azure_DI_settings]
connection_timeout = 300    # วินาที - timeout สำหรับ connection
read_timeout = 300          # วินาที - timeout สำหรับ read response
max_retries = 2             # จำนวนครั้งที่ retry เมื่อ fail
```

### วิธีแก้ Timeout

#### Option A: เพิ่ม Timeout
```ini
connection_timeout = 600    # เพิ่มเป็น 10 นาที
read_timeout = 600
```

#### Option B: เพิ่ม Retries
```ini
max_retries = 5            # retry มากขึ้น
```

### หมายเหตุ
- Timeout มากเกินไป = รอนาน ถ้า Azure มีปัญหาจริง
- Retry มากเกินไป = ใช้เวลานานกว่าจะ fail

---

## คำถาม 2
> เอกสารถูก reject เพราะ confidence ต่ำ ต้องแก้อย่างไร?

## ตอบ

### File Location
```
Config/config.cfg → [Azure_DI_settings]
```

### Setting
```ini
[Azure_DI_settings]
Doc_Classification_Confidence_Threshold = 0.6   # ค่า default
```

### วิธีแก้

#### ลด Threshold
```ini
Doc_Classification_Confidence_Threshold = 0.4   # ยอมรับ confidence ต่ำกว่า
```

### Threshold Guidelines

| Value | ความหมาย |
|-------|---------|
| 0.9 | เข้มงวดมาก - ต้อง confident มากๆ |
| 0.6 | ค่า default - balance |
| 0.4 | ผ่อนปรน - ยอมรับ uncertain |
| 0.2 | ผ่อนปรนมาก - อาจได้ผลลัพธ์ผิด |

### ⚠️ ข้อควรระวัง
- ลด threshold = เอกสารที่ไม่แน่ใจอาจถูก process ผิดประเภท
- แนะนำ: Train classifier ให้ดีขึ้นแทนการลด threshold

---

## คำถาม 3
> จะเปลี่ยน Azure DI model ที่ใช้ ต้องแก้ที่ไหน?

## ตอบ

### File Location
```
Config/ocr_config/model_ids.json
```

### Format
```json
{
    "<Class Name>": ["<Extraction Model ID>", "<Transaction Type>"],
    "Doc_Classifier": "<Classifier Model ID>"
}
```

### ตัวอย่าง (ข้อมูลจริงจากระบบปัจจุบัน)
```json
{
    "KBANK Multiple": ["CS-Smart-reconcile-KBank-Multiple-Pay-In", "Multiple"],
    "SCB Multiple": ["CS-Smart-reconcile-SCB-Multiple-Pay-In", "Multiple"],
    "BBL Multiple": ["CS-Smart-reconcile-BBL-Multiple-Pay-In-2", "Multiple"],
    "BBL Single": ["CS-Smart-reconcile-BBL-Single-Pay-In", "Single"],
    "LHBANK Single": ["CS-Smart-reconcile-LHBANK-Single-Pay-In", "Single"],
    "KTB Multiple": ["CS-Smart-reconcile-KTB-Multiple-Pay-In", "Multiple"],
    "KKP Multiple": ["CS-Smart-reconcile-KKP-Multiple-Pay-In", "Multiple"],
    "BAY Multiple": ["CS-Smart-reconcile-BAY-Multiple-Pay-In", "Multiple"],
    "GSB Multiple": ["CS-Smart-reconcile-GSB-Multiple-Pay-In-20260128", "Multiple"],
    "UOB Single": ["CS-Smart-reconcile-UOB-Single-Pay-In", "Single"],
    "Slip": ["CS-Smart-reconcile-PromptPay-Slip", "Slip"],
    "Doc_Classifier": "CS-Smart-Reconcile-Classification-20260127"
}
```

### เปลี่ยน Extraction Model
```json
{
    "KBANK Multiple": ["NEW-MODEL-ID-v2", "Multiple"]  // ← เปลี่ยน Model ID
}
```

### เปลี่ยน Classifier
```json
{
    "Doc_Classifier": "NEW-CLASSIFIER-ID-v2"  // ← เปลี่ยน Classifier ID
}
```

---

## คำถาม 4
> จะดู Model ID ของ classifier/extractor ได้จากไหน?

## ตอบ

### Azure DI Studio

1. เข้า [Document Intelligence Studio](https://documentintelligence.ai.azure.com/)
2. ไปที่ **Custom models** หรือ **Custom classifiers**
3. เลือก model ที่ต้องการ
4. **Model ID** จะแสดงใน details page

### ตัวอย่าง
```
Model Name: KBank Multiple Pay-In Extractor
Model ID: CS-Smart-reconcile-KBank-Multiple-Pay-In  ← ใช้ค่านี้
Status: Ready
```

---

## Azure Credentials

### ตั้งค่าใน `.env` file
```
DI_ENDPOINT=https://your-resource.cognitiveservices.azure.com/
DI_KEY=your-api-key-here
```

### หรือใน `config.cfg` (ไม่แนะนำ - ไม่ปลอดภัย)
```ini
[Azure_DI]
Endpoint = https://your-resource.cognitiveservices.azure.com/
Key = your-api-key-here
```

### ลำดับการหา Credentials
1. Environment variable (`DI_ENDPOINT`, `DI_KEY`)
2. Config file (`[Azure_DI]` section)
