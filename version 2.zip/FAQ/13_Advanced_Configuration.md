# Advanced Configuration

## คำถาม 1
> ระบบอยู่หลัง proxy ต้อง config อย่างไร?

## ตอบ

### File Location
```
Config/config.cfg → [Network]
```

### Settings
```ini
[Network]
use_proxy = true
HTTP_PROXY = http://username:password@proxy.company.com:8080
HTTPS_PROXY = http://username:password@proxy.company.com:8080
```

### Format
```
http://[username:password@]host:port
```

### ตัวอย่าง
```ini
# Without authentication
HTTP_PROXY = http://proxy.company.com:8080

# With authentication
HTTP_PROXY = http://user:pass@proxy.company.com:8080
```

### ตัวอย่างจากระบบ
```ini
[Network]
use_proxy = false
HTTP_PROXY = http://username:password@kaproxy.tfam.co.th:9090
HTTPS_PROXY = http://username:password@kaproxy.tfam.co.th:9090
```

### หมายเหตุ
- ต้องตั้ง `use_proxy = true` เพื่อเปิดใช้งาน
- HTTPS traffic ก็ใช้ HTTP_PROXY ได้ (proxy จะ tunnel)

---

## คำถาม 2
> จะเพิ่ม concurrent connections ต้องแก้ที่ไหน?

## ตอบ

### File Location
```
Config/config.cfg → [Network]
```

### Setting
```ini
[Network]
POOL_SIZE = 32
```

### ผลกระทบ

| POOL_SIZE | ผล |
|-----------|-----|
| สูง (32+) | Process เร็วขึ้น แต่ใช้ resource มาก |
| ต่ำ (4-8) | Process ช้าลง แต่ประหยัด resource |

### แนะนำ

| สถานการณ์ | POOL_SIZE |
|-----------|-----------|
| Production server | 16-32 |
| Development machine | 4-8 |
| Limited bandwidth | 4 |

### หมายเหตุ
- POOL_SIZE กำหนดจำนวน concurrent HTTP connections
- ส่งผลต่อ Azure DI API calls และ SharePoint API calls

---

## คำถาม 3
> SSL certificate error ต้องแก้อย่างไร?

## ตอบ

### File Location
```
Config/config.cfg → [Network]
```

### Setting
```ini
[Network]
ssl_verify = false
```

### ⚠️ ข้อควรระวัง

**ไม่แนะนำใน Production!**

การปิด SSL verification:
- เสี่ยงต่อ Man-in-the-Middle attacks
- ไม่ตรวจสอบ certificate validity
- ไม่ตรวจสอบ server identity

### วิธีที่ดีกว่า

1. **ติดตั้ง Root CA Certificate:**
   ```bash
   # Windows
   certutil -addstore -f "ROOT" company-ca.crt

   # Python
   pip install certifi
   export SSL_CERT_FILE=/path/to/company-ca.crt
   ```

2. **ใช้ Environment Variable:**
   ```bash
   export REQUESTS_CA_BUNDLE=/path/to/ca-bundle.crt
   ```

### ใช้เมื่อไหร่?
- Development/Testing เท่านั้น
- เมื่อมี self-signed certificate ที่ควบคุมได้

---

## All Network Settings

```ini
[Network]
use_proxy = false
ssl_verify = true
HTTP_PROXY = http://username:password@proxy:port
HTTPS_PROXY = http://username:password@proxy:port
POOL_SIZE = 32
```

---

## Environment Variables

นอกจาก config file ยังสามารถใช้ environment variables:

### Azure Credentials
```bash
export DI_ENDPOINT=https://your-resource.cognitiveservices.azure.com/
export DI_KEY=your-api-key
```

### Proxy (Alternative)
```bash
export HTTP_PROXY=http://proxy:port
export HTTPS_PROXY=http://proxy:port
export NO_PROXY=localhost,127.0.0.1
```

### Priority
1. Environment variables (สูงสุด)
2. Config file
3. Default values

---

## Performance Tuning

### สำหรับ High Volume

```ini
[Network]
POOL_SIZE = 64

[Azure_DI_settings]
connection_timeout = 600
read_timeout = 600
max_retries = 5
```

### สำหรับ Low Resource

```ini
[Network]
POOL_SIZE = 4

[Azure_DI_settings]
connection_timeout = 120
read_timeout = 120
max_retries = 2
```
