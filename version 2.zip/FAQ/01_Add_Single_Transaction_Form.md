# วิธีเพิ่ม Pay-in Form แบบ Single Transaction (ธนาคารใหม่)

## คำถาม
> จะเพิ่ม Pay-in form ของธนาคารใหม่ (แบบ Single) ต้องทำอย่างไร?

## ตอบ

### Single Form คืออะไร?
- เอกสาร 1 หน้า = 1 รายการ transaction
- มี fields หลัก: เลขบัญชี, จำนวนเงิน, วันที่
- ตัวอย่างที่มีอยู่: `BBL Single`, `LHBANK Single`, `UOB Single`

### ขั้นตอน

#### Step 1: สร้าง Extraction Model บน Azure DI Studio

1. เข้า [Document Intelligence Studio](https://documentintelligence.ai.azure.com/)
2. สร้าง **Custom extraction model**
3. Upload ตัวอย่างเอกสาร 5-10 ชุด
4. Label fields ให้ตรงกับชื่อที่ระบบคาดหวัง:
   ```
   Bank Account No.    ← เลขบัญชี (หรือ Bank Account No. Hint ถ้ามี mask)
   Amount              ← จำนวนเงิน
   Date                ← วันที่
   ```
5. Train model
6. จด **Model ID**

#### Step 2: Update Classifier บน Azure DI Studio

1. ไปที่ Custom classifier (`CS-Smart-Reconcile-Classification`)
2. เพิ่ม class ใหม่ เช่น `LHBank Single`
3. Upload training samples
4. Re-train classifier

#### Step 3: แก้ไข `Config/ocr_config/model_ids.json`

```json
{
    "BBL Single": ["CS-Smart-reconcile-BBL-Single-Pay-In", "Single"],
    "LHBANK Single": ["CS-Smart-reconcile-LHBANK-Single-Pay-In", "Single"],
    "UOB Single": ["CS-Smart-reconcile-UOB-Single-Pay-In", "Single"],
    "NEW Bank Single": ["<Model ID จาก Step 1>", "Single"],  // ← เพิ่มบรรทัดนี้
    "Doc_Classifier": "CS-Smart-Reconcile-Classification-20260127"
}
```

**Format:**
```
"<ชื่อ Class จาก Classifier>": ["<Extraction Model ID>", "Single"]
```

### Single Forms ที่มีอยู่ในระบบ (ปัจจุบัน)

| Class Name | Model ID | ธนาคาร |
|------------|----------|--------|
| BBL Single | CS-Smart-reconcile-BBL-Single-Pay-In | Bangkok Bank |
| LHBANK Single | CS-Smart-reconcile-LHBANK-Single-Pay-In | LH Bank |
| UOB Single | CS-Smart-reconcile-UOB-Single-Pay-In | UOB |

### ไม่ต้องทำ
- ❌ ไม่ต้องแก้ code Python
- ❌ ไม่ต้องสร้าง Mapper ใหม่ (ใช้ `SingleTransactionFormMapper`)
- ❌ ไม่ต้องสร้าง schema file

### Files ที่เกี่ยวข้อง
| File | Action |
|------|--------|
| `Config/ocr_config/model_ids.json` | เพิ่ม entry ใหม่ |
| `Config/mapping_config/Bank_Codes.json` | เพิ่มเลขบัญชี (ถ้ามีใหม่) |
