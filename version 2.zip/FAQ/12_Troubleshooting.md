# Troubleshooting Guide

## คำถาม 1
> OCR ไม่ทำงาน / Azure DI error ต้องตรวจสอบอะไรบ้าง?

## ตอบ

### Checklist

#### 1. ตรวจสอบ Credentials
```bash
# ใน .env file
DI_ENDPOINT=https://your-resource.cognitiveservices.azure.com/
DI_KEY=your-api-key-here
```

หรือใน `config.cfg`:
```ini
[Azure_DI]
Endpoint = https://...
Key = ...
```

#### 2. ตรวจสอบ Network
```ini
[Network]
use_proxy = false          # ถ้าอยู่หลัง proxy ต้องเป็น true
HTTP_PROXY = http://...
HTTPS_PROXY = http://...
ssl_verify = true          # ลอง false ถ้ามี SSL error
```

#### 3. ตรวจสอบ Model IDs
```
Config/ocr_config/model_ids.json
```
- `Doc_Classifier` ถูกต้องไหม?
- Model IDs มีอยู่บน Azure จริงไหม?

#### 4. ตรวจสอบ Azure Quota
- เข้า Azure Portal
- ไปที่ Document Intelligence resource
- ดู Metrics → ตรวจสอบ quota/throttling

### Common Errors

| Error | สาเหตุ | วิธีแก้ |
|-------|-------|--------|
| `401 Unauthorized` | API key ผิด | ตรวจสอบ DI_KEY |
| `404 Not Found` | Endpoint หรือ Model ID ผิด | ตรวจสอบ DI_ENDPOINT, model_ids.json |
| `429 Too Many Requests` | เกิน quota | รอ หรือ upgrade plan |
| `Timeout` | Network ช้า | เพิ่ม timeout ใน config |
| `SSL Error` | Certificate issue | ตั้ง ssl_verify = false |

---

## คำถาม 2
> ข้อมูลถูก extract แต่ mapping ผิด ต้องตรวจสอบอะไร?

## ตอบ

### Checklist

#### 1. ตรวจสอบ Field Names
Field names ใน extraction model ต้องตรงกับที่ mapper คาดหวัง:

**Single/Slip:**
```
Bank Account No.    (หรือ Bank Account No. Hint)
Amount
Date
```

**Multiple:**
ต้องตรงกับ schema file ใน `multiple_OCR/`

#### 2. ตรวจสอบ Bank_Codes.json
```
Config/mapping_config/Bank_Codes.json
```
- เลขบัญชีมีอยู่ไหม?
- Format ถูกต้องไหม? (normalized - ไม่มีขีด)

#### 3. ตรวจสอบ Schema File (Multiple)
```
Config/mapping_config/multiple_OCR/<Bank>/
```
- `table_name` ตรงกับที่ Azure extract ไหม?
- `columns` mapping ถูกต้องไหม?

### Debug Steps

1. **ดู extraction result:**
   ```
   Cache/Temp/OCR_extraction_results_YYYY-MM-DD.json
   ```

2. **ดู log file:**
   ```
   Logs/log_YYYY-MM-DD.txt
   ```

   หา messages:
   - `Unmapped account` - เลขบัญชีไม่มีใน Bank_Codes.json
   - `Missing fields` - OCR ไม่ได้ extract field ที่ต้องการ

---

## คำถาม 3
> วันที่แปลงผิด (ปี พ.ศ./ค.ศ.) ต้องแก้อย่างไร?

## ตอบ

### สาเหตุ
- ระบบ auto-detect ปี พ.ศ./ค.ศ. จากค่าปี
- ถ้าปี > 2100 → ถือว่าเป็น พ.ศ.
- ถ้าปี < 100 → ถือว่าเป็นปีแบบย่อ (เช่น 67 = 2567 หรือ 2024)

### Schema Setting
สำหรับ Multiple forms ที่ใช้ปีแบบย่อ:

```json
{
  "mapping_config": {
    "other_settings": {
      "prefer_buddhist_shorthand": "True"
    }
  }
}
```

| Setting | ปี 67 แปลงเป็น |
|---------|---------------|
| `"True"` | 2567 (พ.ศ.) → 2024 (ค.ศ.) |
| `"False"` | 2067 (ค.ศ.) |

### ตัวอย่าง
SCB Multiple ใช้ปี ค.ศ.:
```json
"other_settings": {
    "prefer_buddhist_shorthand": "False"
}
```

---

## คำถาม 4
> บางไฟล์ไม่ถูก process ทั้งที่อยู่ใน input folder ต้องตรวจสอบอะไร?

## ตอบ

### Checklist

#### 1. File Extension
รองรับเฉพาะ:
- PDF: `.pdf`
- Images: `.png`, `.jpg`, `.jpeg`, `.tif`, `.tiff`, `.bmp`, `.gif`, `.webp`
- Excel: `.xlsx`, `.xls`, `.csv`

#### 2. PDF Encrypted
ถ้า PDF มี password → จะถูก skip

ดู log:
```
PDF open failed: PDF is encrypted and requires a password
```

#### 3. Pre-Classification Rules
ดูใน `Functions/PreClassification.py`:

```python
# FINNET folder → FINNET bucket
if "FINNET" in path:
    → finnet bucket

# PDF/Image → Azure DI bucket
if extension in [.pdf, .png, .jpg, ...]:
    → azure bucket

# Excel → Excel bucket
if extension in [.xlsx, .xls, .csv]:
    → excel bucket
```

#### 4. Classifier Output
ถ้า classifier output = "Unused" → ไฟล์จะถูก skip

ดู log:
```
Skipping 'Unused' class
```

### Debug Steps

1. ดู log หา file path ที่ต้องการ
2. ตรวจสอบว่าอยู่ใน bucket ไหน (azure/excel/finnet)
3. ถ้าเป็น azure → ดู classification result
4. ถ้าเป็น excel → ตรวจสอบ schema matching

---

## Log File Location

```
Logs/log_YYYY-MM-DD.txt
```

### Useful Log Searches

```bash
# หาไฟล์ที่ fail
grep "error\|fail\|exception" log_2026-01-25.txt

# หา unmapped accounts
grep "Unmapped account" log_2026-01-25.txt

# หา classification results
grep "Type:\|Confidence:" log_2026-01-25.txt
```
