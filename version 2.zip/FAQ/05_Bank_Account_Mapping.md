# วิธีจัดการ Bank Account Mapping

## คำถาม 1
> มีเลขบัญชีใหม่ที่ต้องรองรับ ต้องเพิ่มที่ไหน?

## ตอบ

### File Location
```
Config/mapping_config/Bank_Codes.json
```

### Format
```json
{
  "เลขบัญชี_normalized": {
    "bank_code": "รหัสธนาคาร",
    "bank": "ชื่อธนาคาร",
    "account_no": "เลขบัญชีแสดงผล"
  }
}
```

### ตัวอย่าง (ข้อมูลจริงจากระบบปัจจุบัน)
```json
{
  "0991364021": { "bank_code": "004", "bank": "KBANK", "account_no": "0991364021" },
  "0891068271": { "bank_code": "004", "bank": "KBANK", "account_no": "0891068271" },
  "0753023501": { "bank_code": "014", "bank": "SCB", "account_no": "0753023501" },
  "0143059976": { "bank_code": "014", "bank": "SCB", "account_no": "0143059976" },
  "1510041182": { "bank_code": "025", "bank": "BAY", "account_no": "1510041182" },
  "0130054268": { "bank_code": "025", "bank": "BAY", "account_no": "0130054268" },
  "0916011356": { "bank_code": "006", "bank": "KTB", "account_no": "0916011356" },
  "0553016056": { "bank_code": "002", "bank": "BBL", "account_no": "0553016056" },
  "0541056693": { "bank_code": "011", "bank": "TTB", "account_no": "0541056693" },
  "7963022704": { "bank_code": "024", "bank": "UOB", "account_no": "7963022704" },
  "1000002375": { "bank_code": "069", "bank": "KKP", "account_no": "1000002375" },
  "8891017564": { "bank_code": "073", "bank": "LHBANK", "account_no": "8891017564" },
  "000000429597": { "bank_code": "030", "bank": "GSB", "account_no": "000000429597" },
  "00011140050414": { "bank_code": "067", "bank": "TISCO", "account_no": "00011140050414" },
  "8000279593": { "bank_code": "022", "bank": "CIMB", "account_no": "8000279593" }
}
```

### การ Normalize เลขบัญชี
- Key = เลขบัญชีที่ลบขีด (-) และช่องว่างออก
- ตัวอย่าง: `123-4-56789-0` → `1234567890`

### Bank Codes ที่ใช้ (ข้อมูลจาก Bank_Codes.json ปัจจุบัน)

| Bank Code | ธนาคาร | ชื่อเต็ม |
|-----------|--------|---------|
| 002 | BBL | ธนาคารกรุงเทพ |
| 004 | KBANK | ธนาคารกสิกรไทย |
| 006 | KTB | ธนาคารกรุงไทย |
| 011 | TTB | ธนาคารทหารไทยธนชาต |
| 014 | SCB | ธนาคารไทยพาณิชย์ |
| 022 | CIMB | ธนาคารซีไอเอ็มบีไทย |
| 024 | UOB | ธนาคารยูโอบี |
| 025 | BAY | ธนาคารกรุงศรีอยุธยา |
| 030 | GSB | ธนาคารออมสิน |
| 067 | TISCO | ธนาคารทิสโก้ |
| 069 | KKP | ธนาคารเกียรตินาคินภัทร |
| 073 | LHBANK | ธนาคารแลนด์ แอนด์ เฮ้าส์ |

---

## คำถาม 2
> ข้อมูล bank_code หรือชื่อธนาคารผิด ต้องแก้ที่ไหน?

## ตอบ

### แก้ไขที่
```
Config/mapping_config/Bank_Codes.json
```

### ตัวอย่าง
```json
{
  "1234567890": {
    "bank_code": "004",      // ← แก้ตรงนี้
    "bank": "KBANK",         // ← แก้ตรงนี้
    "account_no": "123-456-7890"
  }
}
```

---

## คำถาม 3
> OCR อ่านเลขบัญชีได้ แต่ระบบ match ไม่ได้ เกิดจากอะไร?

## ตอบ

### สาเหตุที่เป็นไปได้

#### 1. เลขบัญชีไม่มีใน Bank_Codes.json
**วิธีตรวจสอบ:** ดู log → "Unmapped account"
**วิธีแก้:** เพิ่มเลขบัญชีใน `Bank_Codes.json`

#### 2. OCR อ่านเลขบัญชีผิด
**วิธีตรวจสอบ:** ดู extraction result → เทียบกับเลขบัญชีจริง
**วิธีแก้:** Re-train extraction model บน Azure DI

#### 3. Format ไม่ตรง
**วิธีตรวจสอบ:** เทียบ key ใน Bank_Codes.json กับ OCR output
**วิธีแก้:** ตรวจสอบว่า key เป็น normalized format (ไม่มีขีด)

### Debug Flow
```
OCR Output: "123-456-7890"
     │
     ▼
Normalize: "1234567890"
     │
     ▼
Lookup Bank_Codes.json["1234567890"]
     │
     ├── Found → Return bank info
     └── Not Found → "Unmapped account" warning
```

### Log Messages ที่เกี่ยวข้อง
```
WARNING - Unmapped account (item X): raw='1234567890'
```
