# วิธี Config Cache และ Local Paths

## คำถาม 1
> จะเปลี่ยน folder ที่เก็บ cache ต้องแก้ที่ไหน?

## ตอบ

### File Location
```
Config/config.cfg → [Local_Paths]
```

### Settings
```ini
[Local_Paths]
Cache_Inputs = Cache\Inputs\
Cache_Outputs = Cache\Outputs\
Cache_Temp = Cache\Temp\
Logs = Logs\
```

### Folder Structure
```
Project Root/
├── Cache/
│   ├── Inputs/      ← ไฟล์ที่ download มาจาก SharePoint
│   ├── Outputs/     ← ไฟล์ผลลัพธ์ (Excel)
│   └── Temp/        ← ไฟล์ชั่วคราว (DI inbox, JSON results)
└── Logs/            ← Log files
```

### ตัวอย่างการเปลี่ยน Path

**เปลี่ยนไปใช้ drive อื่น:**
```ini
Cache_Inputs = D:\OCR_Cache\Inputs\
Cache_Outputs = D:\OCR_Cache\Outputs\
Cache_Temp = D:\OCR_Cache\Temp\
Logs = D:\OCR_Cache\Logs\
```

**เปลี่ยนชื่อ folder:**
```ini
Cache_Inputs = WorkingFiles\Input\
Cache_Outputs = WorkingFiles\Output\
```

### หมายเหตุ
- ใช้ `\` สำหรับ Windows paths
- Paths เป็น relative จาก project root
- ระบบจะสร้าง folder อัตโนมัติถ้ายังไม่มี

---

## คำถาม 2
> จะให้ระบบลบ cache อัตโนมัติหลัง upload สำเร็จ ต้อง config อย่างไร?

## ตอบ

### File Location
```
Config/config.cfg → [Cache_setting]
```

### Setting
```ini
[Cache_setting]
Delete_Cache_After_Upload = true
```

### เงื่อนไขการลบ Cache

Cache จะถูกลบเมื่อ **ทุกเงื่อนไข** เป็นจริง:
1. `Delete_Cache_After_Upload = true`
2. `Enable_SharePoint_API = true`
3. มีไฟล์ที่ upload สำเร็จ
4. SharePoint status ไม่ใช่ "failed"

### Folders ที่จะถูกลบ

| Folder | ถูกลบ? |
|--------|--------|
| `Cache/Inputs/` | ✅ Yes |
| `Cache/Outputs/` | ✅ Yes |
| `Cache/Temp/` | ✅ Yes |
| `Logs/` | ❌ No (เก็บไว้) |

### ทำไมไม่ลบ Logs?
- เพื่อเก็บประวัติการ run
- ใช้ debug ถ้ามีปัญหา

### แนะนำ

**Production:**
```ini
Delete_Cache_After_Upload = true
```
- ประหยัด disk space
- ข้อมูลอยู่บน SharePoint แล้ว

**Development:**
```ini
Delete_Cache_After_Upload = false
```
- เก็บ cache ไว้ debug
- ดู intermediate files ได้

---

## All Local Paths Settings

```ini
[Local_Paths]
# Cache directories
Cache_Inputs = Cache\Inputs\
Cache_Outputs = Cache\Outputs\
Cache_Temp = Cache\Temp\
Logs = Logs\

# Config files
Model_IDs_JSON = Config\ocr_config\model_ids.json
Mapping_config_shared_root = Config\mapping_config\
BANK_CODES_DICT = Config\mapping_config\Bank_Codes.json
AGENT_NAMES_DICT = Config\mapping_config\Agent_Names.json
FINNET_mapping_DICT = Config\mapping_config\FINNET\finnet_excel_config.json
multiple_OCR_mapping_schema_dir = Config\mapping_config\multiple_OCR\
other_excel_mapping_schema_dir = Config\mapping_config\other_excels\

# Email templates
Email_Template_Path = Email Format\
```
