# วิธีจัดการ Agent Mapping

## คำถาม 1
> มี Agent/บริษัทหลักทรัพย์ใหม่ ต้องเพิ่มที่ไหน?

## ตอบ

### File Location
```
Config/mapping_config/Agent_Names.json
```

### Format
```json
{
  "CODE": "CODE - ชื่อเต็มภาษาไทย"
}
```

### ตัวอย่าง
```json
{
  "KSAMF": "KSAMF - บริษัทหลักทรัพย์จัดการกองทุน กรุงศรี จำกัด",
  "KSEC": "KSEC - บริษัทหลักทรัพย์ กสิกรไทย จำกัด(มหาชน)",
  "LHBANK": "LHBANK - ธนาคารแลนด์ แอนด์ เฮ้าส์ จำกัด (มหาชน)",
  "LHS": "LHS - บริษัทหลักทรัพย์ แลนด์ แอนด์ เฮาส์ จำกัด (มหาชน)"
}
```

### วิธีเพิ่ม Agent ใหม่

1. เปิดไฟล์ `Agent_Names.json`
2. เพิ่ม entry ใหม่:
```json
{
  "existing...": "...",
  "NEWAGENT": "NEWAGENT - ชื่อเต็มบริษัท"  // ← เพิ่มบรรทัดนี้
}
```

---

## คำถาม 2
> ระบบหา Agent ไม่เจอจาก file path ต้องทำอย่างไร?

## ตอบ

### ระบบหา Agent อย่างไร?

ระบบใช้ `extract_agent_from_path()` ใน `Functions/mappers/helpers.py`:

1. ดึง file path เช่น `/Inputs/KSEC/document.pdf`
2. แยก path components: `["Inputs", "KSEC", "document.pdf"]`
3. เทียบแต่ละ component กับ keys ใน `Agent_Names.json`
4. ถ้าเจอ match → return agent name

### สาเหตุที่หา Agent ไม่เจอ

#### 1. Folder name ไม่ตรงกับ Agent code
```
File path: /Inputs/KrungsriAMC/doc.pdf
Agent_Names.json: {"KSAMF": "..."}

❌ "KrungsriAMC" ≠ "KSAMF"
```
**วิธีแก้:** เปลี่ยนชื่อ folder ให้ตรงกับ code ใน Agent_Names.json

#### 2. Agent code ไม่มีใน Agent_Names.json
```
File path: /Inputs/NEWAGENT/doc.pdf
Agent_Names.json: ไม่มี "NEWAGENT"

❌ No match found
```
**วิธีแก้:** เพิ่ม agent code ใน Agent_Names.json

### Folder Structure ที่แนะนำ
```
Inputs/
├── KSEC/           ← ตรงกับ key "KSEC" ใน Agent_Names.json
│   └── doc1.pdf
├── KSAMF/          ← ตรงกับ key "KSAMF"
│   └── doc2.pdf
└── LHBANK/         ← ตรงกับ key "LHBANK"
    └── doc3.pdf
```

### Debug
ถ้า Agent เป็น empty string ใน output:
1. ตรวจสอบ file path ใน log
2. ตรวจสอบว่า folder name มีใน Agent_Names.json หรือไม่
3. Key ใน Agent_Names.json เป็น case-sensitive
