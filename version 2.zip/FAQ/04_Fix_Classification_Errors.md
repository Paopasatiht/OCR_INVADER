# วิธีแก้ไขปัญหา Classification ผิดพลาด

## คำถาม 1
> Classifier แยกประเภทเอกสารผิด ต้องแก้อย่างไร?

## ตอบ

### สาเหตุ
- Training samples ไม่เพียงพอ
- เอกสารมี layout คล้ายกับ class อื่น
- Confidence threshold สูงเกินไป

### วิธีแก้

#### Option A: เพิ่ม Training Samples

1. เข้า Azure DI Studio → Custom classifier
2. ไปที่ class ที่ต้องการ
3. Upload เอกสารที่ถูก classify ผิดเป็น training sample
4. Re-train classifier

#### Option B: ลด Confidence Threshold

แก้ไข `Config/config.cfg`:
```ini
[Azure_DI_settings]
Doc_Classification_Confidence_Threshold = 0.5  # ลดจาก 0.6
```

⚠️ ข้อควรระวัง: ลด threshold = ยอมรับ confidence ต่ำกว่า = อาจได้ผลลัพธ์ที่ไม่แน่นอน

---

## คำถาม 2
> เอกสารถูก classify เป็น "Unused" ทั้งที่ควรจะใช้ได้ ต้องทำอย่างไร?

## ตอบ

### สาเหตุ
- Classifier ไม่รู้จักเอกสารประเภทนี้
- Confidence ต่ำกว่า threshold

### ตรวจสอบ

1. ดู log file → หา "unknown_or_unused_from_azure"
2. ดู classification_confidence ว่าต่ำกว่า threshold หรือไม่

### วิธีแก้

#### ถ้าเป็นเอกสารประเภทที่มีอยู่แล้ว (เช่น Single)
1. เพิ่ม training samples ให้ class นั้นใน Azure DI
2. Re-train classifier

#### ถ้าเป็นเอกสารประเภทใหม่
1. สร้าง class ใหม่ใน classifier
2. เพิ่ม training samples
3. Train classifier
4. เพิ่ม entry ใน `model_ids.json`

### Files ที่เกี่ยวข้อง
| File | Setting |
|------|---------|
| `Config/config.cfg` | `Doc_Classification_Confidence_Threshold` |
| `Config/ocr_config/model_ids.json` | class → model mapping |
