# วิธีเพิ่ม Test Agent และทดสอบ Output

## คำถาม
> ถ้าต้องการจะเพิ่ม Agent ที่เป็นตัว Test (เช่น "LHBank Tester") ที่มีแต่เอกสาร LHBANK แล้วให้ออก Output ด้วย ต้องทำอย่างไร?

## ตอบ

### สิ่งที่ต้องทำ (3 ขั้นตอน)

```
1. เพิ่ม Agent Code ใน Agent_Names.json
2. สร้าง Folder Structure สำหรับ Test Agent
3. ใส่ไฟล์เอกสาร LHBANK และ Run ระบบ
```

---

## ขั้นตอนที่ 1: เพิ่ม Agent Code

### File Location
```
Config/mapping_config/Agent_Names.json
```

### เพิ่ม Entry ใหม่
```json
{
  "... existing agents ...",
  "LHBANK_TESTER": "LHBANK_TESTER - ทดสอบ LHBANK Agent"
}
```

### หลักการตั้งชื่อ Agent Code
- ใช้ตัวพิมพ์ใหญ่
- ไม่มี space (ใช้ underscore แทน)
- ตรงกับชื่อ folder ที่จะสร้าง

---

## ขั้นตอนที่ 2: สร้าง Folder Structure

### สำหรับ Local Testing
```
Cache/Inputs/
└── LHBANK_TESTER/           ← ชื่อต้องตรงกับ key ใน Agent_Names.json
    └── (ใส่ไฟล์ LHBANK ที่นี่)
```

### สำหรับ SharePoint (Production)
```
Provident Fund/OCR - Rekey Percent Unvest/
└── Inputs/
    └── LHBANK_TESTER/       ← ชื่อต้องตรงกับ key ใน Agent_Names.json
        └── (upload ไฟล์ LHBANK ที่นี่)
```

---

## ขั้นตอนที่ 3: เตรียมเอกสารทดสอบ

### ไฟล์ที่ใช้ได้
- **PDF/Image ของ LHBANK Pay-in Slip**
- ต้องใช้ **เลขบัญชีที่มีอยู่ใน Bank_Codes.json**

### ตรวจสอบเลขบัญชี LHBANK ที่รองรับ
```
Config/mapping_config/Bank_Codes.json
```

เลขบัญชี LHBANK ที่ระบบรองรับ:
```json
"8891017564": { "bank_code": "073", "bank": "LHBANK", "account_no": "8891017564" }
```

### ⚠️ สำคัญ
ถ้าเอกสารทดสอบมี **เลขบัญชีอื่น** ที่ไม่มีใน Bank_Codes.json:
1. ต้องเพิ่มเลขบัญชีนั้นก่อน
2. ดูวิธีเพิ่มใน `05_Bank_Account_Mapping.md`

---

## ขั้นตอนที่ 4: Run ระบบ

### สำหรับ Local Testing
```
Config/config.cfg:
[SharePoint_API_setting]
Enable_SharePoint_API = false
```

วางไฟล์ใน `Cache/Inputs/LHBANK_TESTER/` แล้ว run:
```bash
python main.py
```

### สำหรับ SharePoint
```
Config/config.cfg:
[SharePoint_API_setting]
Enable_SharePoint_API = true
```

---

## Output ที่ได้

### ตำแหน่ง Output
```
Cache/Outputs/
├── Single_{date}.xlsx      ← ถ้าเป็น Single form
├── Multiple_{date}.xlsx    ← ถ้าเป็น Multiple form
└── Slip_{date}.xlsx        ← ถ้าเป็น Slip
```

### โครงสร้าง Excel Output

| Column | ตัวอย่างค่า |
|--------|------------|
| **agent** | `LHBANK_TESTER - ทดสอบ LHBANK Agent` |
| payment_type | `C` |
| bank_code | `073` |
| bank_account_no_fmt | `LHBANK ธนาคารแลนด์ แอนด์ เฮ้าส์ 8891017564` |
| amount | `10,000.00` |
| date | `25/01/2026` |
| source_kind | `Single` (หรือ Multiple/Slip) |
| source_file | `LHBANK_TESTER/document.pdf` |

---

## Flow การทำงานของระบบ

```
Input File Path                    Agent Extraction
────────────────────────────────────────────────────
Cache/Inputs/LHBANK_TESTER/doc.pdf
                     │
                     ▼
        extract_agent_from_path()
                     │
        ┌────────────┴────────────┐
        │ ดึง path components:    │
        │ ["Cache","Inputs",      │
        │  "LHBANK_TESTER",       │
        │  "doc.pdf"]             │
        └────────────┬────────────┘
                     │
                     ▼
        ┌────────────────────────────┐
        │ Match กับ Agent_Names.json │
        │ Key: "LHBANK_TESTER"       │
        └────────────┬───────────────┘
                     │
                     ▼
        Output: "LHBANK_TESTER - ทดสอบ LHBANK Agent"
```

---

## ตัวอย่างเต็ม

### 1. Agent_Names.json (เพิ่ม entry)
```json
{
  "AECS": "AECS - บริษัท หลักทรัพย์ บียอนด์ จำกัด (มหาชน)",
  "... existing ...",
  "LHBANK_TESTER": "LHBANK_TESTER - ทดสอบ LHBANK Agent"
}
```

### 2. Folder Structure
```
Cache/
└── Inputs/
    └── LHBANK_TESTER/
        ├── LHBank_Payin_001.pdf
        ├── LHBank_Payin_002.pdf
        └── LHBank_Slip_001.png
```

### 3. Bank_Codes.json (ตรวจสอบว่ามีเลขบัญชี)
```json
{
  "8891017564": { "bank_code": "073", "bank": "LHBANK", "account_no": "8891017564" }
}
```

### 4. model_ids.json (ตรวจสอบว่ามี model สำหรับ LHBANK)
```json
{
  "LHBANK Single": ["CS-Smart-reconcile-LHBANK-Single-Pay-In", "Single"],
  "Doc_Classifier": "CS-Smart-Reconcile-Classification-20260127"
}
```

### model_ids.json ปัจจุบัน (ทั้งหมด)
```json
{
    "KBANK Multiple": ["CS-Smart-reconcile-KBank-Multiple-Pay-In", "Multiple"],
    "SCB Multiple": ["CS-Smart-reconcile-SCB-Multiple-Pay-In", "Multiple"],
    "BBL Multiple": ["CS-Smart-reconcile-BBL-Multiple-Pay-In-2", "Multiple"],
    "BBL Single": ["CS-Smart-reconcile-BBL-Single-Pay-In", "Single"],
    "LHBANK Single": ["CS-Smart-reconcile-LHBANK-Single-Pay-In", "Single"],
    "KTB Multiple": ["CS-Smart-reconcile-KTB-Multiple-Pay-In", "Multiple"],
    "KKP Multiple": ["CS-Smart-reconcile-KKP-Multiple-Pay-In", "Multiple"],
    "BAY Multiple": ["CS-Smart-reconcile-BAY-Multiple-Pay-In", "Multiple"],
    "GSB Multiple": ["CS-Smart-reconcile-GSB-Multiple-Pay-In-20260128", "Multiple"],
    "UOB Single": ["CS-Smart-reconcile-UOB-Single-Pay-In", "Single"],
    "Slip": ["CS-Smart-reconcile-PromptPay-Slip", "Slip"],
    "Doc_Classifier": "CS-Smart-Reconcile-Classification-20260127"
}
```

---

## Checklist ก่อน Run

- [ ] เพิ่ม Agent Code ใน `Agent_Names.json`
- [ ] สร้าง folder ชื่อตรงกับ Agent Code
- [ ] ตรวจสอบเลขบัญชีใน `Bank_Codes.json`
- [ ] ตรวจสอบ model ใน `model_ids.json` (ต้องมี classifier รองรับ)
- [ ] ตั้งค่า `Enable_SharePoint_API` ตามต้องการ

---

## Troubleshooting

### Agent เป็นค่าว่างใน Output
**สาเหตุ:** ชื่อ folder ไม่ตรงกับ key ใน Agent_Names.json
**วิธีแก้:** ตรวจสอบว่าชื่อ folder ตรงกัน (case-sensitive)

### Document ถูก classify เป็น "Unused"
**สาเหตุ:** Classifier ไม่รู้จักเอกสาร LHBANK
**วิธีแก้:** ต้อง train classifier บน Azure DI Studio ให้รู้จัก LHBANK form

### OCR อ่านเลขบัญชีได้แต่ mapping ไม่เจอ
**สาเหตุ:** เลขบัญชีไม่มีใน Bank_Codes.json
**วิธีแก้:** เพิ่มเลขบัญชีใน Bank_Codes.json

---

## Related FAQs

- `01_Add_Single_Transaction_Form.md` - เพิ่ม Single form ใหม่
- `05_Bank_Account_Mapping.md` - เพิ่มเลขบัญชีใหม่
- `06_Agent_Mapping.md` - จัดการ Agent Names
- `How_to_add_LHBank_Single_Cell.md` - ตัวอย่างเพิ่ม LHBank
