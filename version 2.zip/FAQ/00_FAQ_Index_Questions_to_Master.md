# FAQ Index - คำถามที่ต้องตอบได้เพื่อ Config ระบบ OCR

## Overview

เอกสารนี้รวบรวมคำถามทั้งหมดที่ผู้ดูแลระบบควรตอบได้ เพื่อรองรับ requirements จาก user

---

## 1. เพิ่ม Document Type ใหม่ (Azure DI)

### 1.1 Single Transaction Forms
- [x] **Q: จะเพิ่ม Pay-in form ของธนาคารใหม่ (แบบ Single) ต้องทำอย่างไร?**
  - 📄 `01_Add_Single_Transaction_Form.md`
  - 📄 `How_to_add_LHBank_Single_Cell.md`

### 1.2 Multiple Transaction Forms
- [x] **Q: จะเพิ่ม Pay-in form ของธนาคารใหม่ (แบบ Multiple/ตาราง) ต้องทำอย่างไร?**
  - 📄 `02_Add_Multiple_Transaction_Form.md`

### 1.3 Slip/Mobile Banking
- [x] **Q: จะเพิ่ม Slip รูปแบบใหม่ ต้องทำอย่างไร?**
  - 📄 `03_Add_Slip_Document.md`

### 1.4 Document Classification
- [x] **Q: Classifier แยกประเภทเอกสารผิด ต้องแก้อย่างไร?**
  - 📄 `04_Fix_Classification_Errors.md`

- [x] **Q: เอกสารถูก classify เป็น "Unused" ทั้งที่ควรจะใช้ได้ ต้องทำอย่างไร?**
  - 📄 `04_Fix_Classification_Errors.md`

---

## 2. เพิ่ม/แก้ไข Bank Account Mapping

- [x] **Q: มีเลขบัญชีใหม่ที่ต้องรองรับ ต้องเพิ่มที่ไหน?**
  - 📄 `05_Bank_Account_Mapping.md`

- [x] **Q: ข้อมูล bank_code หรือชื่อธนาคารผิด ต้องแก้ที่ไหน?**
  - 📄 `05_Bank_Account_Mapping.md`

- [x] **Q: OCR อ่านเลขบัญชีได้ แต่ระบบ match ไม่ได้ เกิดจากอะไร?**
  - 📄 `05_Bank_Account_Mapping.md`

---

## 3. เพิ่ม/แก้ไข Agent Mapping

- [x] **Q: มี Agent/บริษัทหลักทรัพย์ใหม่ ต้องเพิ่มที่ไหน?**
  - 📄 `06_Agent_Mapping.md`

- [x] **Q: ระบบหา Agent ไม่เจอจาก file path ต้องทำอย่างไร?**
  - 📄 `06_Agent_Mapping.md`

- [x] **Q: จะเพิ่ม Test Agent สำหรับทดสอบระบบ (เช่น ใส่เฉพาะเอกสาร LHBANK) ต้องทำอย่างไร?**
  - 📄 `14_Add_Test_Agent.md`

---

## 4. Excel Schema Configuration

- [x] **Q: Multiple form ของธนาคารใหม่มี column names ต่างจากที่มีอยู่ ต้องทำอย่างไร?**
  - 📄 `07_Excel_Schema_Configuration.md`

- [x] **Q: Multiple form มีหลาย table types ต้อง config อย่างไร?**
  - 📄 `07_Excel_Schema_Configuration.md`

- [x] **Q: มี Excel file รูปแบบใหม่ที่ไม่ใช่ FINNET ต้อง config อย่างไร?**
  - 📄 `07_Excel_Schema_Configuration.md`

- [x] **Q: Excel มี header row อยู่บรรทัดอื่น (ไม่ใช่บรรทัดแรก) ต้อง config อย่างไร?**
  - 📄 `07_Excel_Schema_Configuration.md`

- [x] **Q: Excel มี row ที่ต้อง ignore (เช่น ยอดรวม) ต้อง config อย่างไร?**
  - 📄 `07_Excel_Schema_Configuration.md`

- [x] **Q: Table มี rows ที่ต้อง filter เอาเฉพาะบาง rows (เช่น GSB) ต้อง config อย่างไร?**
  - 📄 `07_Excel_Schema_Configuration.md`

- [x] **Q: วันที่ใน document เป็นแบบย่อ (เช่น 67 แทน 2567) ต้อง config อย่างไร?**
  - 📄 `07_Excel_Schema_Configuration.md`

---

## 5. Azure DI Settings

- [x] **Q: Azure DI timeout เกิดบ่อย ต้องแก้อย่างไร?**
  - 📄 `08_Azure_DI_Settings.md`

- [x] **Q: เอกสารถูก reject เพราะ confidence ต่ำ ต้องแก้อย่างไร?**
  - 📄 `08_Azure_DI_Settings.md`

- [x] **Q: จะเปลี่ยน Azure DI model ที่ใช้ ต้องแก้ที่ไหน?**
  - 📄 `08_Azure_DI_Settings.md`

- [x] **Q: จะดู Model ID ของ classifier/extractor ได้จากไหน?**
  - 📄 `08_Azure_DI_Settings.md`

---

## 6. SharePoint Settings

- [x] **Q: จะปิด SharePoint integration (ใช้ local files แทน) ต้องทำอย่างไร?**
  - 📄 `09_SharePoint_Settings.md`

- [x] **Q: จะเปลี่ยน folder บน SharePoint ที่ใช้ upload/download ต้องแก้ที่ไหน?**
  - 📄 `09_SharePoint_Settings.md`

- [x] **Q: SharePoint error แต่อยากให้ระบบทำงานต่อ ต้อง config อย่างไร?**
  - 📄 `09_SharePoint_Settings.md`

---

## 7. Email Settings

- [x] **Q: จะเปลี่ยนคนรับ email สรุปผล ต้องแก้ที่ไหน?**
  - 📄 `10_Email_Settings.md`

- [x] **Q: จะเปลี่ยน SMTP server ต้องแก้ที่ไหน?**
  - 📄 `10_Email_Settings.md`

- [x] **Q: จะแก้ไข email template (HTML) ต้องแก้ที่ไหน?**
  - 📄 `10_Email_Settings.md`

---

## 8. Cache & Local Paths

- [x] **Q: จะเปลี่ยน folder ที่เก็บ cache ต้องแก้ที่ไหน?**
  - 📄 `11_Cache_and_Paths.md`

- [x] **Q: จะให้ระบบลบ cache อัตโนมัติหลัง upload สำเร็จ ต้อง config อย่างไร?**
  - 📄 `11_Cache_and_Paths.md`

---

## 9. Troubleshooting

- [x] **Q: OCR ไม่ทำงาน / Azure DI error ต้องตรวจสอบอะไรบ้าง?**
  - 📄 `12_Troubleshooting.md`

- [x] **Q: ข้อมูลถูก extract แต่ mapping ผิด ต้องตรวจสอบอะไร?**
  - 📄 `12_Troubleshooting.md`

- [x] **Q: วันที่แปลงผิด (ปี พ.ศ./ค.ศ.) ต้องแก้อย่างไร?**
  - 📄 `12_Troubleshooting.md`

- [x] **Q: บางไฟล์ไม่ถูก process ทั้งที่อยู่ใน input folder ต้องตรวจสอบอะไร?**
  - 📄 `12_Troubleshooting.md`

---

## 10. Advanced Configuration

- [x] **Q: ระบบอยู่หลัง proxy ต้อง config อย่างไร?**
  - 📄 `13_Advanced_Configuration.md`

- [x] **Q: จะเพิ่ม concurrent connections ต้องแก้ที่ไหน?**
  - 📄 `13_Advanced_Configuration.md`

- [x] **Q: SSL certificate error ต้องแก้อย่างไร?**
  - 📄 `13_Advanced_Configuration.md`

---

## Quick Reference: Config Files

| File | Purpose |
|------|---------|
| `Config/config.cfg` | Main config - paths, settings, credentials |
| `Config/ocr_config/model_ids.json` | Azure DI model mappings (Classifier + Extractors) |
| `Config/mapping_config/Bank_Codes.json` | Bank account → bank info (19 accounts) |
| `Config/mapping_config/Agent_Names.json` | Agent code → display name (56 agents) |
| `Config/mapping_config/default_accounts.json` | Default accounts for some doc types |
| `Config/mapping_config/multiple_OCR/*/` | Schema for Multiple OCR forms (7 banks) |
| `Config/mapping_config/other_excels/*/` | Schema for non-FINNET Excel |
| `Config/mapping_config/FINNET/` | FINNET Excel config |
| `.env` | Azure credentials (DI_ENDPOINT, DI_KEY) |

## Quick Reference: Supported Document Types (ปัจจุบัน)

### Single Forms (3 types)
| Class Name | Model ID |
|------------|----------|
| BBL Single | CS-Smart-reconcile-BBL-Single-Pay-In |
| LHBANK Single | CS-Smart-reconcile-LHBANK-Single-Pay-In |
| UOB Single | CS-Smart-reconcile-UOB-Single-Pay-In |

### Multiple Forms (7 types)
| Class Name | Model ID |
|------------|----------|
| KBANK Multiple | CS-Smart-reconcile-KBank-Multiple-Pay-In |
| SCB Multiple | CS-Smart-reconcile-SCB-Multiple-Pay-In |
| BBL Multiple | CS-Smart-reconcile-BBL-Multiple-Pay-In-2 |
| KTB Multiple | CS-Smart-reconcile-KTB-Multiple-Pay-In |
| KKP Multiple | CS-Smart-reconcile-KKP-Multiple-Pay-In |
| BAY Multiple | CS-Smart-reconcile-BAY-Multiple-Pay-In |
| GSB Multiple | CS-Smart-reconcile-GSB-Multiple-Pay-In-20260128 |

### Slip (1 type)
| Class Name | Model ID |
|------------|----------|
| Slip | CS-Smart-reconcile-PromptPay-Slip |

### Classifier
| Purpose | Model ID |
|---------|----------|
| Document Classification | CS-Smart-Reconcile-Classification-20260127 |

---

## FAQ Files Summary

| File | Topics |
|------|--------|
| `00_FAQ_Index_Questions_to_Master.md` | This index |
| `01_Add_Single_Transaction_Form.md` | เพิ่ม Single form ใหม่ |
| `02_Add_Multiple_Transaction_Form.md` | เพิ่ม Multiple form ใหม่ |
| `03_Add_Slip_Document.md` | เพิ่ม Slip ใหม่ |
| `04_Fix_Classification_Errors.md` | แก้ปัญหา classification |
| `05_Bank_Account_Mapping.md` | จัดการ bank accounts |
| `06_Agent_Mapping.md` | จัดการ agent names |
| `07_Excel_Schema_Configuration.md` | Config Excel schemas |
| `08_Azure_DI_Settings.md` | Azure DI settings |
| `09_SharePoint_Settings.md` | SharePoint settings |
| `10_Email_Settings.md` | Email settings |
| `11_Cache_and_Paths.md` | Cache & paths |
| `12_Troubleshooting.md` | Debug & troubleshooting |
| `13_Advanced_Configuration.md` | Network, proxy, SSL |
| `14_Add_Test_Agent.md` | เพิ่ม Test Agent และทดสอบ Output |
| `How_to_add_LHBank_Single_Cell.md` | ตัวอย่างเพิ่ม LHBank |

---

## Status

✅ **ตอบครบทุกคำถามแล้ว (37/37)**

---

## Last Updated

**2026-01-30** - Synced with latest code:
- Updated model_ids.json with 11 document types (3 Single, 7 Multiple, 1 Slip)
- Updated Bank_Codes.json with 19 bank accounts
- Added row_filter documentation for GSB Multiple
- Added prefer_buddhist_shorthand documentation
