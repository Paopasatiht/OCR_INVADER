# วิธีเพิ่ม LHBank Single Cell เข้าระบบ OCR

## Config System Overview

```
Config/
├── config.cfg                      ← Main config ชี้ไปหา files อื่นๆ
├── ocr_config/
│   └── model_ids.json              ← Azure DI Model IDs (Classifier + Extractors)
└── mapping_config/
    ├── Bank_Codes.json             ← เลขบัญชี → Bank info
    ├── Agent_Names.json            ← Agent code → Display name
    ├── default_accounts.json       ← Default accounts สำหรับบาง document types
    ├── FINNET/                     ← FINNET Excel config
    │   └── finnet_excel_config.json
    ├── multiple_OCR/               ← Schema สำหรับ Multiple OCR forms
    │   ├── BAY Multiple/
    │   ├── BBL Multiple/
    │   ├── GSB Multiple/
    │   ├── KBank Multiple/
    │   ├── KKP Multiple/
    │   ├── KTB Multiple/
    │   └── SCB Multiple/
    └── other_excels/               ← Schema สำหรับ Excel files ที่ไม่ใช่ FINNET
        └── KBank/
```

---

## สิ่งที่มีอยู่แล้ว

จาก `model_ids.json` (ล่าสุด):
```json
{
    "KBANK Multiple": ["CS-Smart-reconcile-KBank-Multiple-Pay-In", "Multiple"],
    "SCB Multiple": ["CS-Smart-reconcile-SCB-Multiple-Pay-In", "Multiple"],
    "BBL Multiple": ["CS-Smart-reconcile-BBL-Multiple-Pay-In-2", "Multiple"],
    "BBL Single": ["CS-Smart-reconcile-BBL-Single-Pay-In", "Single"],
    "LHBANK Single": ["CS-Smart-reconcile-LHBANK-Single-Pay-In", "Single"],  ← มีแล้ว!
    "KTB Multiple": ["CS-Smart-reconcile-KTB-Multiple-Pay-In", "Multiple"],
    "KKP Multiple": ["CS-Smart-reconcile-KKP-Multiple-Pay-In", "Multiple"],
    "BAY Multiple": ["CS-Smart-reconcile-BAY-Multiple-Pay-In", "Multiple"],
    "GSB Multiple": ["CS-Smart-reconcile-GSB-Multiple-Pay-In-20260128", "Multiple"],
    "UOB Single": ["CS-Smart-reconcile-UOB-Single-Pay-In", "Single"],
    "Slip": ["CS-Smart-reconcile-PromptPay-Slip", "Slip"],
    "Doc_Classifier": "CS-Smart-Reconcile-Classification-20260127"
}
```

จาก `Bank_Codes.json`:
```json
{
    "8891017564": { "bank_code": "073", "bank": "LHBANK", "account_no": "8891017564" }
}
```
→ **LHBANK มีเลขบัญชีอยู่แล้ว 1 บัญชี**

---

## ขั้นตอนที่ต้องทำ

### Step 1: Azure Document Intelligence (บน Azure Portal)

#### 1.1 สร้าง Extraction Model สำหรับ LHBank Single

1. เข้า [Document Intelligence Studio](https://documentintelligence.ai.azure.com/)
2. สร้าง **Custom extraction model** ใหม่
3. Upload ตัวอย่าง LHBank Single Cell forms (5-10 ตัวอย่าง)
4. Label fields ที่ต้องการ:
   - `Bank Account No.` หรือ `Bank Account No. Hint` - เลขบัญชี
   - `Amount` - จำนวนเงิน
   - `Date` - วันที่
5. Train model
6. **จด Model ID** เช่น `CS-Smart-reconcile-LHBank-Single-Pay-In`

#### 1.2 Update Classifier ให้รู้จัก LHBank Single

1. ไปที่ Custom classifier ที่มีอยู่ (`CS-Smart-Reconcile-Classification`)
2. เพิ่ม class ใหม่ชื่อ `LHBank Single`
3. Upload training samples สำหรับ class นี้
4. Re-train classifier

---

### Step 2: Update Config Files

#### 2.1 แก้ไข `Config/ocr_config/model_ids.json`

เพิ่ม entry ใหม่:

```json
{
    "KBANK Multiple": ["CS-Smart-reconcile-KBank-Multiple-Pay-In", "Multiple"],
    "SCB Multiple": ["CS-Smart-reconcile-SCB-Multiple-Pay-In", "Multiple"],
    "BBL Multiple": ["CS-Smart-reconcile-BBL-Multiple-Pay-In-2", "Multiple"],
    "BBL Single": ["CS-Smart-reconcile-BBL-Single-Pay-In", "Single"],
    "LHBank Single": ["CS-Smart-reconcile-LHBank-Single-Pay-In", "Single"],  ← เพิ่มบรรทัดนี้
    "Slip": ["CS-Smart-reconcile-PromptPay-Slip", "Slip"],
    "Doc_Classifier": "CS-Smart-Reconcile-Classification"
}
```

**รูปแบบ:**
```
"<Classifier Output Name>": ["<Extraction Model ID>", "<Transaction Type>"]
```

- `"LHBank Single"` = ชื่อ class ที่ classifier จะ output
- `"CS-Smart-reconcile-LHBank-Single-Pay-In"` = Model ID ที่สร้างใน Step 1.1
- `"Single"` = Transaction Type → ระบบจะใช้ `SingleTransactionFormMapper`

#### 2.2 เพิ่มเลขบัญชี (ถ้ามีเลขบัญชีใหม่)

แก้ไข `Config/mapping_config/Bank_Codes.json`:

```json
{
    "เลขบัญชีที่มีอยู่...": "...",
    "8891017564": { "bank_code": "073", "bank": "LHBANK", "account_no": "8891017564" },
    "1234567890": { "bank_code": "073", "bank": "LHBANK", "account_no": "123-456-7890" }  ← เพิ่มถ้ามีบัญชีใหม่
}
```

**Format:**
- Key = เลขบัญชีที่ลบขีด/ช่องว่างออก (normalized)
- `bank_code` = รหัสธนาคาร (073 = LHBANK)
- `bank` = ชื่อธนาคาร
- `account_no` = เลขบัญชีแบบแสดงผล

---

## Flow การทำงาน

```
Document Input (LHBank Single Cell form)
        │
        ▼
┌───────────────────────────────────────┐
│ Azure DI Classifier                    │
│ Model: CS-Smart-Reconcile-Classification│
│ Output: "LHBank Single"                │
└───────────────────────────────────────┘
        │
        ▼
┌───────────────────────────────────────┐
│ Lookup model_ids.json                  │
│ "LHBank Single" → [                    │
│   "CS-Smart-reconcile-LHBank-Single",  │
│   "Single"                             │
│ ]                                      │
└───────────────────────────────────────┘
        │
        ├─── Extraction Model ID ───────────────┐
        │                                        ▼
        │                          ┌─────────────────────────┐
        │                          │ Azure DI Extraction      │
        │                          │ Model: CS-Smart-...      │
        │                          │ Output: fields           │
        │                          │   - Bank Account No.     │
        │                          │   - Amount               │
        │                          │   - Date                 │
        │                          └─────────────────────────┘
        │                                        │
        └─── Transaction Type = "Single" ────────┤
                                                 ▼
                                    ┌─────────────────────────┐
                                    │ SingleTransactionForm   │
                                    │ Mapper                   │
                                    │                          │
                                    │ 1. Extract Bank Account  │
                                    │ 2. Lookup Bank_Codes.json│
                                    │ 3. Match "8891017564"    │
                                    │    → LHBANK, 073         │
                                    │ 4. Create Transaction    │
                                    │    Record                │
                                    └─────────────────────────┘
```

---

## Checklist

| # | Task | File/Location | Required? |
|---|------|---------------|-----------|
| 1 | สร้าง Extraction Model | Azure DI Studio | ✅ ต้องทำ |
| 2 | Train Classifier ให้รู้จัก class ใหม่ | Azure DI Studio | ✅ ต้องทำ |
| 3 | เพิ่ม entry ใน model_ids.json | `Config/ocr_config/model_ids.json` | ✅ ต้องทำ |
| 4 | เพิ่มเลขบัญชี (ถ้ามีใหม่) | `Config/mapping_config/Bank_Codes.json` | ❓ ถ้ามีบัญชีใหม่ |
| 5 | ทดสอบ | ส่ง sample document | ✅ ต้องทำ |

---

## สิ่งที่ไม่ต้องทำ

- ❌ ไม่ต้องแก้ code Python
- ❌ ไม่ต้องสร้าง Mapper ใหม่ (ใช้ `SingleTransactionFormMapper` ที่มีอยู่)
- ❌ ไม่ต้องสร้าง schema file ใน `multiple_OCR/` (เพราะเป็น Single ไม่ใช่ Multiple)
- ❌ ไม่ต้องแก้ `config.cfg`

---

## ตัวอย่าง: model_ids.json (ปัจจุบัน)

```json
{
    "KBANK Multiple": ["CS-Smart-reconcile-KBank-Multiple-Pay-In", "Multiple"],
    "SCB Multiple": ["CS-Smart-reconcile-SCB-Multiple-Pay-In", "Multiple"],
    "BBL Multiple": ["CS-Smart-reconcile-BBL-Multiple-Pay-In-2", "Multiple"],
    "BBL Single": ["CS-Smart-reconcile-BBL-Single-Pay-In", "Single"],
    "LHBANK Single": ["CS-Smart-reconcile-LHBANK-Single-Pay-In", "Single"],
    "KTB Multiple": ["CS-Smart-reconcile-KTB-Multiple-Pay-In", "Multiple"],
    "KKP Multiple": ["CS-Smart-reconcile-KKP-Multiple-Pay-In", "Multiple"],
    "BAY Multiple": ["CS-Smart-reconcile-BAY-Multiple-Pay-In", "Multiple"],
    "GSB Multiple": ["CS-Smart-reconcile-GSB-Multiple-Pay-In-20260128", "Multiple"],
    "UOB Single": ["CS-Smart-reconcile-UOB-Single-Pay-In", "Single"],
    "Slip": ["CS-Smart-reconcile-PromptPay-Slip", "Slip"],
    "Doc_Classifier": "CS-Smart-Reconcile-Classification-20260127"
}
```

---

## หมายเหตุสำคัญ

1. **ชื่อ class ใน Classifier ต้องตรงกับ key ใน model_ids.json**
   - ถ้า Classifier output = `"LHBank Single"`
   - model_ids.json ต้องมี key = `"LHBank Single"`

2. **Transaction Type กำหนด Mapper**
   - `"Single"` → `SingleTransactionFormMapper`
   - `"Multiple"` → `MultipleTransactionFormMapper`
   - `"Slip"` → `SlipTransactionFormMapper`

3. **Field names ใน Extraction Model ต้องตรงกับที่ Mapper คาดหวัง**
   - SingleTransactionFormMapper ต้องการ: `Bank Account No.`, `Amount`, `Date`
   - ถ้า LHBank form มี field names ต่าง ต้อง label ให้ตรงกัน
