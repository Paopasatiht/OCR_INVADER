# Functions/mappers/multiple_transaction_OCR.py
from __future__ import annotations

from typing import Any, Dict, List, Tuple, Optional
import logging
from pathlib import Path
import json
import configparser
import re

from Functions.mappers.base import TransactionRecord, TransactionFormMapper, DateNormOptions
# import helpers
from Functions.mappers.helpers import (
    extract_agent_from_path,
    map_account_number,
    normalize_transaction_amount,
    normalize_date,
    load_shared_bank_codes,
    load_shared_agent_names,
    to_optional_bool,
    to_int,
    to_bool,
    to_locale
    )

def _get_field_value_string(fields: Dict[str, Any], key: str) -> str:
    """Safely get valueString from fields[key] if present; supports Date (string), Date(valueDate)."""
    v = fields.get(key) or {}
    # Prefer valueString; fall back to valueDate or content
    return (
        v.get("valueString")
        or v.get("valueDate")
        or v.get("content")
        or ""
    )

def _obj_get_string(row_obj: Dict[str, Any], key: str) -> str:
    """Safely get valueString/content from a row's valueObject[key]."""
    v = row_obj.get(key) or {}
    return (
        v.get("valueString")
        or v.get("content")
        or ""
    )

def _normalize_key(s: str) -> str:
    """Lowercase and strip non-alphanumerics for loose key matching."""
    return re.sub(r"[^a-z0-9]+", "", (s or "").lower())

def _find_obj_value_by_schema_key(row_obj: Dict[str, Any], schema_key: str) -> str:
    """
    Try exact key match, else case-insensitive/normalized partial match
    between schema_key and keys in row_obj.
    Returns empty string if not found.
    """
    if not schema_key:
        return ""
    # 1) Exact match
    if schema_key in row_obj:
        return _obj_get_string(row_obj, schema_key)

    # 2) Normalized partial match (e.g., 'credit' -> 'Credit amount')
    target_norm = _normalize_key(schema_key)
    for k in row_obj.keys():
        if target_norm and target_norm in _normalize_key(k):
            val = _obj_get_string(row_obj, k)
            if val:
                return val
    return ""

def _row_matches_filter(
    row_obj: Dict[str, Any],
    row_filter: Dict[str, Any]
) -> bool:
    if not row_filter or not row_filter.get('enabled', False):
        return True
    
    column = row_filter.get('column', "")
    match_type = row_filter.get('match_type', 'contains')
    keywords =  row_filter.get('keywords', [])
    case_sensitive = row_filter.get('case_sensitive', False)

    if not column or not keywords:
        return True
    
    cell_value = _find_obj_value_by_schema_key(row_obj, column)

    compare_value = cell_value if case_sensitive else cell_value.lower()
    compare_keywords = keywords if case_sensitive else [k.lower() for k in keywords]

    for keyword in compare_keywords:
        if match_type == "exact":
            if compare_value == keyword:
                return True
        elif match_type == "startswith":
            if compare_value.startswith(keyword):
                return True
        elif match_type == "regex":
            if re.search(keyword, compare_value):
                return True
        else:
            if keyword in compare_value:
                return True
    return False


def _extract_value(schema_fixed_values: Dict[str, Any], schema_columns: Dict[str, Any], fields: Dict[str, Any], value_key: str, row_obj: Dict[str, Any]) -> str:
    """
    If schema defines 'cells' (e.g., {'date': 'Date'}), it indicates that this value_key uses fixed value (e.g., fields['Date']).
    Otherwise try row_obj['Value date'] or row_obj['Date'] (valueString/content).
    """
    schema_key = (schema_fixed_values or {}).get(value_key)
    if schema_key:
        return _get_field_value_string(fields, schema_key)  # e.g., 'Date'
    # fallback to table row fields, or even empty if that fails to
    else:
        schema_key = (schema_columns or {}).get(value_key)
        return (
            _find_obj_value_by_schema_key(row_obj, schema_key)
        )


def find_schema_file(base_path: Path, class_name: str, table_type: str) -> Optional[Path]:
    """
    Searches under: base_path / class_name
    Tries multiple filename strategies:
      - Exact: <table_type>.json
      - Sanitized: spaces -> underscores, lowercased
      - Numeric suffix only: e.g., '...Type 3' -> '3.json'
    """
    search_root = base_path / class_name
    if not search_root.exists():
        return None

    candidates = []

    # 1) Exact
    candidates.append(f"{table_type}.json")

    # 2) Sanitized
    sanitized = re.sub(r"\s+", "_", table_type).strip()
    candidates.append(f"{sanitized}.json")
    candidates.append(f"{sanitized.lower()}.json")

    # 3) Numeric suffix
    m = re.search(r'(\d+)$', table_type)
    if m:
        candidates.append(f"{m.group(1)}.json")

    # Search for any candidate via rglob
    try:
        for cand in candidates:
            for file in search_root.rglob(cand):
                if file.exists():
                    return file
    except Exception:
        return None

    # Fallback: scan all jsons and pick one whose stem equals normalized table_type
    target_norm = _normalize_key(table_type)
    try:
        for file in search_root.rglob("*.json"):
            if _normalize_key(file.stem) == target_norm:
                return file
    except Exception:
        pass



def load_schema(base_path: Path, class_name: str, table_type: str) -> Dict[str, Any]:
    """
    Loads the JSON schema file as a dict. Expected top-level key 'schemas' (list).
    Raises FileNotFoundError if not found.
    """
    schema_file = find_schema_file(base_path, class_name, table_type)
    if not schema_file or not schema_file.exists():
        raise FileNotFoundError(
            f"Schema file not found for class='{class_name}', table_type='{table_type}'"
        )
    with open(schema_file, "r", encoding="utf-8") as f:
        return json.load(f)
    


def detect_table_type(fields: dict) -> str:
    """
    Returns the key name whose value has a non-empty 'valueArray'.
    Ignores 'Date'. If none found, returns ''.
    """
    for key, val in fields.items():
        if key == "Date":
            continue
        if isinstance(val, dict) and val.get("valueArray"):
            return key
    return ""



class MultipleTransactionFormMapper(TransactionFormMapper):
    """
    Maps OCR results for single-transaction pay-in forms to TransactionRecord(s).
    Expects extraction_results['extraction_results']['Single'] to be a list of items.
    """

    def __init__(self, config_path: Path, log: logging.Logger):
        self.config_path = config_path
        self.log = log
        cfg = configparser.ConfigParser()
        cfg.read(str(config_path))
        # Allow override via config. Defaults to "Config/mapping_config/other_excels"
        self.schema_root_dir = Path(
            cfg.get("Local_Paths", "multiple_OCR_mapping_schema_dir",
                    fallback="Config/mapping_config/multiple_OCR")
        )

        # Shared JSONs (available for account parsing & agent naming)
        self.bank_codes_mapping = load_shared_bank_codes(config_path, log)
        self.agent_names_mapping = load_shared_agent_names(config_path, log)


    def map(self, extraction_results: Dict[str, Any]) -> Tuple[List[TransactionRecord], List[Dict[str,Any]]]: # also return failed files list

        failed_files: List[Dict[str,Any]] = []

        multiple_items = (
            extraction_results.get('extraction_results', {})
                              .get('Multiple', [])
        )
        self.log.info("Processing %d 'Multiple' items.", len(multiple_items))

        records: List[TransactionRecord] = []
        missing_account_map = 0
        missing_fields = 0
        
        for idx, item in enumerate(multiple_items, start=1):
            try:
                # ---- Agent: derive from file path (fallback-safe) ----
                file_path = item.get("file_path")
                page_num = item.get("page_num")
                if not file_path:
                    # Defensive: navigate analyze_result/documents[] safely
                    analyze_result = item.get("analyze_result", {})
                    documents = analyze_result.get("documents") or []
                    doc0 = documents[0] if documents else {}
                    file_path = doc0.get("docPath", "")
                agent = extract_agent_from_path(
                    path_str = file_path, 
                    agent_map = self.agent_names_mapping) or ""

                # ---- Fields from OCR (defensive access) ----
                analyze_result = item.get("analyze_result", {})
                documents = analyze_result.get("documents") or []
                fields = (documents[0].get("fields", {}) if documents else {})

                # ---- This is multiple transaction doc, first, select the correct mapping schema setting based on bank and table type ----
                class_name = item.get("doc_type", None)
                table_type = detect_table_type(fields)
                
                # Initialize to avoid scope surprises later
                schema_fixed_values: Dict[str, Any] = {}
                schema_columns: Dict[str, Any] = {}

                # Guard: missing doc_type or table_type
                if not class_name or not table_type:
                    self.log.warning(
                        "Missing schema identifier (class/table_type) for item %d. class='%s', table_type='%s'",
                        idx, class_name, table_type
                    )
                    fail_payload = {"file_path": file_path, "reason": "Missing schema identifier"}
                    if page_num:
                        fail_payload["page_num"] = page_num
                    failed_files.append(fail_payload)
                    # Skip this item
                    continue


                try:
                    # Load the JSON file for this class/table_type
                    mapping_schema = load_schema(self.schema_root_dir, class_name, table_type)

                    # Expect structure: {"schemas": [ { "mapping_config": { "cells": {...}, "columns": {...} } } ]}
                    schemas = mapping_schema.get("schemas", [])
                    if not isinstance(schemas, list) or not schemas:
                        raise FileNotFoundError(
                            f"No 'schemas' array inside JSON for class='{class_name}', table_type='{table_type}'"
                        )

                    first_entry = schemas[0] or {}
                    mapping_config = first_entry.get("mapping_config", {}) or {}

                    #   - 'cells'  => fixed values applied to all rows in the item
                    #   - 'columns' => per-row column mappings
                    schema_fixed_values = mapping_config.get("cells", {}) or {}
                    schema_columns = mapping_config.get("columns", {}) or {}


                    row_filter = mapping_config.get("row_filter", {}) or {}

                    # ---------------- Date normalization options (schema-driven) ----------------
                    schema_other_options = mapping_config.get("other_settings", {}) or {}

                    # Determine defaults from your dataclass (for clarity; you could hardcode too)
                    _default = DateNormOptions()
                    prefer_buddhist_shorthand = to_optional_bool(
                        schema_other_options.get("prefer_buddhist_shorthand", None)
                    )
                    pivot_offset = to_int(
                        schema_other_options.get("pivot_offset", _default.pivot_offset),
                        _default.pivot_offset
                    )
                    buddhist_proximity_window = to_int(
                        schema_other_options.get("buddhist_proximity_window", _default.buddhist_proximity_window),
                        _default.buddhist_proximity_window
                    )
                    assume_day_first = to_bool(
                        schema_other_options.get("assume_day_first", _default.assume_day_first),
                        _default.assume_day_first
                    )
                    locale_hint = to_locale(schema_other_options.get("locale_hint", _default.locale_hint))

                    
                    # Optional: inferred tweaks—if locale_hint is 'th' but assume_day_first missing, enforce True
                    if schema_other_options.get("assume_day_first") is None and locale_hint == "th":
                        assume_day_first = True

                    options = DateNormOptions(
                        prefer_buddhist_shorthand=prefer_buddhist_shorthand,
                        pivot_offset=pivot_offset,
                        buddhist_proximity_window=buddhist_proximity_window,
                        assume_day_first=assume_day_first,
                        locale_hint=locale_hint
                    )

                    self.log.info(
                        "Loaded multiple-OCR mapping_config for class='%s', table_type='%s'. fixed=%d, columns=%d",
                        class_name, table_type, len(schema_fixed_values), len(schema_columns)
                    )


                except FileNotFoundError as e:
                    self.log.exception("No schema found for item %d: %s", idx, e)
                    fail_payload = {
                        "file_path": file_path,
                        "reason": "No schema found"
                    }
                    if page_num:
                        fail_payload["page_num"] = page_num
                    failed_files.append(fail_payload)
                    # Skip this item
                    continue

                
                # ---- Load the table (valueArray of objects) ----
                table: list = (fields.get(f"{table_type}", {}) or {}).get("valueArray", []) or []
                if not isinstance(table, list) or not table:
                    self.log.warning("No rows found for table '%s' (item %d).", table_type, idx)
                    fail_payload = {"file_path": file_path, "reason": "Empty table"}
                    if page_num:
                        fail_payload["page_num"] = page_num
                    failed_files.append(fail_payload)
                    # Skip this item
                    continue


                # Iterate each row entry in table
                for r_index, row_entry in enumerate(table, start=1):
                    try:
                        row_obj: Dict[str, Any] = (row_entry.get("valueObject") or {})

                        if not _row_matches_filter(row_obj, row_filter):
                            self.log.debug(
                                "Row %d skipped by filter (item %d): column='%s'",
                                r_index, idx, row_filter.get('column', "")
                            )
                            continue
                
                        # ---- Extract item/row ----
                        raw_acc = _extract_value(schema_fixed_values, schema_columns, fields, 'to_account', row_obj)
                        raw_amount = _extract_value(schema_fixed_values, schema_columns, fields, 'amount', row_obj)
                        raw_date = _extract_value(schema_fixed_values, schema_columns, fields, 'date', row_obj)

                        # ---- Normalize per your existing helpers ----
                        amount = normalize_transaction_amount(raw_amount)
                        
                        date   = normalize_date(raw_date, options=options)

                        # ---- Map Bank Account No & Code ----
                        mapped: Optional[Tuple[str, str, str]] = map_account_number(raw_acc, self.bank_codes_mapping)
                        if mapped:
                            bank_code, bank_name, normalized_acc = mapped
                            bank_account_no_fmt = f"{bank_code} {bank_name} {normalized_acc}"
                        else:
                            bank_code = ""
                            bank_account_no_fmt = ""
                            missing_account_map += 1
                            self.log.warning("Unmapped account (item %d, row %d): raw='%s'", idx, r_index, raw_acc)

                        # ---- Payment Type ----
                        payment_type = "C"  # Pay-in form (Non-slip)

                        # Debug: log missing key fields
                        if not agent or not raw_acc or not raw_amount or not raw_date:
                            missing_fields += 1
                            self.log.debug(
                                "Item %d row %d has missing fields: agent='%s', acc='%s', amount='%s', date='%s'",
                                idx, r_index, agent, raw_acc, raw_amount, raw_date
                            )

                        # ---- Append TransactionRecord for this row ----
                        records.append(
                            TransactionRecord(
                                agent=agent,
                                payment_type=payment_type,
                                bank_code=f"{bank_code}",
                                bank_account_no_fmt=bank_account_no_fmt,
                                amount=amount,
                                date=date,
                                source_kind="Multiple",
                                source_file=file_path
                                )
                            )

                    except Exception as rexc:
                        self.log.exception("Failed to process item %d row %d: %s", idx, r_index, rexc)
                        fail_payload = {"file_path": file_path, "row": r_index, "reason": "Row processing failed"}
                        if page_num:
                            fail_payload["page_num"] = page_num
                        failed_files.append(fail_payload)
                        # Continue to next row
                        continue

            except Exception as e:
                self.log.exception("Failed to process item %d: %s", idx, e)
                failed_files.append({
                    "file_path":file_path,
                    "page_num": page_num,
                    "reason": "Item processing failed"
                    })

        self.log.info("Completed items: %d, unmapped accounts: %d, items with missing fields: %d",
                      len(multiple_items), missing_account_map, missing_fields)
        return records, failed_files
    
    
