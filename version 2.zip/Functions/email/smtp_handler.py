# Functions/email/smtp_handler.py
# -*- coding: utf-8 -*-
from __future__ import annotations

import os
import time
import smtplib
import mimetypes
import configparser
from pathlib import Path
from typing import List, Optional, Dict, Any, Tuple
from email.message import EmailMessage
from string import Template
import logging
import pandas as pd


DEFAULT_RETRY_TOTAL = 3
DEFAULT_BACKOFF_BASE = 1.0  # seconds


def _load_email_config(config_path: Path, log: logging.Logger) -> Dict[str, Any]:
    """
    Load Email settings from Config/config.cfg. Expected section:
      [Email]
      sender_email = ...
      smtp_server  = ...
      smtp_port    = 587
      username     = ...
      password     = ...
    """
    cfg = configparser.ConfigParser()
    read_ok = cfg.read(config_path)
    if not read_ok:
        log.error("Email config not found or failed to read: %s", config_path)
        raise FileNotFoundError(f"Email config missing: {config_path}")

    if not cfg.has_section("Email"):
        log.error("Email section missing in config: %s", config_path)
        raise KeyError("Missing [Email] section in config")

    email_cfg = {
        "sender_email": cfg.get("Email", "sender_email", fallback=None),
        "smtp_server":  cfg.get("Email", "smtp_server",  fallback=None),
        "smtp_port":    cfg.getint("Email", "smtp_port", fallback=25),
    }
    missing = [k for k, v in email_cfg.items() if v is None and k in ("sender_email", "smtp_server")]
    if missing:
        log.error("Required Email config missing keys: %s", ", ".join(missing))
        raise ValueError(f"Missing required Email config keys: {missing}")

    return email_cfg


def _key_to_title(key: str) -> str:
    """
    Convert a result key like 'failed_OCR_classification_files' into a
    readable Title-Case label: 'Failed OCR Classification Files'.
    """
    if not key:
        return "Sheet"
    # Replace underscores with spaces, then title-case
    pretty = key.replace("_", " ").strip()
    # Keep acronyms readable: OCR -> OCR, PDF -> PDF
    pretty = pretty.replace("Ocr", "OCR").replace("Pdf", "PDF")
    return pretty.title()


def _safe_sheet_name(name: str) -> str:
    """
    Excel sheet names must be <= 31 chars and cannot contain some characters.
    This trims and sanitizes while keeping names recognizable.
    """
    name = (name or "Sheet").replace("/", "_").replace("\\", "_").replace(":", "_").replace("?", "_").replace("*", "_").replace("[", "(").replace("]", ")")
    return name[:31]


def _as_dataframe(records: Any) -> pd.DataFrame:
    """
    Robustly convert a list/dict/DataFrame into a DataFrame.
    If empty or unsupported, return a placeholder row.
    """
    try:
        if isinstance(records, pd.DataFrame):
            df = records.copy()
        elif isinstance(records, list):
            if records and isinstance(records[0], dict):
                df = pd.DataFrame(records)
            else:
                df = pd.DataFrame({"Items": records})
        elif isinstance(records, dict):
            df = pd.DataFrame([records])
        else:
            df = pd.DataFrame({"Info": [str(records)]})
    except Exception:
        df = pd.DataFrame({"Info": ["Unable to serialize"]})

    if df.empty:
        df = pd.DataFrame({"Info": ["No records"]})
    return df


def _build_summary_excel(
    extraction_results: Dict[str, Any],
    output_dir: Path,
    log: logging.Logger,
    failure_keys: List[str],
    success_key: str,
) -> Path:
    """
    Build a unified summary.xlsx with N+1 sheets:
      - One sheet per provided failure key
      - One sheet for the provided success key
      - Plus a 'Dashboard' sheet with counts (always included)

    Always created, even if all lists are empty.
    """
    output_dir.mkdir(parents=True, exist_ok=True)
    summary_path = output_dir / "run_summary.xlsx"

    # Build the plan dynamically from arguments (no hardcoding).
    # Pair each key with its data.
    keyed_data: List[Tuple[str, Any]] = []
    keyed_data.append((success_key, extraction_results.get(success_key, [])))
    for key in failure_keys:
        keyed_data.append((key, extraction_results.get(key, [])))
    

    # Prepare dashboard counts
    dashboard_rows = []
    for key, data in keyed_data:
        try:
            count = len(data) if hasattr(data, "__len__") else 1
        except Exception:
            count = 0
        dashboard_rows.append({
            "Category": _key_to_title(key),
            "Key": key,
            "Items": count,
        })
    dashboard_df = pd.DataFrame(dashboard_rows)

    with pd.ExcelWriter(summary_path, engine="openpyxl") as writer:
        # 1) Dashboard first
        dashboard_df.to_excel(writer, index=False, sheet_name=_safe_sheet_name("Dashboard"))

        # 2) Each category sheet
        for key, data in keyed_data:
            sheet_title = _key_to_title(key)
            safe_name = _safe_sheet_name(sheet_title)
            df = _as_dataframe(data)

            # Column ordering hint: move common fields up front if present
            preferred_cols = [c for c in ["file_path", "page_num", "error_reason", "error", "doc_type", "model_id"] if c in df.columns]
            other_cols = [c for c in df.columns if c not in preferred_cols]
            df = df[preferred_cols + other_cols] if preferred_cols else df

            df.to_excel(writer, index=False, sheet_name=safe_name)

    log.info("Summary Excel written: %s", summary_path)
    return summary_path
   

# =====================================================================================
# _build_flat_summary_excel - สร้าง summary Excel แบบ flat (1 sheet)
# =====================================================================================
def _build_flat_summary_excel(
    extraction_results: Dict[str, Any],
    output_dir: Path,
    log: logging.Logger,
    config_path: Optional[Path] = None,
) -> Path:
    """
    สร้าง summary Excel แบบ flat - รวมทุกไฟล์ใน 1 sheet

    Columns: Agent | File | File Path | Status | Error | Doc Type

    Status: สำเร็จ / ผิดพลาด (เท่านั้น)
    Error: รวม Error Code + Description (ว่าง = สำเร็จ)

    Args:
        extraction_results: Dict ของ extraction results
        output_dir: Directory สำหรับ save Excel
        log: Logger
        config_path: Path to config.cfg (for agent names)

    Returns:
        Path ไปยัง Excel file ที่สร้าง
    """
    from pathlib import Path as PathLib
    from datetime import datetime
    from Functions.error_codes import format_error_for_summary

    # Load agent names mapping (optional)
    agent_names_mapping = {}
    try:
        if config_path:
            from Functions.mappers.helpers import load_shared_agent_names
            agent_names_mapping = load_shared_agent_names(config_path, log)
    except Exception as e:
        log.warning("Could not load agent names: %s", e)

    # Helper: extract agent from file path
    def get_agent(file_path: str) -> str:
        """ดึงชื่อ Agent จาก file path - ถ้าไม่มีใน config แสดง folder name + (ไม่มีใน config)"""
        try:
            from Functions.mappers.helpers import extract_agent_from_path
            agent = extract_agent_from_path(file_path, agent_names_mapping)
            if agent:
                return agent

            # ไม่พบใน config - ดึง folder name แล้วระบุว่าไม่มีใน config
            parts = PathLib(file_path).parts
            for i, part in enumerate(parts):
                if part.lower() in ("input", "inputs", "download"):
                    if i + 1 < len(parts):
                        folder_name = parts[i + 1]
                        return f"{folder_name} (ไม่มีใน config)"
            return "Unknown"
        except Exception:
            # Fallback: ใช้ folder name
            parts = PathLib(file_path).parts
            for i, part in enumerate(parts):
                if part.lower() in ("input", "inputs", "download"):
                    if i + 1 < len(parts):
                        folder_name = parts[i + 1]
                        return f"{folder_name} (ไม่มีใน config)"
            return "Unknown"

    # Helper: get file name from path
    def get_filename(file_path: str) -> str:
        return PathLib(file_path).name if file_path else ""

    # -----------------------------------------------------------------
    # รวบรวมทุกไฟล์เป็น flat list
    # -----------------------------------------------------------------
    all_records = []

    # 1. Success files
    for item in extraction_results.get("overall_success_files", []):
        file_path = item.get("file_path", "") if isinstance(item, dict) else str(item)
        doc_type = item.get("doc_type", "") if isinstance(item, dict) else ""
        all_records.append({
            "Agent": get_agent(file_path),
            "File": get_filename(file_path),
            "File Path": file_path,
            "Status": "สำเร็จ",
            "Error": "",  # ว่าง = สำเร็จ
            "Doc Type": doc_type,
            "_file_path": file_path,  # เก็บไว้สำหรับ sorting
        })

    # 2. Skipped files (zip, unsupported)
    for item in extraction_results.get("skipped_files", []):
        file_path = item.get("file_path", "") if isinstance(item, dict) else str(item)
        all_records.append({
            "Agent": get_agent(file_path),
            "File": get_filename(file_path),
            "File Path": file_path,
            "Status": "ผิดพลาด",
            "Error": format_error_for_summary("skipped", item),
            "Doc Type": "",
            "_file_path": file_path,
        })

    # 3. Error files - ทุกประเภท error = ผิดพลาด
    # (key, category_for_error_code)
    error_sources = [
        ("encrypted_pdf_files", "encrypted_pdf"),
        ("failed_OCR_classification_files", "classification_failed"),
        ("failed_OCR_extraction_files", "extraction_failed"),
        ("unknown_or_unused_from_azure", "unknown"),
        ("failed_mapping_files", "mapping_failed"),
    ]

    for key, category in error_sources:
        for item in extraction_results.get(key, []):
            file_path = item.get("file_path", "") if isinstance(item, dict) else str(item)
            doc_type = item.get("doc_type", "") if isinstance(item, dict) else ""

            all_records.append({
                "Agent": get_agent(file_path),
                "File": get_filename(file_path),
                "File Path": file_path,
                "Status": "ผิดพลาด",
                "Error": format_error_for_summary(category, item),
                "Doc Type": doc_type,
                "_file_path": file_path,
            })

    # -----------------------------------------------------------------
    # สร้าง DataFrame และ sort
    # -----------------------------------------------------------------
    if not all_records:
        all_records.append({
            "Agent": "-",
            "File": "-",
            "File Path": "-",
            "Status": "ไม่มีไฟล์",
            "Error": "No files processed",
            "Doc Type": "",
            "_file_path": "",
        })

    df = pd.DataFrame(all_records)

    # Sort by Agent, then by status (สำเร็จ first), then by file
    status_order = {"สำเร็จ": 0, "ผิดพลาด": 1, "ไม่มีไฟล์": 2}
    df["_status_order"] = df["Status"].map(status_order).fillna(9)
    df = df.sort_values(["Agent", "_status_order", "File"])

    # ลบ columns ที่ใช้สำหรับ sorting
    df = df.drop(columns=["_file_path", "_status_order"])

    # -----------------------------------------------------------------
    # เขียน Excel
    # -----------------------------------------------------------------
    output_dir.mkdir(parents=True, exist_ok=True)
    summary_path = output_dir / "run_summary.xlsx"

    with pd.ExcelWriter(summary_path, engine="openpyxl") as writer:
        df.to_excel(writer, index=False, sheet_name="Summary")

        # Optional: เพิ่ม formatting
        workbook = writer.book
        worksheet = writer.sheets["Summary"]

        # ปรับ column width
        worksheet.column_dimensions["A"].width = 35  # Agent
        worksheet.column_dimensions["B"].width = 30  # File
        worksheet.column_dimensions["C"].width = 50  # File Path
        worksheet.column_dimensions["D"].width = 12  # Status
        worksheet.column_dimensions["E"].width = 60  # Error
        worksheet.column_dimensions["F"].width = 20  # Doc Type

    log.info("Flat summary Excel written: %s (%d records)", summary_path, len(df))
    return summary_path




def _extract_agents_from_files(
        success_files: List[Dict[str, Any]],
        agent_names_mapping: Dict[str, str],
) -> set:
    
    from Functions.mappers.helpers import extract_agent_from_path

    agents = set()
    for item in success_files:
        file_path = item.get("file_path", "")
        if file_path:
            agent = extract_agent_from_path(file_path, agent_names_mapping)
            if agent:
                agents.add(agent)
    return agents

def _build_thai_plain_text_body(
        extraction_results: Dict[str, Any],
        log: logging.Logger,
        config_path: Optional[Path] = None,
) -> str:
    from datetime import datetime
    from pathlib import Path

    success_files = extraction_results.get("overall_success_files", [])
    total_success = len(success_files)

    encrypted_pdf_files = extraction_results.get("encrypted_pdf_files", [])
    failed_OCR_classification_files = extraction_results.get("failed_OCR_classification_files", [])
    failed_OCR_extraction_files = extraction_results.get("failed_OCR_extraction_files", [])
    unknown_or_unused_from_azure = extraction_results.get("unknown_or_unused_from_azure", [])
    failed_mapping_files = extraction_results.get("failed_mapping_files", [])

    total_encrypted = len(encrypted_pdf_files)
    total_classify_failed = len(failed_OCR_classification_files)
    total_extraction_failed = len(failed_OCR_extraction_files)
    total_unknown = len(unknown_or_unused_from_azure)
    total_mapping_failed = len(failed_mapping_files)

    total_failed = (
        total_encrypted + total_classify_failed + total_extraction_failed + total_unknown + total_mapping_failed
    )

    total_files = total_success + total_failed

    success_rate = (total_success / total_files * 100) if total_files > 0 else 0.0

    active_agents = set()
    try: 
        if config_path:
            from Functions.mappers.helpers import load_shared_agent_names
            agent_names_mapping = load_shared_agent_names(config_path, log)
            active_agents = _extract_agents_from_files(success_files, agent_names_mapping)
    except Exception as e:
        log.warning("Could not extract agents: %s", e)

    total_active_agents = len(active_agents)

    success_by_kind = extraction_results.get("successful_mapping_files_by_kind", {})
    single_count = len(success_by_kind.get("Single", []))
    multiple_count = len(success_by_kind.get("Multiple", []))
    slip_count = len(success_by_kind.get("Slip", []))
    excel_count = len(success_by_kind.get("Excel", []))
    finnet_count = len(success_by_kind.get("FINNET", []))

    if extraction_results.get("status") == "sharepoint_failed":
        status_thai = "Sharepoint ผิดพลาด"
        status_icon = "❌"
    elif total_failed == 0 and total_success == 0:
        status_thai = "ไม่มีไฟล์ที่สามารถประมวลผลได้"
        status_icon = "⚠️"
    elif total_failed == 0 and total_success > 0:
        status_thai = "ประมวลผลสำเร็จทั้งหมด"
        status_icon = "✅"
    elif total_failed > 0 and total_success > 0:
        status_thai = "ประมวลผลสำเร็จบางส่วน"
        status_icon = "⚠️"
    else:
        status_thai = "ล้มเหลวทั้งหมด"
        status_icon = "❌"

    # Email Body
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    lines = []

    lines.append("=" * 50)
    lines.append(f"รายงานผลการประมวลผลเอกสาร OCR")
    lines.append("=" * 50)
    lines.append("")
    lines.append(f"วันที่ประมวลผล: {timestamp}")
    lines.append(f"สถานะ: {status_icon} {status_thai}")
    lines.append("")

    lines.append("=" * 50)
    lines.append("สรุปภาพรวม")
    lines.append("=" * 50)
    lines.append(f"จำนวนไฟล์ทั้งหมด ที่ประมวลผลวันนี้: {total_files} ไฟล์")
    lines.append(f"จำนวน Agent ที่มีรายการวันนี้: {total_active_agents} Agent")
    lines.append("")

    lines.append("=" * 50)
    lines.append(f"ไฟล์ที่ประมวลผลสำเร็จ: {total_success} ไฟล์")
    lines.append("=" * 50)
    if total_success > 0:
        if single_count > 0:
            lines.append(f"- Single: {single_count} ไฟล์")
        if multiple_count > 0:
            lines.append(f"- Multiple: {multiple_count} ไฟล์")
        if slip_count > 0:
            lines.append(f"- Slip: {slip_count} ไฟล์")
        if excel_count > 0:
            lines.append(f"- Excel: {excel_count} ไฟล์")
        if finnet_count > 0:
            lines.append(f"- FINNET: {finnet_count} ไฟล์")
    else:
        lines.append("ไม่มีไฟล์ที่ประมวลผลสำเร็จ")
    lines.append("")

    lines.append("=" * 50)
    lines.append(f"ไฟล์ที่ประมวลผลไม่สำเร็จ: {total_failed} ไฟล์")
    lines.append("=" * 50)
    if total_failed > 0:
        if total_encrypted > 0:
            lines.append(f"- ไฟล์ PDF มีรหัสผ่าน เข้าไม่ได้: {total_encrypted} ไฟล์")
        if total_classify_failed > 0:
            lines.append(f"- ไฟล์ที่ไม่ผ่านการจำแนกประเภท OCR: {total_classify_failed} ไฟล์")
        if total_extraction_failed > 0:
            lines.append(f"- ไฟล์ที่ไม่สามารถสกัดข้อมูล OCR ได้: {total_extraction_failed} ไฟล์")
        if total_unknown > 0:
            lines.append(f"- ไฟล์ที่ไม่รู้จักหรือไม่ได้ใช้จาก Azure: {total_unknown} ไฟล์")
        if total_mapping_failed > 0:
            lines.append(f"- ไฟล์ที่แมปข้อมูลไม่สำเร็จ: {total_mapping_failed} ไฟล์")
    else:
        lines.append("ไม่มีไฟล์ที่ประมวลผลไม่สำเร็จ")
    lines.append("")

    lines.append("=" * 50)
    lines.append("สถิติ")
    lines.append("=" * 50)
    lines.append(f"อัตราความสำเร็จ: {success_rate:.2f}%")
    lines.append(f"success / all: {total_success}/{total_files} ไฟล์")
    lines.append("")

    if active_agents:
        lines.append("=" * 50)
        lines.append("Agent ที่มีรายการวันนี้")
        lines.append("=" * 50)
        for i, agent in enumerate(sorted(active_agents), start=1):
            lines.append(f"{i}. {agent}")
        lines.append("")
    
    lines.append("=" * 50)
    lines.append("ดูรายละเอียดเพิ่มเติมได้ที่ run_summary.xlsx ที่แนบมา")
    lines.append("=" * 50)
    lines.append("")
    lines.append("OCR System")

    body = "\n".join(lines)
    log.info("built thai plain text email body %d characters,  %d agents", len(body), total_active_agents)
    return body

def send_plain_text_email(
    subject: str,
    body_text: str,
    to_emails: List[str],
    log: logging.Logger,
    config_path: Path,
    attachments: Optional[List[Path]] = None,
    cc_emails: Optional[List[str]] = None,
    retry_total: int = DEFAULT_RETRY_TOTAL,
    backoff_base: float = DEFAULT_BACKOFF_BASE,
) -> None:
    """
    ส่ง email แบบ plain text (ไม่ใช่ HTML)

    Args:
        subject: หัวข้อ email
        body_text: เนื้อหา email (plain text)
        to_emails: List ของ email addresses ผู้รับ
        log: Logger
        config_path: Path ไปยัง Config/config.cfg
        attachments: List ของ Paths ที่จะแนบ (optional)
        cc_emails: List ของ CC recipients (optional)
        retry_total: จำนวน retry สูงสุด
        backoff_base: base seconds สำหรับ exponential backoff
    """
    try:
        # โหลด email config
        email_cfg = _load_email_config(config_path, log)

        # สร้าง email message
        msg = EmailMessage()
        msg["Subject"] = subject
        msg["From"] = email_cfg["sender_email"]
        msg["To"] = ", ".join(to_emails)

        # เพิ่ม CC ถ้ามี
        if cc_emails:
            msg["Cc"] = ", ".join(cc_emails)

        # ใส่ body เป็น plain text
        msg.set_content(body_text)

        # แนบไฟล์
        _attach_files(msg, attachments, log)

        # ส่ง email พร้อม retry
        _send_with_retries(
            email_cfg=email_cfg,
            msg=msg,
            log=log,
            retry_total=retry_total,
            backoff_base=backoff_base
        )

    except Exception as e:
        log.exception("Error preparing/sending plain text email: %s", e)
        raise

def _prepare_email_body(
    body_path: Path,
    log: logging.Logger,
) -> str:
    """
    Load an HTML template file and optionally inject a failed-files bullet list
    plus any additional variables via ${var} syntax.
    """
    if not body_path.exists():
        log.error("Email body template not found: %s", body_path)
        raise FileNotFoundError(f"Body template missing: {body_path}")

    with open(body_path, "r", encoding="utf-8") as f:
        body_template = f.read()

    return body_template



def prepare_email_template_and_attachments(
    extraction_results: Dict[str, Any],
    templates_dir: Path,
    output_dir: Path,
    log: logging.Logger
) -> Tuple[Path, List[Path]]:
    """
    Select email template and prepare attachments based on extraction_results.

    Conditions:
    1) If all keys empty -> choose 'no_valid_file.html'
    2) If all except 'overall_success_files' empty -> choose 'success.html'
    3) If any failure keys not empty AND overall_success_files not empty -> choose 'partial_success.html'
    4) If any failure keys not empty AND overall_success_files empty -> choose 'fail.html'

    NEW: Always attach 'summary.xlsx' built from 5 failure keys + 1 success key.
    """

    # --- Keys we include in summary.xlsx ---
    failure_keys = [
        "encrypted_pdf_files",
        "failed_OCR_classification_files",
        "failed_OCR_extraction_files",
        "unknown_or_unused_from_azure",
        "failed_mapping_files",
    ]
    success_key = "overall_success_files"

    failures_exist = any(extraction_results.get(k) for k in failure_keys)
    success_exist = bool(extraction_results.get(success_key))

    # --- Decide template (existing logic unchanged except SharePoint) ---
    if extraction_results.get("status") == "sharepoint_failed":
        template_name = "SharePoint_Fail.html"
        template_path = templates_dir / template_name
        attachments: List[Path] = []

        # Optional Excel with SharePoint error details (unchanged)
        try:
            output_dir.mkdir(parents=True, exist_ok=True)
            excel_path = output_dir / "sharepoint_error_details.xlsx"
            error_data = {
                "SharePoint Error": [extraction_results.get("sharepoint_error", "Unknown error")],
                "Upload Error": [extraction_results.get("sharepoint_upload_error", "None")]
            }
            df = pd.DataFrame(error_data)
            with pd.ExcelWriter(excel_path, engine="openpyxl") as writer:
                df.to_excel(writer, index=False, sheet_name="SharePoint_Failure")
            attachments.append(excel_path)
            log.info("Created SharePoint error details Excel: %s", excel_path)
        except Exception as e:
            log.exception("Failed to create SharePoint error Excel: %s", e)

        # NEW: Also include summary.xlsx even in SharePoint failure case
        try:
            summary_path = _build_summary_excel(
                extraction_results=extraction_results,
                output_dir=output_dir,
                log=log,
                failure_keys=failure_keys,
                success_key=success_key
            )
            attachments.append(summary_path)
            log.info("Created summary Excel: %s", summary_path)
        except Exception as e:
            log.exception("Failed to create summary Excel: %s", e)

        log.info("Selected template: %s", template_path)
        return template_path, attachments

    # --- Non-SharePoint templates ---
    if not failures_exist and not success_exist:
        template_name = "No_Valid_File.html"
    elif not failures_exist and success_exist:
        template_name = "Success.html"
    elif failures_exist and success_exist:
        template_name = "Partial_Success.html"
    else:  # failures_exist and not success_exist
        template_name = "Fail.html"

    template_path = templates_dir / template_name
    attachments: List[Path] = []

    # NEW: Always create and attach summary.xlsx
    try:
        summary_path = _build_summary_excel(
            extraction_results=extraction_results,
            output_dir=output_dir,
            log=log,
            failure_keys=failure_keys,
            success_key=success_key
        )
        attachments.append(summary_path)
        log.info("Created summary Excel: %s", summary_path)
    except Exception as e:
        log.exception("Failed to create summary Excel: %s", e)

    # (Optional) Keep the old failure-only workbook if you still want it; otherwise remove this block.
    # Since you said "no longer want to append failure_files.xlsx only", we remove this block entirely.

    log.info("Selected template: %s", template_path)
    return template_path, attachments


def _attach_files(msg: EmailMessage, attachments: Optional[List[Path]], log: logging.Logger) -> None:
    """
    Attach files to the email with proper MIME types. If type cannot be guessed,
    default to application/octet-stream.
    """
    if not attachments:
        return

    for ap in attachments:
        try:
            if not ap or not Path(ap).exists():
                log.warning("Attachment not found: %s", ap)
                continue

            file_path = Path(ap)
            ctype, encoding = mimetypes.guess_type(str(file_path))
            if ctype is None or encoding is not None:
                ctype = "application/octet-stream"

            maintype, subtype = ctype.split("/", 1)

            with open(file_path, "rb") as f:
                file_data = f.read()

            msg.add_attachment(file_data, maintype=maintype, subtype=subtype, filename=file_path.name)
            log.info("Attached file: %s (%s)", file_path, ctype)
        except Exception as e:
            log.exception("Failed to attach file %s: %s", ap, e)


def _send_with_retries(
    email_cfg: Dict[str, Any],
    msg: EmailMessage,
    log: logging.Logger,
    retry_total: int = DEFAULT_RETRY_TOTAL,
    backoff_base: float = DEFAULT_BACKOFF_BASE,
) -> None:
    """
    Send the email with simple exponential backoff retries for transient SMTP errors.
    """
    attempts = 0
    while True:
        try:
            with smtplib.SMTP(email_cfg["smtp_server"], email_cfg["smtp_port"], timeout=30) as server:
                server.send_message(msg)
                log.info("Email sent successfully to: %s", msg["To"])
                return

        except Exception as e:
            attempts += 1
            log.warning("SMTP send attempt %d/%d failed: %s", attempts, retry_total, e)
            if attempts >= retry_total:
                log.exception("Failed to send email after %d attempts.", attempts)
                raise
            wait = backoff_base * (2 ** (attempts - 1))  # 1, 2, 4, ...
            time.sleep(wait)


def send_email(
    subject: str,
    body_path: Path,
    to_emails: List[str],
    log: logging.Logger,
    config_path: Path,
    attachments: Optional[List[Path]] = None,
    cc_emails: Optional[List[str]] = None,
    bcc_emails: Optional[List[str]] = None,
    retry_total: int = DEFAULT_RETRY_TOTAL,
    backoff_base: float = DEFAULT_BACKOFF_BASE,
) -> None:
    """
    Send an email with optional HTML body, attachments, and dynamic failed file list.
    Matches project patterns (explicit config path, logger, Paths).

    :param subject: Email subject line.
    :param body_path: Path to the HTML template file for the email body.
    :param to_emails: List of recipient email addresses.
    :param log: Project logger.
    :param config_path: Path to Config/config.cfg.
    :param failed_files_list: Optional list of failed files to include in the email body.
    :param attachments: Optional list of file paths to attach (Path objects).
    :param cc_emails: Optional CC recipients.
    :param bcc_emails: Optional BCC recipients.
    :param retry_total: SMTP retry attempts.
    :param backoff_base: Backoff base seconds (exponential).
    :param extra_template_vars: Dict of extra variables to substitute in the HTML template.
    """
    try:
        email_cfg = _load_email_config(config_path, log)

        msg = EmailMessage()
        msg["Subject"] = subject
        msg["From"] = email_cfg["sender_email"]
        msg["To"] = ", ".join(to_emails)
        if cc_emails:
            msg["Cc"] = ", ".join(cc_emails)
        # BCC is not placed in headers that recipients see; handled at send time:
        # We'll merge into envelope later if needed.

        body_html = _prepare_email_body(
            body_path=body_path,
            log=log
        )
        msg.add_alternative(body_html, subtype="html")

        _attach_files(msg, attachments, log)

        # Merge envelope recipients (To + CC + BCC)
        envelope_recipients = list(to_emails or [])
        if cc_emails:
            envelope_recipients.extend(cc_emails)
        if bcc_emails:
            envelope_recipients.extend(bcc_emails)

        # Ensure unique recipients
        envelope_recipients = list(dict.fromkeys(envelope_recipients))

        # Delegating the actual sending with retries
        _send_with_retries(
            email_cfg=email_cfg,
            msg=msg,
            log=log,
            retry_total=retry_total,
            backoff_base=backoff_base
        )

    except Exception as e:
        log.exception("Error preparing/sending email: %s", e)
       

__all__ = [
    "send_email",
    "send_plain_text_email",
    "prepare_email_template_and_attachments",
    "_build_thai_plain_text_body",
    "_build_summary_excel",
]


# =====================================================================================
# _build_smart_reconcile_email_body - สร้าง email body แบบ Smart Reconcile
# =====================================================================================
def _build_smart_reconcile_email_body(
    extraction_results: Dict[str, Any],
    log: logging.Logger,
    config_path: Optional[Path] = None,
    sender_name: str = "ทีมพัฒนา OCR",
) -> str:
    """
    สร้าง email body แบบ OCR Smart Reconcile

    Status มีแค่ 2 ค่า: สำเร็จ (Success) และ ล้มเหลว (Fail)

    Args:
        extraction_results: Dict ของ extraction results
        log: Logger
        config_path: Path to config.cfg (for loading agent names)
        sender_name: ชื่อผู้ส่ง/ทีม

    Returns:
        Tuple[str, str]: (plain text email body, status_text)
    """
    from datetime import datetime
    from pathlib import Path

    # =========================================================================
    # 1. นับจำนวนไฟล์แยกตามหมวดหมู่
    # =========================================================================

    # Success
    success_files = extraction_results.get("overall_success_files", [])
    success_count = len(success_files)

    # Fail (ทุก error รวมกัน)
    encrypted = extraction_results.get("encrypted_pdf_files", [])
    classify_failed = extraction_results.get("failed_OCR_classification_files", [])
    extract_failed = extraction_results.get("failed_OCR_extraction_files", [])
    unknown = extraction_results.get("unknown_or_unused_from_azure", [])
    mapping_failed = extraction_results.get("failed_mapping_files", [])
    skipped = extraction_results.get("skipped_files", [])

    fail_count = (
        len(encrypted) + len(classify_failed) + len(extract_failed) +
        len(unknown) + len(mapping_failed) + len(skipped)
    )

    # Total
    total_files = success_count + fail_count

    # =========================================================================
    # 2. นับ Active Agents
    # =========================================================================
    active_agents = set()
    try:
        if config_path:
            from Functions.mappers.helpers import load_shared_agent_names, extract_agent_from_path
            agent_names_mapping = load_shared_agent_names(config_path, log)

            # นับจากทุกไฟล์ (success + fail)
            all_files = (
                success_files +
                encrypted + classify_failed + extract_failed + unknown +
                mapping_failed + skipped
            )
            for item in all_files:
                file_path = item.get("file_path", "") if isinstance(item, dict) else str(item)
                if file_path:
                    agent = extract_agent_from_path(file_path, agent_names_mapping)
                    if agent:
                        active_agents.add(agent)
    except Exception as e:
        log.warning("Could not extract agents: %s", e)

    active_agent_count = len(active_agents)

    # =========================================================================
    # 3. กำหนดสถานะ (แค่ 2 ค่า: สำเร็จ / ล้มเหลว / สำเร็จบางส่วน / ไม่มีไฟล์)
    # =========================================================================
    if extraction_results.get("status") == "sharepoint_failed":
        status_text = "ล้มเหลว"
    elif fail_count > 0 and success_count == 0:
        status_text = "ล้มเหลว"
    elif fail_count > 0 and success_count > 0:
        status_text = "สำเร็จบางส่วน"
    elif success_count > 0:
        status_text = "สำเร็จ"
    else:
        status_text = "ไม่มีไฟล์"

    # =========================================================================
    # 4. สร้าง Email Body
    # =========================================================================
    date_str = datetime.now().strftime("%d/%m/%Y")

    lines = []

    # --- Greeting ---
    lines.append("เรียน ทีมงานที่เกี่ยวข้อง")
    lines.append("")
    lines.append("ระบบ OCR Smart Reconcile ได้ดำเนินการประมวลผลข้อมูลของวันนี้เสร็จสิ้นแล้ว")
    lines.append("โดยมีสรุปภาพรวมดังนี้ครับ")
    lines.append("")

    # --- Daily Summary ---
    lines.append("📊 สรุปภาพรวม (Daily Summary)")
    lines.append("─" * 50)
    lines.append(f"จำนวนไฟล์ทั้งหมดในระบบ  : {total_files} ไฟล์")
    lines.append(f"จำนวน Agent ที่ Active   : {active_agent_count} ท่าน (ตรวจพบไฟล์ใน Folder)")
    lines.append("")

    # --- Processing Status Table (แค่ 2 สถานะ) ---
    lines.append("🔍 สถานะการประมวลผล (Processing Status)")
    lines.append("─" * 50)
    lines.append(f"{'สถานะ':<25} | {'จำนวน':>6} | คำแนะนำ")
    lines.append("─" * 50)
    lines.append(f"{'✅ สำเร็จ (Success)':<25}| {success_count:>6} | ข้อมูลถูกดึงเข้าสู่ระบบเรียบร้อยแล้ว")
    lines.append(f"{'❌ ล้มเหลว (Fail)':<25}| {fail_count:>6} | มี Error กรุณาตรวจสอบรายละเอียดด้านล่าง")
    lines.append("")

    # --- Additional Info ---
    lines.append("💡 ข้อมูลเพิ่มเติม")
    lines.append("─" * 50)
    lines.append("• รายละเอียดทั้งหมด: รายละเอียด Transaction รายคน และ Log การทำงาน")
    lines.append("  อย่างละเอียด ได้ถูกแนบมาพร้อมกับอีเมลฉบับนี้แล้ว")
    lines.append("")

    # --- Footer ---
    lines.append("หากมีข้อสงสัยเพิ่มเติม สามารถติดต่อทีมพัฒนาได้ทันทีครับ")
    lines.append("")
    lines.append("ขอบคุณครับ")
    lines.append(sender_name)

    body = "\n".join(lines)

    log.info("Built Smart Reconcile email body: %d chars, %d agents, status=%s",
             len(body), active_agent_count, status_text)

    return body, status_text  # Return ทั้ง body และ status สำหรับใช้ใน subject

# =====================================================================================
# _build_smart_reconcile_subject - สร้าง email subject แบบ Smart Reconcile
# =====================================================================================
def _build_smart_reconcile_subject(
    status_text: str,
    date_str: Optional[str] = None,
) -> str:
    """
    สร้าง email subject แบบ Smart Reconcile

    Format: [Summary] OCR Smart Reconcile ประจำวันที่ DD/MM/YYYY | สถานะ: {{status}}

    Args:
        status_text: สถานะ ("สำเร็จ", "สำเร็จบางส่วน", "ล้มเหลว")
        date_str: วันที่ (ถ้าไม่ระบุจะใช้วันนี้)

    Returns:
        str: email subject
    """
    from datetime import datetime

    if not date_str:
        date_str = datetime.now().strftime("%d/%m/%Y")

    return f"[Summary] OCR Smart Reconcile ประจำวันที่ {date_str} | สถานะ: {status_text}"

